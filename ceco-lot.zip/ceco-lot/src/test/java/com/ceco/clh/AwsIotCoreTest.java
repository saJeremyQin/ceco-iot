package com.ceco.clh;

import com.amazonaws.services.iot.client.AWSIotDevice;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.ceco.common.utils.aws.IOTCoreUtils;
import com.ceco.configure.aws.AWSConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import software.amazon.awssdk.services.iot.IotClient;

/**
 * @auther Dean
 * @Date 2021/11/17.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class AwsIotCoreTest {
    @Autowired
    private IotClient iotClient;
    @Autowired
    private AWSConfig awsConfig;
    @Autowired
    private IOTCoreUtils iotCoreUtils;




    @Test
    public void createShadow()throws Exception{
        AWSIotMqttClient awsIotMqttClient =awsConfig.getAWSIotMqttClient();
        AWSIotDevice device = new AWSIotDevice("lightstripSSS");
        awsIotMqttClient.attach(device);
        awsIotMqttClient.connect();
//        device.onShadowUpdate(jsonState);
//        device.update(jsonState);
        String json="{\"state\": {\"desired\": {\"firmwave\": {\"socket\": \"off\"}},\"reported\": {\"firmwave\": {\"socket\": \"on\"}}}}";
        device.update(json);

    }

    @Test
    public void createThingShadow()throws Exception{

        iotCoreUtils.createThingShadow("lightstrip001","xxxx");


    }
    @Test
    public void createThing()throws Exception{

//        iotCoreUtils.createThing("lightstrip001","xxxx");


    }

    @Test
    public void attachThing2Certificate()throws Exception{

        iotCoreUtils.attachThing2Certificate("xxxxx","lightstrip");


    }

    @Test
    public void attachPolicy2Certificate()throws Exception{

        iotCoreUtils.attachPolicy2Certificate("xxxxx","");


    }
}
