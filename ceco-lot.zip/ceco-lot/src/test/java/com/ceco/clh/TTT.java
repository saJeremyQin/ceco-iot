package com.ceco.clh;

import com.ceco.channel.service.thing.model.aws1.A1101;
import com.google.gson.Gson;

/**
 * @auther Dean
 * @Date 2021/11/23.
 */
public class TTT {

    public static void main(String[] args) {
        System.out.println(System.currentTimeMillis());
        System.out.println(System.currentTimeMillis()/1000);

        System.out.println(Integer.MAX_VALUE);
    }
}
