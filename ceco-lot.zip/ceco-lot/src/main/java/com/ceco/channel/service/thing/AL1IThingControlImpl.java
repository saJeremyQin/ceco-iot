package com.ceco.channel.service.thing;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.cloudapi.sdk.model.ApiResponse;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.teautil.MapTypeAdapter;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.Constants;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.response.ResultResponse;
import com.ceco.configure.AliIOT.life.AL1IOTConfig;
import com.ceco.configure.AliIOT.life.IoTApiClientBuilderParams;
import com.ceco.configure.AliIOT.life.IoTApiRequest;
import com.ceco.configure.AliIOT.life.SyncApiClient;
import com.ceco.module.service.IDeviceService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @auther Dean
 * @Date 2021/10/29.
 * 阿里云生活物联网平台(旧)控制类
 */
@Service
@Slf4j
public class AL1IThingControlImpl implements IThingControl{
    @Autowired
    private SyncApiClient syncApiClient;

    @Autowired
    private AL1IOTConfig al1IOTConfig;

   final private String STATUS_GET_PATH="/cloud/thing/status/get";
   final private String PROPERTIES_GET_PATH="/cloud/thing/properties/get";
   final private String PROPERTIES_SET_PATH="/cloud/thing/properties/set";
   final private String CLOUD_TOKEN="/cloud/token";

//   @Autowired
//   private RedisTemplate redisTemplate;
//
//    @PostConstruct
//    public void init(){
//        String aliCloudToken=getCloudToken();
//        System.out.println(aliCloudToken);
//        //1.5小时后过期，正常阿里云是2小时
//        redisTemplate.opsForValue().set("aliCloudToken",aliCloudToken, Constants.ALIYUN_IOT_CLOUDTOKEN_EXPIRETIME, TimeUnit.SECONDS);
//    }

    @Override
    public boolean thingSceneParamSet(DeviceParam deviceParam) {

        return false;
    }

    private IoTApiRequest getIoTApiRequest(DeviceParam deviceParam){
        IoTApiClientBuilderParams builderParams = new IoTApiClientBuilderParams();
        builderParams.setAppKey(al1IOTConfig.getAppKey());
        builderParams.setAppSecret(al1IOTConfig.getAppSecret());

        IoTApiRequest request = new IoTApiRequest();
        //设置api的版本
        request.setApiVer("1.0.2");
        request.setCloudToken(deviceParam.getCloudToken()); //设置cloudToken 非认证接口都需要携带

        Map mapParams=new HashMap();

        mapParams.put("productKey",deviceParam.getProductKey());
        mapParams.put("deviceName",deviceParam.getDeviceName());
        request.setParams(mapParams);

        return request;
    }

    @Override
    public Map thingStatusSearch(DeviceParam deviceParam) {
        IoTApiClientBuilderParams builderParams = new IoTApiClientBuilderParams();
        builderParams.setAppKey(al1IOTConfig.getAppKey());
        builderParams.setAppSecret(al1IOTConfig.getAppSecret());
        SyncApiClient syncClient = new SyncApiClient(builderParams);

        String path =STATUS_GET_PATH;
        ApiResponse response =null;
        String  responseBody=null;
        ResultResponse resultResponse=null;
        try {
            response   = syncClient.postBody(al1IOTConfig.getChinaHost(), path, getIoTApiRequest(deviceParam),true);
            responseBody=new String(response.getBody(),
                    "utf-8");
            Map mapResponseBody = JSONObject.parseObject(responseBody);
            Integer codeInt=(Integer) mapResponseBody.get("code");

            if(codeInt==200){
                //返回值是200 查询成功
                Map statusMap=new HashMap();
                Integer statusInt=(Integer) ((Map)mapResponseBody.get("data")).get("status");
                statusMap.put("status",statusInt);
                return statusMap;

            }else{
               throw new BusinessException("-------------阿里云获取设备status接口异常------------");
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        throw new BusinessException("阿里云获取设备status接口异常");
    }

    @Override
    public ThingModel thingPropertySearch(DeviceParam deviceParam) {
        IoTApiClientBuilderParams builderParams = new IoTApiClientBuilderParams();
        builderParams.setAppKey(al1IOTConfig.getAppKey());
        builderParams.setAppSecret(al1IOTConfig.getAppSecret());
        SyncApiClient syncClient = new SyncApiClient(builderParams);

        //根据productKey 获取实际的物模型

        String  thingMoel=AL1IOTConfig.productKey2TingMoelMap.get(deviceParam.getProductKey());
        if(thingMoel==null){
            throw new BusinessException ( "=========产品key:["+ deviceParam.getProductKey()+"]对应的物模型不存在");
        }
        Class thingMoelClass=null;
        ThingModel thingModel=null;

        try {
            thingMoelClass=Class.forName(thingMoel); //获取实际的物模型对象
             thingModel=(ThingModel)thingMoelClass.newInstance();
        } catch (Exception e) {
            throw new BusinessException("该物模型不存在");
        }


        //请求参数域名、path、request
        String path =PROPERTIES_GET_PATH;
        ApiResponse response =null;
        String  responseBody=null;
        try {
            response   = syncClient.postBody(al1IOTConfig.getChinaHost(), path, getIoTApiRequest(deviceParam),true);
            responseBody=new String(response.getBody(),
                    "utf-8");

            Map mapResponseBody =JSONObject.parseObject(responseBody);
            Integer codeInt=(Integer) mapResponseBody.get("code");
            if(codeInt==200){
                List dataList=new ArrayList();
                dataList=(List)mapResponseBody.get("data");
                //==============待优化.....
                if(dataList.size()>0){
                    for(int i=0;i<dataList.size();i++){
                        Map mapTemp=(Map)dataList.get(i);
                        Map mapObj=new HashMap();
                        mapObj.put(mapTemp.get("attribute"),mapTemp.get("value"));
                         BeanUtil.copyProperties(mapObj,thingModel);
                    }
                }
                return thingModel;
            }else{
                throw  new BusinessException("获取物模型数据异常");
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return thingModel;

    }

    @Override
    public boolean thingPropertySet(DeviceParam deviceParam) {
        IoTApiClientBuilderParams builderParams = new IoTApiClientBuilderParams();
        builderParams.setAppKey(al1IOTConfig.getAppKey());
        builderParams.setAppSecret(al1IOTConfig.getAppSecret());
        SyncApiClient syncClient = new SyncApiClient(builderParams);

        //设置api的版本
        Gson gson = new Gson();
        Map mapParams=new HashMap();
        Map paramMap = gson.fromJson(deviceParam.getParam(),Map.class);

        //根据productKey 获取实际的物模型
        //String thingMoel="com.ceco.channel.service.thing.model.ali1.AL1LightStripThingModelX";   //
        String  thingMoel=AL1IOTConfig.productKey2TingMoelMap.get(deviceParam.getProductKey());
        if(thingMoel==null){
            throw new BusinessException ( "=========产品key:["+ deviceParam.getProductKey()+"]对应的物模型不存在");
        }
        Class thingMoelClass=null;

        try {
             thingMoelClass=Class.forName(thingMoel); //获取实际的物模型对象

        } catch (Exception e) {
            throw new BusinessException("该物模型不存在");
        }
       Object thingMoelObject=  ConvertUtil.convert(paramMap,thingMoelClass);

        // /将Map指令参数转为对象
       String jjjj=  JSONObject.toJSONString(thingMoelObject);

       Map mapItems=  JSONObject.parseObject(jjjj);
        IoTApiRequest request= getIoTApiRequest(deviceParam);

        mapParams.put("items",mapItems);

        mapParams.put("productKey",deviceParam.getProductKey());
        mapParams.put("deviceName",deviceParam.getDeviceName());

        log.info("阿里云请求参数===>" +JSONObject.toJSONString(mapParams));
        request.setParams(mapParams);

        //请求参数域名、path、request
        String path = PROPERTIES_SET_PATH;
        ApiResponse response =null;
        String  responseBody=null;
        try {
            response   = syncClient.postBody(al1IOTConfig.getChinaHost(), path, request,true);
            responseBody=new String(response.getBody(),
                   "utf-8");
            Map mapResponseBody = JSONObject.parseObject(responseBody);
            Integer codeInt=(Integer) mapResponseBody.get("code");
            if(codeInt==200){
                //设备在线，下发指令成功
                log.info("SUCCESS[invoke:thingPropertySet=="+"设备在线200"+"]");
                return true;
            }else if(codeInt==9201){
                //设备不在线
                log.info("SUCCESS[invoke:thingPropertySet=="+"设备离线9201"+"]");
                return true;
            }else{
                throw new BusinessException("ERROR[invoke:thingPropertySet=="+responseBody+"]");
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return true;

    }

    /**
     * 获取cloudToken
     * @return
     */
    public String getCloudToken() {
        IoTApiRequest request = new IoTApiRequest();
        request.setApiVer("1.0.1");
        request.putParam("grantType", "project");
        request.putParam("res", al1IOTConfig.getProjectId());
        ApiResponse response =null;
        String responseStr="";
        String cloudToken="";
        try {
            response=       syncApiClient.postBody(al1IOTConfig.getChinaHost(),
                    CLOUD_TOKEN, request, true);
            responseStr=new String(response.getBody(), "UTF-8");
            Map responseMap=JSONObject.parseObject(responseStr);
            Integer codeInt=(Integer)responseMap.get("code");
            if(codeInt!=200){
                log.info("ERROR[invoke:getCloudToken=="+responseStr+"]");
                throw  new BusinessException("ERROR[invoke-getCloudToken-"+responseStr+"]");
            }
            Map dataMap=(Map)responseMap.get("data");
            cloudToken=(String)dataMap.get("cloudToken");

        } catch (UnsupportedEncodingException e) {
            throw  new BusinessException("ERROR[invoke-getCloudToken-"+responseStr+"]");
        }
        return cloudToken;

    }

}
