package com.ceco.channel.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.resp.AppUserDeviceResp;
import com.ceco.channel.app.model.req.DeviceListReq;
import com.ceco.channel.app.model.req.DeviceRegisterReq;
import com.ceco.channel.app.model.req.DeviceSaveReq;
import com.ceco.channel.app.model.req.DeviceSaveSerialNoReq;
import com.ceco.channel.app.model.resp.*;
import com.ceco.channel.service.IApiDeviceService;
import com.ceco.common.Enum.EnumDeviceQueryType;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.DateUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.*;
import com.ceco.module.entity.device.DeviceInfo;
import com.ceco.module.service.*;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ApiDeviceServiceImpl implements IApiDeviceService {

    @Autowired
    IDeviceService deviceService;

    @Autowired
    IHomeService homeService;

    @Autowired
    IRoomService roomService;

    @Autowired
    IGroupService groupService;

    @Autowired
    IRoomDeviceService roomDeviceService;

    @Autowired
    IGroupDeviceService groupDeviceService;

    @Autowired
    IDeviceModelService deviceModelService;

    @Autowired
    IAppUserService appUserService;

    @Autowired
    IDeviceInfoService deviceInfoService;

    @Override
    public boolean register(DeviceRegisterReq req) {
        ValidatorUtils.validateEntity(req);
        Device device = deviceService.getOne(new QueryWrapper<Device>().lambda().eq(Device::getSerialNo,req.getSerialNo()));
        if(device != null){
            //云端设备已添加，那么忽略
            //throw  new BusinessException("设备已注册！");
            deviceService.removeById(device.getId());
        }
        device = ConvertUtil.convert(req,Device.class);
        return deviceService.save(device);
    }

    @Override
    public ConnectedDeviceResp getConnectedDevice(String appUserId) {
        ConnectedDeviceResp connectedDeviceResp = new ConnectedDeviceResp();
        List<Home> home = homeService.list(new QueryWrapper<Home>().lambda().eq(Home::getAppUserId,appUserId));
        List<HomeResp> homeRespList = ConvertUtil.convert(home, HomeResp.class);
        if(!CollectionUtils.isEmpty(homeRespList)){
            List<RoomResp> roomRespList = roomService.selectHomeRoom(appUserId);
            if(!roomRespList.isEmpty()) {
                Map<String, List<RoomResp>> roomListMap = roomRespList.stream().collect(Collectors.toMap(RoomResp::getHomeId,roomResp-> Lists.newArrayList(roomResp),(List<RoomResp> newValueList, List<RoomResp> oldValueList) ->
                {
                    oldValueList.addAll(newValueList);
                    return oldValueList;
                }));
            List<AppUserDeviceResp> appUserDeviceRespList = deviceService.selectUserDetailDevice(appUserId);
            Map<String,List<AppUserDeviceResp>> roomDeviceMap = appUserDeviceRespList.stream().collect(Collectors.toMap(AppUserDeviceResp::getRoomId,appUserDeviceResp-> Lists.newArrayList(appUserDeviceResp),(List<AppUserDeviceResp> newValueList, List<AppUserDeviceResp> oldValueList) ->
            {
                oldValueList.addAll(newValueList);
                return oldValueList;
            }));
            homeRespList.forEach(homeResp -> {
                    if(roomListMap.get(homeResp.getId()) !=null){
                        homeResp.setRoomRespList(roomListMap.get(homeResp.getId()));
                        List<DeviceResp> deviceRespList = new ArrayList<>();
                        homeResp.getRoomRespList().forEach(roomResp -> {
                            if(roomDeviceMap.get(roomResp.getId())!=null){
                                List<AppUserDeviceResp> appUserRoomDeviceRespList = roomDeviceMap.get(roomResp.getId());
                                appUserRoomDeviceRespList.forEach(appUserDeviceResp -> {
                                    DeviceResp deviceResp = new DeviceResp();
                                    deviceResp.setId(appUserDeviceResp.getDeviceId());
                                    deviceResp.setName(appUserDeviceResp.getDeviceName());
                                    deviceResp.setSerialNo(appUserDeviceResp.getSerialNo());
                                    deviceRespList.add(deviceResp);
                                });
                                roomResp.setDeviceRespList(deviceRespList);
                            }
                        });
                    }
                });
            }
        }
        connectedDeviceResp.setHomeRespList(homeRespList);

        List<Group> groupList = groupService.list(new QueryWrapper<Group>().lambda().eq(Group::getAppUserId,appUserId));
        List<GroupResp> groupRespList = ConvertUtil.convert(groupList, GroupResp.class);
        if(!CollectionUtils.isEmpty(groupRespList)){
            List<DeviceResp> deviceRespList = deviceService.selectGroupDevice(appUserId);
            if(!CollectionUtils.isEmpty(deviceRespList)){
                Map<String, List<DeviceResp>> groupDeviceMap = deviceRespList.stream().collect(Collectors.toMap(DeviceResp::getGroupId,deviceResp-> Lists.newArrayList(deviceResp),(List<DeviceResp> newValueList, List<DeviceResp> oldValueList) ->
                {
                    oldValueList.addAll(newValueList);
                    return oldValueList;
                }));
                groupRespList.forEach(groupResp -> {
                    if(groupDeviceMap.get(groupResp.getId()) !=null){
                        groupResp.setDeviceRespList(groupDeviceMap.get(groupResp.getId()));
                    }
                });
            }
        }
        connectedDeviceResp.setGroupRespList(groupRespList);
        return connectedDeviceResp;
    }

    @Override
    public boolean save(DeviceSaveReq req) {
        ValidatorUtils.validateEntity(req);
        Device device = deviceService.getById(req.getId());
        if(Objects.isNull(device)){
            throw  new BusinessException("修改的设备不存在!");
        }
        device.setName(req.getName());
        return deviceService.updateById(device);
    }

    @Override
    public boolean save(DeviceSaveSerialNoReq req) {
        ValidatorUtils.validateEntity(req);
        Device device = deviceService.getOne(new QueryWrapper<Device>().lambda().eq(Device::getSerialNo,req.getSerialNo()));
        if(Objects.isNull(device)){
            throw  new BusinessException("修改的设备不存在!");
        }
        device.setName(req.getName());
        return deviceService.updateById(device);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(String id) {
        boolean result =  deviceService.removeById(id);
        result = roomDeviceService.remove(new QueryWrapper<RoomDevice>().lambda().eq(RoomDevice::getDeviceId,id));
        result = groupDeviceService.remove(new QueryWrapper<GroupDevice>().lambda().eq(GroupDevice::getDeviceId,id));
        return result;
    }

    @Override
    public List<DeviceResp> list(DeviceListReq req) {

        LambdaQueryWrapper<Device> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Device::getAppUserId,req.getAppUserId()).or().eq(Device::getAppUserId,"-1").eq(StringUtil.isNotEmpty(req.getProductKey()),Device::getProductKey,req.getProductKey());
        if(req.getQueryType().intValue() != EnumDeviceQueryType.ALL.getValue()){
            if(StringUtil.isNotEmpty(req.getHomeId())){
                List<DeviceResp> deviceRespList = deviceService.selectRoomDevice(req.getHomeId() , req.getRoomId());
                List<String> deviceIdList = deviceRespList.stream().map(DeviceResp::getId).collect(Collectors.toList());
                if(CollUtil.isNotEmpty(deviceIdList)) {
                    if (req.getQueryType().intValue() == EnumDeviceQueryType.IN_ROOM_DEVICE.getValue()) {
                        queryWrapper.in(Device::getId, deviceIdList);
                    } else {
                        queryWrapper.notIn(Device::getId, deviceIdList);
                    }
                }else{
                    if (req.getQueryType().intValue() == EnumDeviceQueryType.IN_ROOM_DEVICE.getValue()) {
                        return deviceRespList;
                    }
                }
            }
        }
        List<Device> deviceList = deviceService.list(queryWrapper);
        List<DeviceResp> deviceRespList = ConvertUtil.convert(deviceList,DeviceResp.class);
        List<DeviceModel> deviceModelList = deviceModelService.list();
        Map<String,List<DeviceModel> > deviceModelMap ;
        if(CollUtil.isNotEmpty(deviceModelList)){
            deviceModelMap = deviceModelList.stream().collect(Collectors.groupingBy(DeviceModel::getProductKey));
        }else{
            deviceModelMap = new HashMap<>();
        }
        Room room ;
        if(StringUtil.isNotEmpty(req.getRoomId())) {
            room =roomService.getById(req.getRoomId());
        }else{
            room = null;
        }
        deviceRespList.forEach(deviceResp -> {
            if(room != null) {
                deviceResp.setRoomName(room.getName());
            }
            if (deviceModelMap.get(deviceResp.getProductKey()) != null) {
                DeviceModel deviceModel = deviceModelMap.get(deviceResp.getProductKey()).stream().findFirst().get();
                deviceResp.setImgUrl(deviceModel.getImgUrl());
                deviceResp.setDeviceModelName(deviceModel.getModelName());
            }
        });


        return deviceRespList;
    }


    @Override
    public DeviceResp getDeviceDetail(String id) {
        if(StringUtil.isEmpty(id)){
            throw  new BusinessException("id不能为空");
        }
        Device device = deviceService.getById(id);
        if(device == null) {
            return null;
        }
        DeviceResp deviceResp = ConvertUtil.convert(device,DeviceResp.class);
        List<RoomDevice> roomDeviceList = roomDeviceService.list(new QueryWrapper<RoomDevice>().lambda().eq(RoomDevice::getDeviceId,device.getId()));
        if(CollUtil.isNotEmpty(roomDeviceList)){
            RoomDevice roomDevice =  roomDeviceList.stream().findFirst().get();
            Room room = roomService.getById(roomDevice.getId());
            if(room !=null ){
                deviceResp.setRoomName(room.getName());
                deviceResp.setRoomId(room.getId());
            }
        }

        List<GroupDevice> groupDeviceList = groupDeviceService.list(new QueryWrapper<GroupDevice>().lambda().eq(GroupDevice::getDeviceId,device.getId()));
        if(CollUtil.isNotEmpty(groupDeviceList)){
            GroupDevice groupDevice = groupDeviceList.stream().findFirst().get();
            Group group = groupService.getById(groupDevice.getGroupId());
            if(group !=null){
                deviceResp.setGroupId(group.getId());
                deviceResp.setGroupName(group.getName());
            }
        }
        if(!StringUtil.isNotEmpty(deviceResp.getProductKey())){
            List<DeviceModel> deviceModelList = deviceModelService.list(new QueryWrapper<DeviceModel>().lambda().eq(DeviceModel::getProductKey,device.getProductKey()));
            if(CollUtil.isNotEmpty(deviceModelList)){
                DeviceModel deviceModel = deviceModelList.stream().findFirst().get();
                deviceResp.setImgUrl(deviceModel.getImgUrl());
            }
        }
        return deviceResp;
    }

    @Override
    public String getDeviceTime(String serialNo) {

        DeviceInfo deviceInfo = new DeviceInfo();
        deviceInfo.setConnected(1);
        deviceInfo.setSerialNo(serialNo);
        deviceInfoService.update(deviceInfo, new QueryWrapper<DeviceInfo>().lambda().eq(DeviceInfo::getSerialNo,deviceInfo.getSerialNo()));
        if(StringUtils.isEmpty(serialNo)){
             return DateUtils.format(DateUtils.date(),DateUtils.NORM_DATETIME_MS_PATTERN_1);
        }else{
            Device device = deviceService.getOne(new QueryWrapper<Device>().lambda().eq(Device::getSerialNo,serialNo));
            if(device == null ){
                return DateUtils.format(DateUtils.date(),DateUtils.NORM_DATETIME_MS_PATTERN_1);
            }else{
                AppUser appUser =appUserService.getById(device.getAppUserId());
                if(appUser == null ){
                    return DateUtils.format(DateUtils.date(),DateUtils.NORM_DATETIME_MS_PATTERN_1);
                }
                TimeZone defaultZone =  TimeZone.getDefault();
                TimeZone.setDefault(TimeZone.getTimeZone(appUser.getTimezone()));
                Calendar calendar = Calendar.getInstance();
                String dateTime =  DateUtils.format(calendar.getTime(),DateUtils.NORM_DATETIME_MS_PATTERN_1);
                TimeZone.setDefault(defaultZone);
                return dateTime;
            }
        }
    }
}
