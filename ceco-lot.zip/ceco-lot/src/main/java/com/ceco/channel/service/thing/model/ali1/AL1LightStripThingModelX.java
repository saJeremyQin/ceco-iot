package com.ceco.channel.service.thing.model.ali1;

import com.ceco.common.Enum.SwitchLed;
import com.ceco.common.Enum.SwitchMode;
import com.ceco.channel.service.thing.ThingModel;
import com.ceco.interceptor.annotation.CecoEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

/**
 * @auther Dean
 * @Date 2021/10/29.
 * Ceco定制面板模型
 */
@Data
public class AL1LightStripThingModelX extends ThingModel {
    //开关状态
    @CecoEnum(clazz = SwitchLed.class, method = "getValue", message = "switch_led参数只能为1或0")
    private Integer switchLed;

    //工作模式
    @CecoEnum(clazz = SwitchMode.class, method = "getValue", message = "switch_mode 参数:  1 white ,2 colour,3 scence,4 music 5节律")
    private Integer switchMode;

    //亮度值
    @ApiModelProperty("亮度值")
    @Max(value = 100,message = "bright_value最大不能超过100")
    @Min(value  =0,message = "bright_value最小不能小于0")
    private Integer brightValue;

    //冷暖值
    @ApiModelProperty("冷暖值")
    @Max(value = 6500,message = "temp_value最大不能超过6500")
    @Min(value = 2699,message = "temp_value最小不能小于2700")
    private Integer tempValue;






    //彩光   HSV 转换
    @ApiModelProperty("彩光")
    @Size(min=6,max = 6,message = "colourData长度应为6个字符:RGB，不含RGBCW")
    private String colourData;

    public String getColourData() {
        return colourData;
    }

    public void setColourData(String colourData) {
        this.colourData = colourData;
    }

    //动态灯效
    @ApiModelProperty("动态灯效")
    @Size(min=1,max = 512,message = "scene_data长度应小于512个字符")
    private String sceneData;


    //音乐律动
    @ApiModelProperty("音乐律动")
    @Size(min=21,max = 21,message = "music_data长度应为21个字符")
    private String musicData;


    //倒计时
    @ApiModelProperty("倒计时")
    @Max(value = 86400,message = "countdown最大不能超过86400")
    @Min(value  =0,message = "countdown最小不能小于0")
    private Integer countdown;

    //调节
    @ApiModelProperty("调节")
    @Size(min=0,max = 512,message = "control_data长度应小于512个字符")
    private String controlData;

    @ApiModelProperty("点数")
    @Max(value = 1000,message = "lightpixel_number_set最大不能超过1000")
    @Min(value  =1,message = "lightpixel_number_set最小不能小于1")
    private Integer lightpixelNumberSet;

    @ApiModelProperty("点数")
    @Size(min=0,max = 512,message = "colorPaletteData长度应小于512个字符")
    private String colorPaletteData;
}
