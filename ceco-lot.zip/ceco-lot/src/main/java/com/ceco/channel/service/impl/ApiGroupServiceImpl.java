package com.ceco.channel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.app.model.req.*;
import com.ceco.channel.app.model.resp.DeviceResp;
import com.ceco.channel.app.model.resp.GroupResp;
import com.ceco.channel.app.model.resp.RoomResp;
import com.ceco.channel.service.IApiGroupService;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.*;
import com.ceco.module.service.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ApiGroupServiceImpl implements IApiGroupService {

    @Autowired
    IGroupService groupService;


    @Autowired
    IGroupDeviceService groupDeviceService;


    @Autowired
    IDeviceService deviceService;





    @Override
    public GroupResp save(GroupSaveReq req) {
        ValidatorUtils.validateEntity(req);
        Group group = ConvertUtil.convert(req, Group.class);
        groupService.saveOrUpdate(group);
        GroupResp groupResp =  ConvertUtil.convert(group, GroupResp.class);
        return groupResp;

    }

    @Override
    public PageInfo<GroupResp> list(GroupListReq req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<Group> groupList = groupService.list(new QueryWrapper<Group>().lambda().eq(Group::getAppUserId,req.getAppUserId()));
        List<GroupResp> groupRespList = ConvertUtil.convert(groupList, GroupResp.class);

        if(!CollectionUtils.isEmpty(groupRespList)){
            List<DeviceResp> deviceRespList = deviceService.selectGroupDevice(req.getAppUserId());
            if(!CollectionUtils.isEmpty(deviceRespList)){
                Map<String, List<DeviceResp>> groupDeviceMap = deviceRespList.stream().collect(Collectors.toMap(DeviceResp::getGroupId,deviceResp-> Lists.newArrayList(deviceResp),(List<DeviceResp> newValueList, List<DeviceResp> oldValueList) ->
                {
                    oldValueList.addAll(newValueList);
                    return oldValueList;
                }));
                groupRespList.forEach(groupResp -> {
                    if(groupDeviceMap.get(groupResp.getId()) !=null){
                        groupResp.setDeviceRespList(groupDeviceMap.get(groupResp.getId()));
                    }
                });
            }
        }
        return new PageInfo<>(groupRespList);

    }

    @Override
    public boolean delete(String id) {
        return groupService.removeById(id);
    }

    @Override
    public boolean addGroupDevice(GroupDeviceAddReq req) {
        ValidatorUtils.validateEntity(req);
        List<Device> deviceList = deviceService.list(new QueryWrapper<Device>().lambda().in(Device::getId,req.getDeviceIdList()));
        if(CollectionUtils.isEmpty(deviceList)){
            throw  new BusinessException("设备不存在!");
        }
        //添加群组设备之前，先删除。因为删除群组接口并未删除群组和设备的绑定关系
       groupDeviceService.remove(new QueryWrapper<GroupDevice>().lambda().in(GroupDevice::getDeviceId,req.getDeviceIdList()).eq(GroupDevice::getGroupId,req.getGroupId()));
        List<GroupDevice> groupDeviceList = new ArrayList<>();
        req.getDeviceIdList().forEach(deviceId->{
            GroupDevice groupDevice = new GroupDevice();
            groupDevice.setDeviceId(deviceId);
            groupDevice.setGroupId(req.getGroupId());
            groupDeviceList.add(groupDevice);
        });
      return groupDeviceService.saveBatch(groupDeviceList);
    }
}
