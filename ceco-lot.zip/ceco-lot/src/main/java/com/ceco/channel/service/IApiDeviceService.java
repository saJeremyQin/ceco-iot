package com.ceco.channel.service;

import com.ceco.channel.app.model.req.DeviceListReq;
import com.ceco.channel.app.model.req.DeviceRegisterReq;
import com.ceco.channel.app.model.req.DeviceSaveReq;
import com.ceco.channel.app.model.req.DeviceSaveSerialNoReq;
import com.ceco.channel.app.model.resp.ConnectedDeviceResp;
import com.ceco.channel.app.model.resp.DeviceResp;

import java.util.List;

public interface IApiDeviceService {

    /**
     * 设备注册
     * @param req
     * @return
     */
    boolean register( DeviceRegisterReq req);


    /**
     * 查询已连接设备信息
     *   @param appUserId
     * @return
     */
    ConnectedDeviceResp getConnectedDevice(String appUserId);


    /**
     * 修改设备信息
     * @param req
     * @return
     */
    boolean save( DeviceSaveReq req);

    /**
     * 根据设备mac地址修改设备信息
     * @param req
     * @return
     */
    boolean save( DeviceSaveSerialNoReq req);

    /**
     * 删除设备信息
     * @param id
     * @return
     */
     boolean delete(String id);

    /**
     * 查询用户的所有设备
     * @param req
     * @return
     */
    List<DeviceResp> list(DeviceListReq req);


    /**
     * 获取设备详情
     * @param id
     * @return
     */
    DeviceResp getDeviceDetail(String id);


    /**
     * 获取用户所在时区的时间
     * @param serialNo 设备sn
     * @return
     */
    String getDeviceTime(String serialNo);

}
