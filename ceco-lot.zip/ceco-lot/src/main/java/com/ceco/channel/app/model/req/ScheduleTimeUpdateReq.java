package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("定时周期状态变更请求对象")
@Data
public class ScheduleTimeUpdateReq {

    @ApiModelProperty("定时配置具体时间id")
    private String scheduleId;

    @ApiModelProperty("状态:0无效1有效")
    private Integer status;


    private String time;



}
