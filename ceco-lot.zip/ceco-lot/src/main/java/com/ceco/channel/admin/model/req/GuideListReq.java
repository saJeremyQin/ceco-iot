package com.ceco.channel.admin.model.req;

import com.ceco.common.utils.BasePageReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("引导页列表请求对象")
public class GuideListReq extends BasePageReq {

    /**
     * 系统类型：1:ios2:安卓3:window4:其他
     */
    @ApiModelProperty("系统类型：1:ios2:安卓3:window4:其他")
    private Integer sysType;
}
