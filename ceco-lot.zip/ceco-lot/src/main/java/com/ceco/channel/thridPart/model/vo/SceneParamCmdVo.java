package com.ceco.channel.thridPart.model.vo;

import lombok.Data;

@Data
public class SceneParamCmdVo {

    private String colorList;

    private String showTimes;

    private String intervalTimes;

    private String status;

    private String timeRange;
}
