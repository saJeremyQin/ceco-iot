package com.ceco.channel.service;

import com.ceco.channel.admin.model.req.SceneListReq;
import com.ceco.channel.admin.model.req.SceneParamSaveReq;
import com.ceco.channel.admin.model.req.SceneSaveReq;
import com.ceco.channel.admin.model.resp.SceneParamResp;
import com.ceco.channel.admin.model.resp.SceneResp;
import com.github.pagehelper.PageInfo;

import java.util.List;


public interface IApiSceneService {

    /**
     * 保存动态灯效
     * @param req 动态灯效信息保存请求对象
     * @return 操作结果
     */
    boolean save(SceneSaveReq req);

    /**
     * 查询动态灯效信息列表
     * @param req 动态灯效信息列表请求对象
     * @return
     */
    PageInfo<SceneResp> list(SceneListReq req);



    /**
     * 查询动态灯效信息列表
     * @return
     */
    List<SceneResp> list();


    /**
     * 根据设备id查询
     * @param deviceId
     * @return
     */
    List<SceneResp> listByDeviceId(String deviceId);


    /**
     * 删除动态灯效数据
     * @param id 删除数据id
     * @return
     */
    boolean delete(String id);


    /**
     * 保存动态灯效的参数配置
     * @param req
     * @return
     */
    boolean paramSave( SceneParamSaveReq req);

    /**
     * 动态灯效删除
     * @return
     */
    List<SceneParamResp> paramList();

    /**
     * 动态灯效删除
     * @param id
     * @return
     */
    boolean paramDelete( String id);


}
