package com.ceco.channel.app.model.req;

import com.ceco.common.utils.BasePageReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("房间查询请求对象")
public class RoomListReq extends BasePageReq {

    @ApiModelProperty("家庭id")
    private String homeId;

    @ApiModelProperty("房间id")
    private String roomId;

}


