package com.ceco.channel.app.model.resp;

import com.ceco.channel.admin.model.resp.UserLoginResp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @auther Dean
 * @Date 2021/10/27.
 */
@ApiModel("阿里巴巴App外置用户登录返回对象")
public class AliAppUserLoginResp  extends UserLoginResp {
    private String AuthCode;

    public String getAuthCode() {
        return AuthCode;
    }

    public void setAuthCode(String authCode) {
        AuthCode = authCode;
    }
}
