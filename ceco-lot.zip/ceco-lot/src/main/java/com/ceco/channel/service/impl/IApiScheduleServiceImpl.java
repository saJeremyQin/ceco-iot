package com.ceco.channel.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.ceco.channel.app.model.req.ScheduleListReq;
import com.ceco.channel.app.model.req.ScheduleSaveReq;
import com.ceco.channel.app.model.req.ScheduleTimeSaveReq;
import com.ceco.channel.app.model.req.ScheduleTimeUpdateReq;
import com.ceco.channel.app.model.resp.ScheduleResp;
import com.ceco.channel.app.model.resp.ScheduleTimeResp;
import com.ceco.channel.service.IApiDeviceControlService;
import com.ceco.channel.service.IApiScheduleService;
import com.ceco.channel.service.thing.AL1IThingControlImpl;
import com.ceco.channel.service.thing.AWS1IThingControlImpl;
import com.ceco.channel.service.thing.DeviceParam;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.DateUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.Device;
import com.ceco.module.entity.Schedule;
import com.ceco.module.entity.ScheduleTime;
import com.ceco.module.service.IDeviceService;
import com.ceco.module.service.IScheduleService;
import com.ceco.module.service.IScheduleTimeService;
import org.joda.time.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import static com.ceco.common.utils.DateUtils.NORM_DATETIME_MS_PATTERN_1;
import static com.ceco.common.utils.DateUtils.NORM_DATETIME_PATTERN;


@Service
public class IApiScheduleServiceImpl implements IApiScheduleService {

    @Autowired
    IScheduleService scheduleService;
    @Autowired
    IScheduleTimeService scheduleTimeService;

    @Autowired
    IDeviceService deviceService;

    @Autowired
    private IApiDeviceControlService iApiDeviceControlService;

    @Autowired
    private AWS1IThingControlImpl  aws1IThingControl;

   @Override
   @Transactional(rollbackFor = Exception.class)
   public boolean save(ScheduleSaveReq req) {
       ValidatorUtils.validateEntity(req);
       boolean result = false;
       List<Schedule> scheduleList = scheduleService.list(new QueryWrapper<Schedule>().lambda().eq(Schedule::getAppUserId, req.getAppUserId()).eq(Schedule::getDeviceId, req.getDeviceId()));
       if (CollectionUtils.isEmpty(scheduleList)) {
           Schedule schedule = ConvertUtil.convert(req, Schedule.class);
           result = scheduleService.save(schedule);
           if (result) {
               List<ScheduleTime> scheduleTimeList = new ArrayList<>();
               req.getScheduleTimeSaveReqList().forEach(scheduleTimeSaveReq -> {
                   ScheduleTime scheduleTime = ConvertUtil.convert(scheduleTimeSaveReq, ScheduleTime.class);
                   scheduleTime.setScheduleId(schedule.getId());
                   scheduleTime.setType(req.getType());
                   scheduleTimeList.add(scheduleTime);
               });
               result = scheduleTimeService.saveBatch(scheduleTimeList);
           }
       } else {

           List<Schedule> scheduleExistsList = scheduleList.stream().filter(schedule1 -> schedule1.getType().intValue() == req.getType()).collect(Collectors.toList());
           Schedule schedule = null;
           if(req.getId() != null ){
               schedule =  scheduleService.getById(req.getId());
               if(schedule == null){
                   throw  new BusinessException("修改的数据不存在!");
               }
               schedule.setName(req.getName());
               schedule.setStatus(1);
               scheduleService.updateById(schedule);
               scheduleTimeService.remove(new QueryWrapper<ScheduleTime>().lambda().in(ScheduleTime::getScheduleId, req.getId()));
           }
           else {
               /**
                * 定时新增
                */
               List<String> scheduleIdList = scheduleExistsList.stream().map(Schedule::getId).collect(Collectors.toList());
               if (req.getType() == 0  ) {
                   if(CollUtil.isNotEmpty(scheduleIdList)) {
                       schedule = scheduleExistsList.get(0);
                   }else{
                       schedule = ConvertUtil.convert(req, Schedule.class);
                   }
                   scheduleTimeService.remove(new QueryWrapper<ScheduleTime>().lambda().eq(ScheduleTime::getScheduleId, schedule.getId()));
                   schedule.setStatus(1);
                   schedule.setName(req.getName());
                   scheduleService.saveOrUpdate(schedule);
               } else {
                   if (CollUtil.isNotEmpty(scheduleIdList)) {
                       List<Integer> dayOfWeekList = req.getScheduleTimeSaveReqList().stream().map(ScheduleTimeSaveReq::getDayOfWeek).collect(Collectors.toList());
                       List<Integer> timeList = req.getScheduleTimeSaveReqList().stream().map(ScheduleTimeSaveReq::getTime).collect(Collectors.toList());
                       List<ScheduleTime> scheduleTimeList = scheduleTimeService.list(new QueryWrapper<ScheduleTime>().lambda().
                               in(ScheduleTime::getScheduleId, scheduleIdList).
                               in(ScheduleTime::getTime, timeList).
                               in(ScheduleTime::getDayOfWeek, dayOfWeekList).
                               ne(StringUtil.isNotEmpty(req.getId()), ScheduleTime::getScheduleId, req.getId()));
                       if (CollUtil.isNotEmpty(scheduleTimeList)) {
                           throw new BusinessException("已存在相同的定时配置！");
                       }
                   }
                   schedule = ConvertUtil.convert(req, Schedule.class);
                   result = scheduleService.save(schedule);
               }
           }

           /**
            *  新增更新互斥数据无效
            */
           scheduleService.update(new UpdateWrapper<Schedule>().lambda().set(Schedule::getStatus, 0).
                   eq(Schedule::getDeviceId, req.getDeviceId()).
                   eq(Schedule::getAppUserId, req.getAppUserId()).
                   eq(Schedule::getType, (1 ^ req.getType())));
           String scheduleId = schedule.getId();
           List<ScheduleTime> scheduleTimeList = new ArrayList<>();
           req.getScheduleTimeSaveReqList().forEach(scheduleTimeSaveReq -> {
               ScheduleTime scheduleTime = ConvertUtil.convert(scheduleTimeSaveReq, ScheduleTime.class);
               scheduleTime.setType(req.getType());
               scheduleTime.setScheduleId(scheduleId);
               scheduleTimeList.add(scheduleTime);
           });
           result = scheduleTimeService.saveBatch(scheduleTimeList);
       }
       sendLotMsg(req.getDeviceId(),req.getAppUserId(),req.getTime());
       return result;
   }

    @Override
    public List<ScheduleResp> list(ScheduleListReq req) {
        List<Schedule> scheduleList = scheduleService.list(new QueryWrapper<Schedule>().lambda().eq(Schedule::getAppUserId, req.getAppUserId()).eq(Schedule::getDeviceId, req.getDeviceId()));
        List<ScheduleResp> scheduleRespList = new ArrayList<>();
        if(CollUtil.isNotEmpty(scheduleList)){
            scheduleRespList = ConvertUtil.convert(scheduleList,ScheduleResp.class);
            List<String> scheduleIdList = scheduleList.stream().map(Schedule::getId).collect(Collectors.toList());
            List<ScheduleTime> scheduleTimeList = scheduleTimeService.list(new QueryWrapper<ScheduleTime>().lambda().in(ScheduleTime::getScheduleId,scheduleIdList));
            if(CollUtil.isNotEmpty(scheduleTimeList)){
                Map<String,List<ScheduleTime>> scheduleTimeMap = scheduleTimeList.stream().collect(Collectors.groupingBy(ScheduleTime::getScheduleId));

                scheduleRespList.forEach(scheduleResp -> {
                    if(scheduleTimeMap.get(scheduleResp.getId() ) !=null){
                         List<ScheduleTime> scheduleTimes = scheduleTimeMap.get(scheduleResp.getId() );
                         List<ScheduleTimeResp> scheduleTimeRespList = ConvertUtil.convert(scheduleTimes,ScheduleTimeResp.class);
                         scheduleResp.setScheduleTimeRespList(scheduleTimeRespList);
                    }
                });
            }
        }

        return scheduleRespList;
    }

    @Override
    @Transactional(rollbackFor =Exception.class)
    public boolean updateStatus(ScheduleTimeUpdateReq req) {
        ValidatorUtils.validateEntity(req);
        Schedule schedule = scheduleService.getById(req.getScheduleId());
        boolean result = false;
        if(schedule == null){
            throw  new BusinessException("设置的定时配置不存在!");
        }
        List<Schedule> scheduleList = scheduleService.list(new QueryWrapper<Schedule>().lambda().
                eq(Schedule::getAppUserId, schedule.getAppUserId()).
                eq(Schedule::getDeviceId, schedule.getDeviceId()).
                ne(Schedule::getType,schedule.getType())
                .ne(Schedule::getId,schedule.getId()));

        schedule.setStatus( req.getStatus());
        result = scheduleService.updateById(schedule);
        if(CollUtil.isNotEmpty(scheduleList)) {
            if (req.getStatus() == 1) {
                List<String> scheduleIdList = scheduleList.stream().map(Schedule::getId).collect(Collectors.toList());
                scheduleService.update(new UpdateWrapper<Schedule>().lambda().set(Schedule::getStatus, (1 ^ req.getStatus())).in(Schedule::getId, scheduleIdList));
            }
        }
        sendLotMsg(schedule.getDeviceId(),schedule.getAppUserId(),req.getTime());
        return result;
    }

    @Override
    public boolean delete(String id,String time) {
        boolean result = false;
        Schedule schedule = scheduleService.getById(id);
        if(schedule == null){
            throw  new BusinessException("设置的定时配置不存在!");
        }
        result = scheduleService.removeById(id);
        scheduleTimeService.remove(new QueryWrapper<ScheduleTime>().lambda().eq(ScheduleTime::getScheduleId ,id));
        sendLotMsg(schedule.getDeviceId(),schedule.getAppUserId(),time);
        return result;
    }

    @Override
    public List<ScheduleTimeResp> restMelody() {
       List<ScheduleTimeResp> scheduleTimeRespList = new ArrayList<>();
        ScheduleTimeResp scheduleTimeResp = new ScheduleTimeResp();
        scheduleTimeResp.setDayOfWeek(0);
        scheduleTimeResp.setTime(390);
        scheduleTimeRespList.add(scheduleTimeResp);
        ScheduleTimeResp scheduleTimeResp1 = new ScheduleTimeResp();
        scheduleTimeResp1.setDayOfWeek(1);
        scheduleTimeResp1.setTime(690);
        scheduleTimeRespList.add(scheduleTimeResp1);
        ScheduleTimeResp scheduleTimeResp2 = new ScheduleTimeResp();
        scheduleTimeResp2.setDayOfWeek(2);
        scheduleTimeResp2.setTime(1020);
        scheduleTimeRespList.add(scheduleTimeResp2);
        ScheduleTimeResp scheduleTimeResp3 = new ScheduleTimeResp();
        scheduleTimeResp3.setDayOfWeek(3);
        scheduleTimeResp3.setTime(1260);
        scheduleTimeRespList.add(scheduleTimeResp3);
        return scheduleTimeRespList;
    }


    @Async
    public void sendLotMsg(String deviceId,String appUserId,String time){
        Map<String,Object> sendMap = new HashMap<>(8);
        sendMap.put("appUserId",appUserId);
        Device device =deviceService.getById(deviceId);
        if(device == null){
            return ;
        }
        sendMap.put("sn",device.getSerialNo());
        sendMap.put("cloudBiz","AWS1");
        sendMap.put("switchMode",5L);
        Date dateTime = DateUtils.parse(time,NORM_DATETIME_MS_PATTERN_1);


        sendMap.put("time", DateUtils.format(dateTime,NORM_DATETIME_PATTERN));

        DeviceParam deviceParam= iApiDeviceControlService.getDeviceParam(JSON.toJSONString(sendMap));
        aws1IThingControl.thingPropertySet(deviceParam);

    }
}
