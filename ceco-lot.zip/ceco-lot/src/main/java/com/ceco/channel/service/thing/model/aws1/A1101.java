package com.ceco.channel.service.thing.model.aws1;


import com.ceco.channel.service.thing.ThingModel;
import com.ceco.common.utils.ConvertUtil;
import lombok.Data;
import java.util.HashMap;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/18.
 * 呢绒灯 aws物模型
 */
@Data
public class A1101  extends ThingModel{

    public State state = new State();//设备影子状态
    @Data
    public static   class State {
        public Document reported = new Document();//硬件上报的状态
        public Document desired = new Document();//要下发到硬件的状态
    }

    @Data
    public static class Document {
        public Integer switchLed = null;//设备开关状态，默认为0关机，1开机
        public Integer switchMode = null;  //模式
        public Integer brightValue = null;//亮度值
        public Integer tempValue = null;//冷暖值
        public String colourData = null;//静态光效
        public String sceneData = null;//动态光效
        public String musicData = null;//音乐
        public String controlData = null;//节律
        public String colorPaletteData = null;//调色板
        public String productKey=null;//产品key
        public String serialNo=null;//设备编码，蓝牙地址
        public String timezone=null;//时区
        public Integer timestamp=null;//时间戳 int，4个字节 ：java 无 无符号整型，最大21亿，可以用到2038年；c语言有无符号整型,最大42亿，可以用到2106年

        @Override
        public String toString() {
            return "Document{" +
                    "switchLed=" + switchLed +
                    ", switchMode=" + switchMode +
                    ", brightValue=" + brightValue +
                    ", tempValue=" + tempValue +
                    ", colourData='" + colourData + '\'' +
                    ", sceneData='" + sceneData + '\'' +
                    ", musicData='" + musicData + '\'' +
                    ", controlData='" + controlData + '\'' +
                    ", colorPaletteData='" + colorPaletteData + '\'' +
                    ", productKey='" + productKey + '\'' +
                    ", serialNo='" + serialNo + '\'' +
                    ", timezone='" + timezone + '\'' +
                    ", timestamp=" + timestamp +
                    '}';
        }
    }





    public static Map outputData(Map<String,Object> mapParams){

        Document document=    ConvertUtil.convert(mapParams,Document.class);
        //不下发productKey
        document.setProductKey(null);
        Map stateMap =new HashMap();
        Map desiredMap=new HashMap();
        Map<String,Object>map1=ConvertUtil.convertToMapNotEmpty(document);
        desiredMap.put("desired",map1);
        stateMap.put("state",desiredMap);
        return stateMap;
    }


    public static void main(String[] args) {
        outputData(new HashMap());

    }



}
