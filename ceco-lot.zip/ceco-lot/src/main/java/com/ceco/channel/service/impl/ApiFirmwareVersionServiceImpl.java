package com.ceco.channel.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.FirmwareVersionListReq;
import com.ceco.channel.admin.model.req.FirmwareVersionSaveReq;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.channel.admin.model.resp.FirmwareVersionResp;
import com.ceco.channel.admin.model.resp.DeviceTypeResp;
import com.ceco.channel.service.IApiFirmwareVersionService;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.PageUtils;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.FirmwareVersion;
import com.ceco.module.entity.VersionSupportDevice;
import com.ceco.module.service.IFirmwareVersionService;
import com.ceco.module.service.IVersionSupportDeviceService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ApiFirmwareVersionServiceImpl implements IApiFirmwareVersionService {

    @Autowired
    IFirmwareVersionService firmwareVersionService;
    @Autowired
    IVersionSupportDeviceService versionSupportDeviceService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean save(FirmwareVersionSaveReq req) {
        ValidatorUtils.validateEntity(req);
        FirmwareVersion firmwareVersion = ConvertUtil.convert(req,FirmwareVersion.class);
        List<VersionSupportDevice> versionSupportDeviceList = new ArrayList<>();
        boolean result = firmwareVersionService.saveOrUpdate(firmwareVersion);
        versionSupportDeviceService.remove(new QueryWrapper<VersionSupportDevice>().lambda().eq(VersionSupportDevice::getVersionId,firmwareVersion.getId()));
        req.getDeviceModel().forEach(deviceModel ->{
            VersionSupportDevice versionSupportDevice = new VersionSupportDevice();
            versionSupportDevice.setDeviceModelId(deviceModel);
            versionSupportDevice.setVersionId(firmwareVersion.getId());
            versionSupportDeviceList.add(versionSupportDevice);
        });
        result = versionSupportDeviceService.saveBatch(versionSupportDeviceList);
        return result;
    }

    @Override
    public PageInfo<FirmwareVersionResp> list(FirmwareVersionListReq req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<FirmwareVersion> firmwareVersionList = firmwareVersionService.list();
        PageInfo<FirmwareVersion> pageInfo = new PageInfo<>(firmwareVersionList);
        PageInfo<FirmwareVersionResp> respPageInfo =PageUtils.pageInfo2Resp(pageInfo, FirmwareVersionResp.class);
        if(!CollUtil.isEmpty(respPageInfo.getList())){
            List<String> versionIdList = respPageInfo.getList().stream().map(FirmwareVersionResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> modelRespList = versionSupportDeviceService.selectSupportDeviceList(versionIdList);
            if(!CollUtil.isEmpty(modelRespList)){
                Map<String,List<DeviceModelResp>> versionDeviceMap= modelRespList.stream().collect(Collectors.toMap(DeviceModelResp::getVersionId, deviceModelResp-> Lists.newArrayList(deviceModelResp),(List<DeviceModelResp> newValueList, List<DeviceModelResp> oldValueList) ->
                {
                    oldValueList.addAll(newValueList);
                    return oldValueList;
                }));
                respPageInfo.getList().forEach(firmwareVersionResp -> {
                    if(versionDeviceMap.get(firmwareVersionResp.getId() ) !=null){
                        firmwareVersionResp.setDeviceModelRespList(versionDeviceMap.get(firmwareVersionResp.getId()));
                    }
                });
            }
        }
        return  respPageInfo;
    }

    @Override
    public List<FirmwareVersionResp> list() {
        List<FirmwareVersion> firmwareVersionList = firmwareVersionService.list();
        List<FirmwareVersionResp> firmwareVersionRespList =  ConvertUtil.convert(firmwareVersionList,FirmwareVersionResp.class);
        if(!CollUtil.isEmpty(firmwareVersionRespList)){
            List<String> versionIdList = firmwareVersionRespList.stream().map(FirmwareVersionResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> modelRespList = versionSupportDeviceService.selectSupportDeviceList(versionIdList);
            if(!CollUtil.isEmpty(modelRespList)){
                Map<String,List<DeviceModelResp>> versionDeviceMap= modelRespList.stream().collect(Collectors.toMap(DeviceModelResp::getVersionId, deviceModelResp-> Lists.newArrayList(deviceModelResp),(List<DeviceModelResp> newValueList, List<DeviceModelResp> oldValueList) ->
                {
                    oldValueList.addAll(newValueList);
                    return oldValueList;
                }));
                firmwareVersionRespList.forEach(firmwareVersionResp -> {
                    if(versionDeviceMap.get(firmwareVersionResp.getId() ) !=null){
                        firmwareVersionResp.setDeviceModelRespList(versionDeviceMap.get(firmwareVersionResp.getId()));
                    }
                });
            }
        }
        return firmwareVersionRespList;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(String id) {
        boolean result =  firmwareVersionService.removeById(id);
        result = versionSupportDeviceService.remove(new QueryWrapper<VersionSupportDevice>().lambda().eq(VersionSupportDevice::getVersionId,id));
        return result;
    }


}
