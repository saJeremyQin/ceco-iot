package com.ceco.channel.app.model.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;


@ApiModel("群组保存响应对象")
@Data
public class UserColorResp {


    @ApiModelProperty("颜色")
    private String color;

    @ApiModelProperty("用户id")
    private String appUserId;

    private String id;

}
