package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@ApiModel("定时配置保存请求对象")
public class ScheduleSaveReq {

    @ApiModelProperty("用户id")
    @NotEmpty(message = "用户信息不能为空")
    private String appUserId;

    @ApiModelProperty("保存的定时配置类型:0节律1定时")
    @NotNull(message = "配置类型不能为空")
    private Integer type;

    @ApiModelProperty("保存的定时配置类型:设备id")
    @NotEmpty(message = "设备id不能为空")
    private String deviceId;

    @ApiModelProperty("具体的时间配置清单列表")
    private List<ScheduleTimeSaveReq> scheduleTimeSaveReqList;


    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("修改id")
    private String id;

    @ApiModelProperty("客户端时间")
    private String time;

}
