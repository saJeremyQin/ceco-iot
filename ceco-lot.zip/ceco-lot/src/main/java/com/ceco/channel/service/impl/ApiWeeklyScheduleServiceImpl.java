package com.ceco.channel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.service.IApiWeeklyScheduleService;
import com.ceco.channel.thridPart.model.vo.WeeklyScheduleDateTemp;
import com.ceco.channel.thridPart.model.vo.WeeklyScheduleVo;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.GsonUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.common.utils.reflect.ReflectUtils;
import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.Biorhythm;
import com.ceco.module.entity.WeeklySchedule;
import com.ceco.module.service.IBiorhythmService;
import com.ceco.module.service.IWeeklyScheduleService;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @auther Dean
 * @Date 2021/11/10.
 */
@Service
@Slf4j
@Transactional
public class ApiWeeklyScheduleServiceImpl implements IApiWeeklyScheduleService {
    @Autowired
    private IWeeklyScheduleService iWeeklyScheduleService;
    @Autowired
    private IBiorhythmService iBiorhythmService;

    @Override
    public ResponseModel queryOneWeekScheduleService(Map map) {

        String appUserId=(String)map.get("appUserId");
        WeeklySchedule weeklySchedule=iWeeklyScheduleService.getOne(new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId,appUserId));
        WeeklyScheduleVo weeklyScheduleVo=WeeklyScheduleVo.getWeeklyScheduleVo(weeklySchedule);

        Biorhythm biorhythm= iBiorhythmService.getOne(new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getAppUserId,appUserId));
        Map biorhythmMap=new HashMap();
        biorhythmMap.put("id",biorhythm.getId());
        biorhythmMap.put("status",biorhythm.getStatus());

        Map weeklyScheduleMap=new HashMap();
        weeklyScheduleMap.put("monday",weeklyScheduleVo.getMonday());
        weeklyScheduleMap.put("tuesday",weeklyScheduleVo.getTuesday());
        weeklyScheduleMap.put("wednesday",weeklyScheduleVo.getWednesday());
        weeklyScheduleMap.put("thursday",weeklyScheduleVo.getThursday());
        weeklyScheduleMap.put("friday",weeklyScheduleVo.getFriday());
        weeklyScheduleMap.put("saturday",weeklyScheduleVo.getSaturday());
        weeklyScheduleMap.put("sunday",weeklyScheduleVo.getSunday());
        weeklyScheduleMap.put("status",weeklyScheduleVo.getStatus());


        Map mapRes=new HashMap();
        mapRes.put("weeklyScheduleVo",weeklyScheduleMap);
        mapRes.put("biorhythmVo",biorhythmMap);









        return ResponseModel.success(200,"生物节律和周定时列表查询",mapRes);
    }

    @Override
    public ResponseModel deleteWeekScheduleService(Map map) {
        String appUserId=(String)map.get("appUserId");
        String time=(String)map.get("time");
        String whichDay=(String)map.get("whichDay");
        String serialNo=(String)map.get("serialNo");
        WeeklySchedule weeklySchedule=iWeeklyScheduleService.getOne(new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId,appUserId).eq(WeeklySchedule::getSerialNo,serialNo));
        Method method= ReflectUtils.getGetMethod(WeeklySchedule.class,whichDay); //获取反射的get方法
        Object whichDaySTR=null;
        try {
             whichDaySTR=method.invoke(weeklySchedule);
        } catch (Exception e) {
            throw new BusinessException("传入的whichDay星期格式有误:"+whichDay);
        }
        Gson gson=new Gson();

        Map whichDayMap= gson.fromJson(whichDaySTR.toString(),Map.class)  ;
        whichDayMap.remove(time);//删除 该时间

        String resultStr=gson.toJson(whichDayMap);
        ReflectUtils.setValue(weeklySchedule,WeeklySchedule.class,whichDay,String.class,resultStr); //反射更新字段

        //通过反射更新，实现删除
        iWeeklyScheduleService.update(weeklySchedule,new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId,appUserId).eq(WeeklySchedule::getSerialNo,serialNo));
        return ResponseModel.success(200,"删除成功",null);
    }

    @Override
    public ResponseModel updateWeekScheduleService(Map map) {
        String appUserId=(String)map.get("appUserId");
        String serialNo=(String)map.get("serialNo");
        WeeklySchedule    weeklySchedule0     =iWeeklyScheduleService.getOne(new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId,appUserId).eq(WeeklySchedule::getSerialNo,serialNo));

        Map mondayMap=(Map)map.get("monday");
        Map tuesdayMap=(Map)map.get("tuesday");
        Map wednesdayMap=(Map)map.get("wednesday");
        Map thursdayMap=(Map)map.get("thursday");
        Map fridayMap=(Map)map.get("friday");
        Map saturdayMap=(Map)map.get("saturday");
        Map sundayMap=(Map)map.get("sunday");
        Gson gson =new Gson();
        String mapStr=gson.toJson(map);

        String mondayStr=weeklySchedule0.getMonday();
        Map mondayAll=new HashMap();
        Map mondayStrMap=gson.fromJson(mondayStr,Map.class);
        if(mondayStrMap!=null)
            mondayAll.putAll(mondayStrMap);//旧的map
        if(mondayMap!=null)
            mondayAll.putAll(dayMap2TimeOpeMap(mondayMap)); //新的map，有重复的则发生覆盖
        weeklySchedule0.setMonday(gson.toJson(mondayAll));

        String tuesdayStr=weeklySchedule0.getTuesday();
        Map tuesdayAll=new HashMap();
        Map tuesdayStrMap=gson.fromJson(tuesdayStr,Map.class);
        if(tuesdayStrMap!=null)
            tuesdayAll.putAll(tuesdayStrMap);
        if(tuesdayMap!=null)
            tuesdayAll.putAll(dayMap2TimeOpeMap(tuesdayMap));
        weeklySchedule0.setTuesday(gson.toJson(tuesdayAll));

        String wednesdayStr=weeklySchedule0.getWednesday();
        Map wednesdayAll=new HashMap();
        Map wednesdayStrMap=gson.fromJson(wednesdayStr,Map.class);
        if(wednesdayStrMap!=null)
            wednesdayAll.putAll(wednesdayStrMap);
        if(wednesdayMap!=null)
            wednesdayAll.putAll(dayMap2TimeOpeMap(wednesdayMap));
        weeklySchedule0.setWednesday(gson.toJson(wednesdayAll));

        String thursdayStr=weeklySchedule0.getThursday();
        Map thursdayAll=new HashMap();
        Map thursdayStrMap=gson.fromJson(thursdayStr,Map.class);
        if(thursdayStrMap!=null)
            thursdayAll.putAll(thursdayStrMap);
        if(thursdayMap!=null)
            thursdayAll.putAll(dayMap2TimeOpeMap(thursdayMap));
        weeklySchedule0.setThursday(gson.toJson(thursdayAll));



        String fridayStr=weeklySchedule0.getFriday();
        Map fridayAll=new HashMap();
        Map fridayStrMap=gson.fromJson(fridayStr,Map.class);
        if(fridayStrMap!=null)
            fridayAll.putAll(fridayStrMap);
        if(fridayMap!=null)
            fridayAll.putAll(dayMap2TimeOpeMap(fridayMap));
        weeklySchedule0.setFriday(gson.toJson(fridayAll));

        String saturdayStr=weeklySchedule0.getSaturday();
        Map saturdayAll=new HashMap();
        Map saturdayStrMap=gson.fromJson(saturdayStr,Map.class);
        if(saturdayStrMap!=null)
            saturdayAll.putAll(saturdayStrMap);
        if(saturdayMap!=null)
            saturdayAll.putAll(dayMap2TimeOpeMap(saturdayMap));
        weeklySchedule0.setSaturday(gson.toJson(saturdayAll));


        String sundayStr=weeklySchedule0.getSunday();
        Map sundayAll=new HashMap();
        Map sundayStrMap=gson.fromJson(sundayStr,Map.class);
        if(sundayStrMap!=null)
            saturdayAll.putAll(sundayStrMap);
        if(sundayMap!=null)
            saturdayAll.putAll(dayMap2TimeOpeMap(sundayMap));
        weeklySchedule0.setSunday(gson.toJson(sundayAll));


        //包含状态，设置生效开关
        if(mapStr.contains("\"subStatus\":\"1\"")){
            weeklySchedule0.setStatus(1);
            Biorhythm biorhythm=new Biorhythm();
            biorhythm.setAppUserId(appUserId);
            biorhythm.setStatus(0);
            iBiorhythmService.update(biorhythm,new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getAppUserId,appUserId).eq(Biorhythm::getSerialNo,serialNo));
        }
        iWeeklyScheduleService.update(weeklySchedule0,new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId,appUserId).eq(WeeklySchedule::getSerialNo,serialNo));

        //修改状态,
        return ResponseModel.success(200,"状态修改成功",null);
    }


    /**
     * 新增，单日的每个定时规则启用状态是0 未启用
     * 新增后，立刻生效。生物节律变为失效
     * @param map
     * @return
     */
    private Map  dayMap2TimeOpeMap(Map map){
        String time=(String)map.get("time");
        String operation= (String)map.get("operation");
        Map mapBody=new HashMap();
        mapBody.put("operation",operation);
        mapBody.put("subStatus","1");
        Map mapxx=new HashMap();
        mapxx.put(time,mapBody);
        return mapxx;
    }

    /**
     * 将app前端传入的参数，封装为要存入数据库的形式
     * 保存即开启subStatus=1
     * @param map
     * @return
     */
    private Map  dayMap2TimeOpeMap2(Map map){
        if(!(null==map)&&map.size()!=0){
            long time=(long)map.get("time");
            long operation= (long)map.get("operation");
            Map mapBody=new HashMap();
            mapBody.put("operation",operation+"");
            mapBody.put("subStatus","1");
            Map mapxx=new HashMap();
            mapxx.put(time,mapBody);
            return mapxx;
        }
        return new HashMap();

    }

    /**
     * 保存接口
     * 难点:对于数据库而言，新增、删除、修改都是更新操作
     * @param map
     * @return
     */
    @Override
    public ResponseModel saveWeeklyScheduleService(Map map) {
        String appUserId=(String)map.get("appUserId");
        String serialNo=(String)map.get("serialNo");
        Integer status=(int)map.get("status");

        Gson gson =new Gson();
        WeeklyScheduleDateTemp weeklyScheduleDateTemp= ConvertUtil.convert(map,WeeklyScheduleDateTemp.class);
        //转为map，则属性为map的变为Json字符串了
        HashMap<String, Object>  weeklyScheduleDateTempMap=ConvertUtil.convertToMap(weeklyScheduleDateTemp);
        //请求参数-->weeklyScheduleDateTempMap-> value 重新赋值 {"312":{"operation":"0","subStatus":"1"}}
        for(Map.Entry<String,Object> entry:weeklyScheduleDateTempMap.entrySet()){
                    String key=entry.getKey();
                    String value=(String)entry.getValue();

                    Map mapTemp= GsonUtils.gsonToMap(value);
                    //将app前端传入的参数，封装为要存入数据库的形式
                    value= gson.toJson(dayMap2TimeOpeMap2(mapTemp)) ;
                    //重新赋值
                    weeklyScheduleDateTempMap.put(key,value);
        }

        //将数据库要求的json字符串赋值给weeklySchedule
        //  {"312":{"operation":"0","subStatus":"1"}}
        WeeklySchedule     weeklySchedule    = ConvertUtil.convert(weeklyScheduleDateTempMap,WeeklySchedule.class);
        weeklySchedule.setAppUserId(appUserId);
        weeklySchedule.setSerialNo(serialNo);


        WeeklySchedule    weeklySchedule0     =iWeeklyScheduleService.getOne(new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId,appUserId).eq(WeeklySchedule::getSerialNo,serialNo));
        if(weeklySchedule0==null){
            iWeeklyScheduleService.save(weeklySchedule);
            return ResponseModel.success(200,"新增成功",null);
        }else{

            map.remove("serialNo");
            map.remove("appUserId");

            for(Object key:map.keySet()){
                String methodName=(String)key;
                Method method=ReflectUtils.getGetMethod(WeeklySchedule.class,methodName);
                try {
                  String weeklyScheduleGetM=(String) method.invoke(weeklySchedule);//new
                  String weeklySchedule0GetM=(String) method.invoke(weeklySchedule0);//old
                  Map xDayAll=new HashMap();
                  Map oldMap=gson.fromJson(weeklySchedule0GetM,Map.class);
                    xDayAll.putAll(oldMap);
                  Map newMap=gson.fromJson(weeklyScheduleGetM,Map.class);
                  xDayAll.putAll(newMap);

                  String xDayString=gson.toJson(xDayAll);
                  ReflectUtils.setValue(weeklySchedule0,WeeklySchedule.class,methodName,String.class,xDayString);

                } catch (Exception e) {
                    throw new BusinessException("反射获取日期参数方法调用失败");
                }
            }

            //status==null，是新增的，生效；status=1，是更新，让他生效
           if(status==null||status==1){

               Biorhythm biorhythm=new Biorhythm();
               biorhythm.setAppUserId(appUserId);
               biorhythm.setStatus(0);
               iBiorhythmService.update(biorhythm,new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getAppUserId,appUserId).eq(Biorhythm::getSerialNo,serialNo));
           }


            iWeeklyScheduleService.update(weeklySchedule0,new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId,appUserId).eq(WeeklySchedule::getSerialNo,serialNo));

        }

        return ResponseModel.success(200,"新增成功",null);
    }



}
