package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@ApiModel("定时配置列表请求对象")
public class ScheduleListReq {

    @ApiModelProperty("用户id")
    private String appUserId;

    @ApiModelProperty("设备id")
    private String deviceId;

}
