package com.ceco.channel.app.controller;

import com.ceco.channel.app.model.req.ScheduleListReq;
import com.ceco.channel.app.model.req.ScheduleSaveReq;
import com.ceco.channel.app.model.req.ScheduleTimeUpdateReq;
import com.ceco.channel.app.model.resp.ScheduleResp;
import com.ceco.channel.app.model.resp.ScheduleTimeResp;
import com.ceco.channel.service.IApiScheduleService;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@ApiModel("定时配置控制器")
@RestController
@RequestMapping("/app/schedule")
public class AppScheudleController {

    @Autowired
    IApiScheduleService apiScheduleService;

    @ApiOperation("定时配置保存")
    @PostMapping("/save")
    public boolean save(@RequestBody ScheduleSaveReq req){
        return apiScheduleService.save(req);
    }


    @ApiOperation("定时配置查询")
    @PostMapping("/list")
    public List<ScheduleResp> save(@RequestBody ScheduleListReq req){
        return apiScheduleService.list(req);
    }

    @ApiOperation("定时配置状态变更查询")
    @PostMapping("/updateStatus")
    public boolean updateStatus (@RequestBody ScheduleTimeUpdateReq req){
        return apiScheduleService.updateStatus(req);
    }

    @ApiOperation("定时配置删除")
    @GetMapping("/delete/{id}/{time}")
    public boolean delete (@PathVariable String id,@PathVariable String time){
        return apiScheduleService.delete(id, time);
    }


    @ApiOperation("重置节律")
    @GetMapping("/restMelody")
    public  List<ScheduleTimeResp> restMelody(){
        return apiScheduleService.restMelody();
    }




}
