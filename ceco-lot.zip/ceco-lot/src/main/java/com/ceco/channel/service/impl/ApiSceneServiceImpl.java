package com.ceco.channel.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.SceneListReq;
import com.ceco.channel.admin.model.req.SceneParamSaveReq;
import com.ceco.channel.admin.model.req.SceneSaveReq;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.channel.admin.model.resp.ModelResp;
import com.ceco.channel.admin.model.resp.SceneParamResp;
import com.ceco.channel.admin.model.resp.SceneResp;
import com.ceco.channel.service.IApiSceneService;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.PageUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.*;
import com.ceco.module.service.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.ceco.common.utils.Constants.DYNAMIC_LIGHTING;

@Service
public class ApiSceneServiceImpl implements IApiSceneService {

    @Autowired
    ISceneConfService sceneConfService;
    @Autowired
    IConfDeviceService confDeviceService;

    @Autowired
    ISceneParamService sceneParamService;
    @Autowired
    IDeviceService deviceService;

    @Autowired
    IDeviceModelService deviceModelService;


    @Override
    public boolean save(SceneSaveReq req) {
        ValidatorUtils.validateEntity(req);
        SceneConf sceneConf = ConvertUtil.convert(req, SceneConf.class);
        boolean result =  sceneConfService.saveOrUpdate(sceneConf);
        List<ConfDevice> confDeviceList = new ArrayList<>();
        confDeviceService.remove(new QueryWrapper<ConfDevice>().lambda().eq(ConfDevice::getConfId,sceneConf.getId()));
        req.getDeviceModel().forEach(deviceModel ->{
            ConfDevice confDevice = new ConfDevice();
            confDevice.setDeviceModelId(deviceModel);
            confDevice.setConfId(sceneConf.getId());
            confDevice.setType(DYNAMIC_LIGHTING);
            confDeviceList.add(confDevice);
        });
        confDeviceService.saveBatch(confDeviceList);
        return result;

    }

    @Override
    public PageInfo<SceneResp> list(SceneListReq req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<SceneConf> sceneConfList = sceneConfService.list();
        List<SceneParam> sceneParamList = sceneParamService.list();
        PageInfo<SceneConf> pageInfo = new PageInfo<>(sceneConfList);
        PageInfo<SceneResp> respPageInfo = PageUtils.pageInfo2Resp(pageInfo, SceneResp.class);
        if(!CollUtil.isEmpty(respPageInfo.getList())){

            List<String> modelIdList = respPageInfo.getList().stream().map(SceneResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> deviceModelRespList = confDeviceService.selectConfDeviceList(modelIdList,DYNAMIC_LIGHTING,null);
            if(!CollUtil.isEmpty(deviceModelRespList)){
                Map<String,List<DeviceModelResp>> confDeviceMap = deviceModelRespList.stream().collect(Collectors.groupingBy(DeviceModelResp::getConfId));
                Map<String,List<SceneParam>> sceneParamMap ;
                if(CollUtil.isNotEmpty(sceneParamList)){
                    sceneParamMap = sceneParamList.stream().collect(Collectors.groupingBy(SceneParam::getId));
                }else{
                    sceneParamMap = new HashMap<>();
                }
                respPageInfo.getList().forEach(modelResp -> {
                    if(confDeviceMap.get(modelResp.getId() ) !=null){
                        modelResp.setDeviceModelRespList(confDeviceMap.get(modelResp.getId()));
                    }
                    if(sceneParamMap.get(modelResp.getParamId()) !=null ){
                        modelResp.setParamContent(sceneParamMap.get(modelResp.getParamId()).stream().findFirst().get().getContent());
                    }
                });
            }

        }
        return respPageInfo;
    }

    @Override
    public List<SceneResp> list() {
        List<SceneConf> sceneConfList = sceneConfService.list();
        List<SceneResp> sceneRespList =  ConvertUtil.convert(sceneConfList,SceneResp.class);
        List<SceneParam> sceneParamList = sceneParamService.list();
        if(!CollUtil.isEmpty(sceneRespList)){
            List<String> modelIdList = sceneRespList.stream().map(SceneResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> deviceModelRespList = confDeviceService.selectConfDeviceList(modelIdList,DYNAMIC_LIGHTING,null);
            Map<String,List<SceneParam>> sceneParamMap ;
            if(CollUtil.isNotEmpty(sceneParamList)){
                sceneParamMap = sceneParamList.stream().collect(Collectors.groupingBy(SceneParam::getId));
            }else{
                sceneParamMap = new HashMap<>();
            }
            if(!CollUtil.isEmpty(deviceModelRespList)){
                Map<String,List<DeviceModelResp>> confDeviceMap = deviceModelRespList.stream().collect(Collectors.groupingBy(DeviceModelResp::getConfId));
                sceneRespList.forEach(modelResp -> {
                    if(confDeviceMap.get(modelResp.getId() ) !=null){
                        modelResp.setDeviceModelRespList(confDeviceMap.get(modelResp.getId()));
                    }
                    if(sceneParamMap.get(modelResp.getParamId())!= null){
                        SceneParam sceneParam = sceneParamMap.get(modelResp.getParamId()).stream().findFirst().get();
                        modelResp.setParamContent(sceneParam.getContent());
                    }
                });
            }

        }
        return sceneRespList;
    }

    @Override
    public List<SceneResp> listByDeviceId(String deviceId) {
        List<SceneResp> respList = new ArrayList<>();

        if (StringUtil.isEmpty(deviceId)) {
            return respList;
        }
        Device device = deviceService.getById(deviceId);
        if (Objects.isNull(device) || Objects.isNull(device.getProductKey())) {
            return respList;
        }
        List<SceneResp> sceneRespList = sceneConfService.getSceneRespListByDeviceId(deviceId);
        List<SceneParam> sceneParamList = sceneParamService.list();
        if (!CollUtil.isEmpty(sceneRespList)) {
            List<String> modelIdList = sceneRespList.stream().map(SceneResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> deviceModelRespList = confDeviceService.selectConfDeviceList(modelIdList, DYNAMIC_LIGHTING, null);
            Map<String, List<SceneParam>> sceneParamMap;
            if (CollUtil.isNotEmpty(sceneParamList)) {
                sceneParamMap = sceneParamList.stream().collect(Collectors.groupingBy(SceneParam::getId));
            } else {
                sceneParamMap = new HashMap<>();
            }
            if (!CollUtil.isEmpty(deviceModelRespList)) {
                Map<String, List<DeviceModelResp>> confDeviceMap = deviceModelRespList.stream().collect(Collectors.groupingBy(DeviceModelResp::getConfId));
                sceneRespList.forEach(modelResp -> {
                    if (confDeviceMap.get(modelResp.getId()) != null) {
                        modelResp.setDeviceModelRespList(confDeviceMap.get(modelResp.getId()));
                    }
                    if (sceneParamMap.get(modelResp.getParamId()) != null) {
                        SceneParam sceneParam = sceneParamMap.get(modelResp.getParamId()).stream().findFirst().get();
                        modelResp.setParamContent(sceneParam.getContent());
                    }
                });
            }
        }
            return sceneRespList;


    }

    @Override
    public boolean delete(String id) {
        return sceneConfService.removeById(id);
    }


    @Override
    public boolean paramSave(SceneParamSaveReq req) {
        ValidatorUtils.validateEntity(req);
        SceneParam  sceneParam = ConvertUtil.convert(req,SceneParam.class);
        return sceneParamService.saveOrUpdate(sceneParam);
    }

    @Override
    public List<SceneParamResp> paramList() {
        List<SceneParam> paramList  = sceneParamService.list();
        return ConvertUtil.convert(paramList,SceneParamResp.class);

    }

    @Override
    public boolean paramDelete(String id) {
        return sceneParamService.removeById(id);
    }
}
