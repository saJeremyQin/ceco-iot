package com.ceco.channel.service;

import com.ceco.channel.thridPart.model.vo.BiorhythmVo;
import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.Biorhythm;

/**
 * @auther Dean
 * @Date 2021/11/9.
 */
public interface IApiBiorhythmService {
    /**
     * 保存或更新
     * @param biorhythmVo
     * @return
     */
    ResponseModel save(BiorhythmVo biorhythmVo);

    /**
     * 删除
     * @param biorhythmVo
     * @return
     */
    ResponseModel delete(BiorhythmVo biorhythmVo);

    /**
     * 修改节律信息
     * @param biorhythmVo
     * @return
     */
    ResponseModel update(BiorhythmVo biorhythmVo);

    /**
     * 查询
     * @param biorhythmVo
     * @return
     */
    ResponseModel queryOne(BiorhythmVo biorhythmVo);

    /**
     * 重置节律信息
     * @param biorhythmVo
     * @return
     */
    ResponseModel resetOne(BiorhythmVo biorhythmVo);

}
