package com.ceco.channel.admin.model.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;


@ApiModel("动态灯效参数响应请求对象")
@Data
public class SceneParamResp {


    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("动态灯效参数名称")
    private String name;


    @ApiModelProperty("参数内容")
    private String content;


    @ApiModelProperty("最后修改人")
    private String updateName;
    @ApiModelProperty("最后修改时间")
    private Date updateTime;
}
