package com.ceco.channel.service.thing;

import com.alibaba.fastjson.JSONObject;
import com.amazonaws.services.iot.client.*;
import com.amazonaws.services.iot.client.shadow.AwsIotDeviceCommand;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.service.thing.model.aws1.A1101;
import com.ceco.common.exception.BusinessException;
import com.ceco.configure.aws.AWSConfig;
import com.ceco.module.entity.device.DeviceInfo;
import com.ceco.module.service.IDeviceInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.iot.model.ListThingsRequest;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @auther Dean
 * @Date 2021/10/29.
 * AWS物联网平台
 */
@Service
@Slf4j
public class AWS1IThingControlImpl implements IThingControl {
    @Autowired
    private AWSConfig awsConfig;
    @Autowired
    private IDeviceInfoService iDeviceInfoService;

    @Autowired
    RedisTemplate redisTemplate;

    @Override
    public boolean thingSceneParamSet(DeviceParam deviceParam) {
        return false;
    }

    @Override
    public ThingModel thingPropertySearch(DeviceParam deviceParam) {


        String thingName = deviceParam.getDeviceName();
        String lastCmdStr =  redisTemplate.opsForValue().get(thingName) == null ? null :  redisTemplate.opsForValue().get(thingName).toString();
        A1101 a1101 = null;
        if(lastCmdStr !=null){
            a1101 = JSONObject.parseObject(lastCmdStr,A1101.class);
            a1101.getState().setReported(a1101.getState().getDesired());
        }

        AWSIotMqttClient awsIotMqttClient=awsConfig.getAWSIotMqttClient();
        AWSIotDevice device = new AWSIotDevice(thingName);
        try {
            awsIotMqttClient.attach(device);
            awsIotMqttClient.connect();
            String value = device.get();
            log.info("获取aws设备状态信息======>" + value);
            a1101 = JSONObject.parseObject(value,A1101.class);
            awsIotMqttClient.disconnect();

        } catch (AWSIotException e) {
            e.printStackTrace();
            throw  new BusinessException("device is not exists");
        }
        return a1101;
    }

    /**
     * aws 设备指令下发
     * @param deviceParam
     * @return
     */
    @Override
    public boolean thingPropertySet(DeviceParam deviceParam) {
        try {
            AWSIotMqttClient awsIotMqttClient=awsConfig.getAWSIotMqttClient();
            awsIotMqttClient.connect();
            String thingName = deviceParam.getDeviceName();
            String topic = "$aws/things/"+thingName+"/shadow/update";

            //暂时默认为灯，后续新增设备类型
            Map map=  A1101.outputData(JSONObject.parseObject(deviceParam.getParam()));

            String payload =JSONObject.toJSONString(map);

            redisTemplate.opsForValue().set(thingName,payload,300, TimeUnit.SECONDS);
            log.info("设置aws设备状态信息======》" +payload);
            awsIotMqttClient.publish(topic, AWSIotQos.QOS0, payload);

            AWSIotDevice device = new AWSIotDevice(thingName);

            awsIotMqttClient.attach(device);

            awsIotMqttClient.disconnect();
        } catch (AWSIotException e) {
            e.printStackTrace();
        }

        return  true;
    }



    /**
     * aws 设备状态查询
     * @param deviceParam
     * @return
     */
    @Override
    public Map thingStatusSearch(DeviceParam deviceParam) {

        DeviceInfo deviceInfo = iDeviceInfoService.getOne(new QueryWrapper<DeviceInfo>().lambda().eq(DeviceInfo::getSerialNo,deviceParam.getDeviceName()));
        Map statusMap=new HashMap();
        if(deviceInfo != null){
            statusMap.put("status",deviceInfo.getConnected());//1开机 ，3关机
        }else {
            statusMap.put("status",0);//1开机 ，3关机

        }
        //查询设备信息表
        return statusMap;
    }


}
