package com.ceco.channel.admin.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@ApiModel("动态灯效参数保存请求对象")
@Data
public class SceneParamSaveReq {

    @ApiModelProperty("动态灯效参数名称")
    @NotEmpty(message ="动态灯效参数名称不能为空")
    private String name;

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("动态灯效内容")
    private String content;




}
