package com.ceco.channel.app.controller;

import com.ceco.channel.admin.model.req.GuideListReq;
import com.ceco.channel.admin.model.resp.CountryResp;
import com.ceco.channel.admin.model.resp.GuideResp;
import com.ceco.channel.admin.model.resp.ModelResp;
import com.ceco.channel.admin.model.resp.SceneResp;
import com.ceco.channel.service.IApiCountryService;
import com.ceco.channel.service.IApiGuideService;
import com.ceco.channel.service.IApiModelService;
import com.ceco.channel.service.IApiSceneService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Api(tags = {"app配置控制类"})
@RequestMapping("/app/config")
public class ConfigController {

    @Autowired
    IApiCountryService apiCountryService;

    @Autowired
    IApiGuideService apiGuideService;

    @Autowired
    IApiModelService apiModelService;

    @Autowired
    IApiSceneService apiSceneService;

    @ApiOperation("查新国家信息")
    @GetMapping("/country")
    public List<CountryResp> country(){
        return apiCountryService.list();
    }

    @ApiOperation("查询引导页")
    @GetMapping("/guide")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "sysType", value = "系统类型 系统类型：1:ios2:安卓3:window4:其他", example = "1"),
    }
    )
    public List<GuideResp> guide(Integer sysType){
        GuideListReq req = new GuideListReq() ;
        req.setSysType(sysType);
        return apiGuideService.listBySys(req);
    }


    @ApiOperation("查询所有静态灯效配置信息")
    @GetMapping("/model/all")
    public List<ModelResp> model(){
        return apiModelService.list();
    }


    @ApiOperation("查询所有动态灯效配置信息")
    @GetMapping("/scene/all")
    public List<SceneResp> scene(){
        return apiSceneService.list();
    }


    @ApiOperation("查询单个设备静态灯效配置信息")
    @GetMapping("/model")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "deviceId", value = "设备Id", example = "1"),
    }
    )
    public List<ModelResp> model(String deviceId) {
        return apiModelService.listByDeviceId(deviceId);
    }


    @ApiOperation("后台单个设备动态灯效配置信息")
    @GetMapping("/scene")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "deviceId", value = "设备Id", example = "1"),
    }
    )
    public List<SceneResp> scene(String deviceId) {
        return apiSceneService.listByDeviceId(deviceId);
    }


}
