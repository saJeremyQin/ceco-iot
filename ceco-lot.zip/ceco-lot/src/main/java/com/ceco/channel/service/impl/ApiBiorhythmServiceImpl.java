package com.ceco.channel.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.thridPart.model.vo.BiorhythmVo;
import com.ceco.channel.service.IApiBiorhythmService;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.Biorhythm;
import com.ceco.module.entity.WeeklySchedule;
import com.ceco.module.service.IBiorhythmService;
import com.ceco.module.service.IWeeklyScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/9.
 */
@Service
public class ApiBiorhythmServiceImpl implements IApiBiorhythmService {
    @Autowired
    private IBiorhythmService iBiorhythmService;
    @Autowired
    private IWeeklyScheduleService iWeeklyScheduleService;


    /**
     * 保存生物节律信息：立即生效。如果有周定时规则，则将周定时失效
     * @param biorhythmVo
     * @return
     */
    @Override
    public ResponseModel save(BiorhythmVo biorhythmVo) {
        ValidatorUtils.validateEntity(biorhythmVo);
        //判断是否已存在
        Biorhythm biorhythm0=   iBiorhythmService.getOne(new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getAppUserId, biorhythmVo.getAppUserId()).eq(Biorhythm::getSerialNo,biorhythmVo.getSerialNo()));
        if(biorhythm0!=null){
            throw new BusinessException("该用户的该设备已有节律信息");//500
        }
        Biorhythm biorhythm = ConvertUtil.convert(biorhythmVo,Biorhythm.class);
        //创建生物节律规则. 立即生效. 如果之前已有周定时规则，则将其子状态全部变为0,周的总状态变为0
        biorhythm.setStatus(1);
                //将所有的周定时的日的状态变为0
                WeeklySchedule weeklySchedule=   iWeeklyScheduleService.getOne(new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId, biorhythmVo.getAppUserId()).eq(WeeklySchedule::getSerialNo,biorhythmVo.getSerialNo()));
               //将Object转为map 处理，再转为Object
                HashMap<String,Object> tempMap=ConvertUtil.convertToMap(weeklySchedule);
                for(Map.Entry<String,Object>entry:tempMap.entrySet()){
                    String value=(String)entry.getValue();
                    String value1= value.replace("\"subStatus\":\"1\"","\"subStatus\":\"0\"");
                    tempMap.put(entry.getKey(),value1);//
                }
        WeeklySchedule weeklySchedule1=ConvertUtil.convert(tempMap,WeeklySchedule.class);
        weeklySchedule1.setStatus(0);
        iWeeklyScheduleService.update(weeklySchedule1,new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getId,weeklySchedule.getId()));

        iBiorhythmService.save(biorhythm);//save后会自动返回主键id
        BiorhythmVo biorhythmVo1 =ConvertUtil.convert(biorhythm,BiorhythmVo.class);
        return ResponseModel.success(200,"用户节律信息创建",biorhythmVo1);

    }

    @Override
    public ResponseModel delete(BiorhythmVo biorhythmVo) {
         iBiorhythmService.removeById(biorhythmVo.getId());
         return ResponseModel.success(200,"删除用户节律信息",null);
    }

    @Override
    public ResponseModel queryOne(BiorhythmVo biorhythmVo) {
        Biorhythm  biorhythm=  iBiorhythmService.getOne(new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getId, biorhythmVo.getId()));
        BiorhythmVo biorhythmvo = ConvertUtil.convert(biorhythm,BiorhythmVo.class);
        return ResponseModel.success(200,"查询用户节律信息",biorhythmvo);
    }

    /**
     * 重置生物节律：将生物节律规则变为失效状态
     * @param biorhythmVo
     * @return
     */
    @Override
    public ResponseModel resetOne(BiorhythmVo biorhythmVo) {
        Biorhythm  biorhythm=  iBiorhythmService.getOne(new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getId, biorhythmVo.getId()));
        biorhythm.setSunrise(390);//日出6:30
        biorhythm.setNoon(690);//正午11:30
        biorhythm.setSunset(900);//日落17:00
        biorhythm.setSleep(1260);//睡眠21:00
        biorhythm.setStatus(0);
        iBiorhythmService.updateById(biorhythm);
        BiorhythmVo biorhythmVo1=ConvertUtil.convert(biorhythm,BiorhythmVo.class);
        return ResponseModel.success(200,"节律重置成功",biorhythmVo1);
    }

    /**
     * 更新生物节律信息：如果status=1，则立刻生效。将周定时规则变为失效
     * @param biorhythmVo
     * @return
     */
    @Override
    public ResponseModel update(BiorhythmVo biorhythmVo) {
        Biorhythm    biorhythm=ConvertUtil.convert(biorhythmVo,Biorhythm.class);
        Biorhythm  biorhythm0=  iBiorhythmService.getOne(new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getId, biorhythmVo.getId()));
        if(biorhythmVo.getStatus()==1){
            WeeklySchedule weeklySchedule=   iWeeklyScheduleService.getOne(new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getAppUserId, biorhythm0.getAppUserId()).eq(WeeklySchedule::getSerialNo,biorhythm0.getSerialNo()));
            //将Object转为map 处理，再转为Object
            HashMap<String,Object> tempMap=ConvertUtil.convertToMap(weeklySchedule);
            for(Map.Entry<String,Object>entry:tempMap.entrySet()){
                String value=(String)entry.getValue();
                String value1= value.replace("\"subStatus\":\"1\"","\"subStatus\":\"0\"");
                tempMap.put(entry.getKey(),value1);//
            }
            WeeklySchedule weeklySchedule1=ConvertUtil.convert(tempMap,WeeklySchedule.class);
            weeklySchedule1.setStatus(0);
            iWeeklyScheduleService.update(weeklySchedule1,new QueryWrapper<WeeklySchedule>().lambda().eq(WeeklySchedule::getId,weeklySchedule.getId()));
        }
        iBiorhythmService.updateById(biorhythm);
        //更新使用,则更新其他的状态
        //根据用户主键id更新用户weekly_schedule的设置
        Biorhythm  biorhythm1=  iBiorhythmService.getOne(new QueryWrapper<Biorhythm>().lambda().eq(Biorhythm::getId, biorhythmVo.getId()));
        BiorhythmVo biorhythmVo1=ConvertUtil.convert(biorhythm1,BiorhythmVo.class);
        return ResponseModel.success(200,"修改节律信息成功",biorhythmVo1);
    }
}
