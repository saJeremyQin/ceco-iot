package com.ceco.channel.app.controller;


import com.ceco.channel.app.model.req.*;
import com.ceco.channel.app.model.req.deviceUpdateReq.AL1LightStripThingModel;
import com.ceco.channel.app.model.resp.ConnectedDeviceResp;
import com.ceco.channel.app.model.resp.DeviceResp;
import com.ceco.channel.service.IApiDeviceControlService;
import com.ceco.channel.service.IApiDeviceService;
import com.ceco.channel.service.thing.ThingModel;
import com.ceco.common.utils.CurrentContext;
import com.ceco.common.utils.aws.IOTCoreUtils;
import com.ceco.common.utils.response.ResultResponse;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Api(tags = {"app端设备控制器"})
@RequestMapping("/app/device")
public class DeviceController {


    @Autowired
    IApiDeviceService apiDeviceService;
    @Autowired
    IApiDeviceControlService apiDeviceControlService;

    @Autowired
    private IOTCoreUtils iotCoreUtils;

    @GetMapping("/getProductKeys")
    @ApiOperation(value = "获取产品keys")
    public Object getProdcutKey(){
        Map map1 =new HashMap();
        map1.put("prodcutType","LightStrip");
        map1.put("productKey","a1rP2pEvHmo");
        map1.put("cloudBiz","AL1");
        map1.put("description","公版面板tg12-test");

        Map map2 =new HashMap();
        map2.put("prodcutType","LightStrip");
        map2.put("productKey","a1KN3RmnLWb");
        map2.put("cloudBiz","AL1");
        map2.put("description","ceco自定义面板tg-12灯带");

        Map map3 =new HashMap();
        map3.put("prodcutType","A1101");
        map3.put("productKey","A1101");
        map3.put("cloudBiz","AWS1");
        map3.put("description","Plush lamp");

        List list = new ArrayList();list.add(map1);list.add(map2);list.add(map3);
        return list;
    }



    @PostMapping("/register")
    @ApiOperation(value = "设备注册")
    public boolean register(@RequestBody DeviceRegisterReq req) {
        return apiDeviceService.register(req);
    }

    @PostMapping("/save")
    @ApiOperation(value = "设备修改")
    public boolean save(@RequestBody DeviceSaveReq req) {
        return apiDeviceService.save(req);
    }


    @PostMapping("/saveBySerial")
    @ApiOperation(value = "设备修改按照mac地址")
    public boolean save(@RequestBody DeviceSaveSerialNoReq req) {
        return apiDeviceService.save(req);
    }



    @GetMapping("/getConnectedDevice/{appUserId}")
    @ApiOperation(value = "已连接设备查询")
    public ConnectedDeviceResp getConnectedDevice(@PathVariable("appUserId") String appUserId){
        return apiDeviceService.getConnectedDevice(appUserId);
    }




    @PostMapping("/v1/thing/setProperties")
    @ApiOperation(value = "设备控制new")
    @ApiImplicitParams({
            @ApiImplicitParam(name="body",value="demo:1.白光{\"sn\":\"b4e8420fcce4\",\"cloudBiz\":\"AL1\",\"tempValue\":4700,\"brightValue\":92,\"switchMode\":1}" +
                    "2.彩光{\"sn\":\"b4e8420fcce4\",\"cloudBiz\":\"AL1\",\"colourData\":\"00d4d4\",\"brightValue\":83,\"switchMode\":2}"+
                    "3.场景{\"sn\":\"b4e8420fcce4\",\"cloudBiz\":\"AL1\",\"brightness\":15,\"sceneConfId\":\"1454634378620096514\",\"switchMode\":3}\n" +
                    "5.调节 6.调色板 {\"appUserId\":\"1450741156045770754\",\"switchMode\":6,\"cloudBiz\":\"AL1\",\"sn\":\"b4e8420fcce4\",\"colorPaletteData\":[{\"id\":\"0\",\"rgb\":\"111111\"},{\"id\":\"1\",\"rgb\":\"-\"},{\"id\":\"2\",\"rgb\":\"-\"},{\"id\":\"3\",\"rgb\":\"-\"},{\"id\":\"4\",\"rgb\":\"-\"},{\"id\":\"5\",\"rgb\":\"-\"},{\"id\":\"6\",\"rgb\":\"-\"},{\"id\":\"7\",\"rgb\":\"-\"},{\"id\":\"8\",\"rgb\":\"-\"},{\"id\":\"9\",\"rgb\":\"-\"}]}" +
                    "" )
    })
    public boolean thingPropertiesSet( @RequestBody String body){
        return apiDeviceControlService.thingPropertiesSetService(body);
    }

    @PostMapping("/v1/thing/getProperties")
    @ApiOperation(value = "获取设备属性状态")
    @ApiImplicitParam(name="body",value="demo:{\"sn\":\"b4e8420f7d94\",\"cloudBiz\":\"AL1\"}" )
    public ThingModel thingPropertiesGet(@RequestBody String body){
        return apiDeviceControlService.thingPropertiesGetService(body);
    }

    @PostMapping("/v1/thing/getStatus")
    @ApiOperation(value = "获取设备连接状态")
    @ApiImplicitParam(name="body",value="demo:{\"sn\":\"b4e8420f7d94\",\"cloudBiz\":\"AL1\"}" )
    @ApiResponses({
            @ApiResponse(code=0,message = "status=0设备未激活"),
            @ApiResponse(code=1,message = "status=1设备在线"),
            @ApiResponse(code=3,message = "status=3设备离线"),
            @ApiResponse(code=8,message = "status=8 设备禁用")
    })
    public Map thingStatusGet(@RequestBody String body){

        return apiDeviceControlService.thingStatusGetService(body);
    }


//    @PostMapping("/{sn}")
//    @ApiOperation(value = "更新设备状态")
//    public boolean updateDevice( @PathVariable String sn, @Validated @RequestBody AL1LightStripThingModel AL1LightStripThingModel){
//        return apiDeviceControlService.updateDevice(sn, AL1LightStripThingModel);
//    }

//    @GetMapping ("/{sn}/{productKey}")
//    @ApiOperation(value = "查询设备状态")
//    public Object queryDevice( @PathVariable String sn,@PathVariable String productKey){
//        return apiDeviceControlService.queryDevice(sn,productKey);
//    }


    //以下为给嵌入式 设备端调用------begin------------------
    @ApiOperation("aws创建物品")
    @PostMapping("/aws/thing/createThing")
    public boolean createAwsThing(String serialNo,String productKey){
        iotCoreUtils.createThing(serialNo,productKey);
        return true;
    }

    @ApiOperation("aws创建设备影子")
    @PostMapping("/aws/thing/createThingShadow")
    public boolean createThingShadow(String serialNo,String productKey){
        iotCoreUtils.createThingShadow(serialNo,productKey);
        return true;
    }

    @ApiOperation("aws证书附加物品")
    @PostMapping("/aws/thing/attachThing2Certificate")
    public boolean attachThing2Certificate(String principal,String serialNo){
        iotCoreUtils.attachThing2Certificate(principal,serialNo);
        return true;
    }

     //由硬件发送上行查询
    @ApiOperation("aws设备时间校准")
    @PostMapping("/aws/thing/serverTimeCalibration")
    public Map serverTimeCalibration(String serialNo){
        Map resMap=new HashMap();
        resMap.put("timestamp",apiDeviceService.getDeviceTime(serialNo));
        return resMap;
    }


    //以下为给嵌入式 设备端调用------end------------------


    @ApiOperation("删除设备信息")
    @GetMapping("/delete/{id}")
    public boolean delete(@PathVariable("id") String id){
        return apiDeviceService.delete(id);
    }


    @PostMapping("/listUserDevice")
    @ApiOperation(value = "查询用户所有设备信息")
    public List<DeviceResp> list(@RequestBody DeviceListReq req){
        return apiDeviceService.list(req);
    }


    @GetMapping("/detail/{id}")
    @ApiOperation(value = "查询设备详情")
    public DeviceResp detail(@PathVariable String id){
        return apiDeviceService.getDeviceDetail(id);
    }


}
