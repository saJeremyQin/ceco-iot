package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
@ApiModel("设备列表请求对象")
public class DeviceListReq {

    @ApiModelProperty("设备类型")
    private String productKey;

    @ApiModelProperty("用户id")
    private String appUserId;

    @ApiModelProperty("家庭id")
    private String homeId;

    @ApiModelProperty("房间id")
    private String roomId;

    @ApiModelProperty("查询类型:1：所有 2：家庭房间的 3：未绑定家庭房间的")
    private Integer queryType = 1;

}
