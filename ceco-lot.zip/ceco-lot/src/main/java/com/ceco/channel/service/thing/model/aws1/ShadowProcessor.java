package com.ceco.channel.service.thing.model.aws1;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.service.IApiDeviceInfoService;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.StringUtil;
import com.ceco.module.entity.device.DeviceInfo;
import com.ceco.module.service.IDeviceInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/26.
 */
@Component
@Slf4j
public  class ShadowProcessor {
    @Autowired
    private IApiDeviceInfoService iApiDeviceInfoService;

    @Autowired
    private IDeviceInfoService deviceInfoService;

    /**
     * http推数据方式
     * @param body
     */
    public void uploadDataByHttp(String body){
        Map mapbody= JSONObject.parseObject(body);
        Map stateMap=(Map)mapbody.get("state");
        Map desiredMap=(Map)stateMap.get("reported");
        if(desiredMap == null || desiredMap.isEmpty()){
             desiredMap=(Map)stateMap.get("desired");
        }

        //获取到具体设备类型的表，动态保存到指令数据表
        log.info("aws https 推送数据--------------------->>"+body);
        DeviceInfo deviceInfo= ConvertUtil.convert(desiredMap,DeviceInfo.class);//设备一些基本信息如 设备类型，设备编码，设备开关状态
        String version = desiredMap.get("version") == null  ? "" :desiredMap.get("version").toString();
        if(StringUtil.isNotEmpty(version)){
            deviceInfo.setFirmwareVersion(version);
        }
        Integer connected = desiredMap.get("connected") == null  ? 1 : Integer.parseInt( desiredMap.get("connected").toString());
        deviceInfo.setConnected(connected);
        deviceInfoService.update(deviceInfo, new QueryWrapper<DeviceInfo>().lambda().eq(DeviceInfo::getSerialNo,deviceInfo.getSerialNo()));

    }

    /**
     * SQS 拉数据方式
     * @param body
     */
    public void uploadDataBySQS(String body){
        //拉取消息数据，保存到搜索引擎
    }

}
