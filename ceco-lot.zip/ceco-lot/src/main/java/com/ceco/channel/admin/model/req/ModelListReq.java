package com.ceco.channel.admin.model.req;

import com.ceco.common.utils.BasePageReq;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("模式列表请求对象")
public class ModelListReq extends BasePageReq {
}
