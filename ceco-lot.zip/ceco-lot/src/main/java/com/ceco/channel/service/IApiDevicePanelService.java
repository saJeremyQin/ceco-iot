package com.ceco.channel.service;

import com.ceco.channel.admin.model.req.DevicePanelListReq;
import com.ceco.channel.admin.model.req.DevicePanelSaveReq;
import com.ceco.channel.admin.model.resp.DeviceModelPanelResp;
import com.ceco.channel.admin.model.resp.DevicePanelResp;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface IApiDevicePanelService {

    /**
     * 保存面板
     * @param req 面板信息保存请求对象
     * @return 操作结果
     */
    boolean save(DevicePanelSaveReq req);

    /**
     * 查询面板信息列表
     * @param req 面板信息列表请求对象
     * @return
     */
    PageInfo<DeviceModelPanelResp> list(DevicePanelListReq req);


    /**
     * 查询面板信息列表
     * @return
     */
    List<DeviceModelPanelResp> list();

    /**
     * 删除面板数据
     * @param deviceModelId 根据设备型号删除支持的面板
     * @return
     */
    boolean delete(String deviceModelId);
}
