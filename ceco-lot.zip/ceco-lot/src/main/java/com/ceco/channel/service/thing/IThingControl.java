package com.ceco.channel.service.thing;

import com.ceco.common.utils.response.ResultResponse;

import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/10/29.
 */
public interface IThingControl {

    boolean thingSceneParamSet(DeviceParam deviceParam);
    boolean thingPropertySet(DeviceParam deviceParam);
    Object thingPropertySearch(DeviceParam deviceParam);
    Map thingStatusSearch(DeviceParam deviceParam);
}
