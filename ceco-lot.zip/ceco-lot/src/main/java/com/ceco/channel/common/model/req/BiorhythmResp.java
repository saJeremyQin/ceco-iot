package com.ceco.channel.common.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * @auther Dean
 * @Date 2021/10/27.
 */
@Data
@ApiModel("生物节律返回对象")
public class BiorhythmResp {
    @ApiModelProperty("日出")
    private String sunrise;
    @ApiModelProperty("日落")
    private String sunset;
    @ApiModelProperty("正午")
    private String solar_noon;
    @ApiModelProperty("昼长")
    private String day_length;
    @ApiModelProperty("民间暮光开始")
    private String civil_twilight_begin;
    @ApiModelProperty("民间暮光结束")
    private String civil_twilight_end;
    @ApiModelProperty("航海黄昏开始")
    private String nautical_twilight_begin;
    @ApiModelProperty("航海黄昏结束")
    private String nautical_twilight_end;
    @ApiModelProperty("天文黄昏开始")
    private String astronomical_twilight_begin;
    @ApiModelProperty("天文黄昏结束")
    private String astronomical_twilight_end;


    public static void main(String[] args) {


        TimeZone.setDefault(TimeZone.getTimeZone("GMT+12"));


        Calendar calendar = Calendar.getInstance();// 获取实例

        DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd        hh:mm:ss");//构造格式化模板

        Date date = calendar.getTime(); //获取Date对象
        System.out.println(format1.format(date));
    }
}
