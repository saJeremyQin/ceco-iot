package com.ceco.channel.service;

import com.ceco.common.utils.response.ResponseModel;

import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/10.
 */
public interface IApiWeeklyScheduleService {
    ResponseModel saveWeeklyScheduleService(Map map);
    ResponseModel deleteWeekScheduleService(Map map);
    ResponseModel updateWeekScheduleService(Map map);
    ResponseModel queryOneWeekScheduleService(Map map);
}
