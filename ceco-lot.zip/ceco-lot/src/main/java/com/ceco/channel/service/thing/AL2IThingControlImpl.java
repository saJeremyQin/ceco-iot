package com.ceco.channel.service.thing;

import com.ceco.common.utils.response.ResultResponse;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/10/29.
 * 阿里云物联网平台(新)控制类
 */
@Service
public class AL2IThingControlImpl implements IThingControl {


    @Override
    public boolean thingSceneParamSet(DeviceParam deviceParam) {
        return false;
    }

    @Override
    public ThingModel thingPropertySearch(DeviceParam deviceParam) {
        return null;
    }

    @Override
    public boolean thingPropertySet(DeviceParam deviceParam) {
        System.out.println("AL2IThingControlImpl  invoke");
        return true;
    }

    @Override
    public Map thingStatusSearch(DeviceParam deviceParam) {
        return null;
    }
}
