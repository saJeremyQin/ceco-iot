package com.ceco.channel.admin.model.req;

import com.ceco.common.utils.BasePageReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("国家列表请求对象")
public class DeviceModelListReq extends BasePageReq {

    @ApiModelProperty("设备类型")
    private String deviceType;
}
