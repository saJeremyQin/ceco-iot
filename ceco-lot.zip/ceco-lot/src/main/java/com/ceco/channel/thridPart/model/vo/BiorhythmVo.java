package com.ceco.channel.thridPart.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @auther Dean
 * @Date 2021/10/27.
 */
@Data
@ApiModel
public class BiorhythmVo {
    @ApiModelProperty("主键id")
    private String id;
    @NotEmpty(message = "用户id不能为空")
    @ApiModelProperty("用户主键id")
    private String appUserId;
    @ApiModelProperty("日出时间")
    private Integer sunrise;
    @ApiModelProperty("正午时间")
    private Integer noon;
    @ApiModelProperty("日落时间")
    private Integer sunset;
    @ApiModelProperty("睡眠时间")
    private Integer sleep;
    @ApiModelProperty("启用状态")
    private Integer status;
    @ApiModelProperty("设备编码")
    private String serialNo;
}
