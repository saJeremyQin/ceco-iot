package com.ceco.channel.app.model.resp;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @auther Dean
 * @Date 2021/10/15.
 */
@Data
@ApiModel("设备控制响应请求对象")
public class DeviceControlResp {

}
