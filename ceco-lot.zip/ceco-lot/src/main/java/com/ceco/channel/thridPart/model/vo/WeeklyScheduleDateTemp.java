package com.ceco.channel.thridPart.model.vo;

import com.ceco.module.entity.WeeklySchedule;
import com.google.gson.Gson;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/9.
 */
@Data
@ApiModel
/**
 * 该对象转为 Map 则key 为String ，value 为json字符串
 */
public class WeeklyScheduleDateTemp {
    private Map monday=new HashMap();

    private Map tuesday=new HashMap();

    private Map wednesday=new HashMap();

    private Map thursday=new HashMap();

    private Map friday=new HashMap();

    private Map saturday=new HashMap();

    private Map sunday=new HashMap();


}
