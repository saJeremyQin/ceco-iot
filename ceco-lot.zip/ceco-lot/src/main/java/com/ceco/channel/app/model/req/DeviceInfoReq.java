package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @auther Dean
 * @Date 2021/11/24.
 */
@Data
public class DeviceInfoReq {
    @NotEmpty(message = "mac地址不能为空")
    private String serialNo;
    @NotEmpty(message = "产品类型不能为空")
    private String productKey;

    private Integer switchLed;

}
