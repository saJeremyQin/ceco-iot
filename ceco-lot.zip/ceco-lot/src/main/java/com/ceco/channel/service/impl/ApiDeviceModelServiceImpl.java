package com.ceco.channel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.DeviceModelListReq;
import com.ceco.channel.admin.model.req.DeviceModelSaveReq;
import com.ceco.channel.admin.model.resp.CountryResp;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.channel.admin.model.resp.DeviceTypeResp;
import com.ceco.channel.service.IApiDeviceModelService;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.PageUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.Country;
import com.ceco.module.entity.DeviceModel;
import com.ceco.module.service.IDeviceModelService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApiDeviceModelServiceImpl implements IApiDeviceModelService {

    @Autowired
    IDeviceModelService deviceModelService;

    @Override
    public boolean save(DeviceModelSaveReq req) {
        ValidatorUtils.validateEntity(req);
        DeviceModel deviceModel = ConvertUtil.convert(req,DeviceModel.class);
        return deviceModelService.saveOrUpdate(deviceModel);
    }

    @Override
    public PageInfo<DeviceModelResp> list(DeviceModelListReq req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<DeviceModel> deviceModelList = deviceModelService.list();
        PageInfo<DeviceModel> pageInfo = new PageInfo<>(deviceModelList);
        return PageUtils.pageInfo2Resp(pageInfo, DeviceModelResp.class);
    }

    @Override
    public List<DeviceModelResp> listAll(DeviceModelListReq req) {
        List<DeviceModel> deviceModelList = deviceModelService.list(new QueryWrapper<DeviceModel>().lambda().eq(StringUtil.isNotEmpty(req.getDeviceType()),DeviceModel::getDeviceType,req.getDeviceType()));
        List<DeviceModelResp> deviceModelRespList =  ConvertUtil.convert(deviceModelList,DeviceModelResp.class);
        return deviceModelRespList;
    }

    @Override
    public boolean delete(String id) {
        return deviceModelService.removeById(id);
    }

    @Override
    public List<DeviceTypeResp> listDeviceType() {
        return deviceModelService.listDeviceType();
    }
}
