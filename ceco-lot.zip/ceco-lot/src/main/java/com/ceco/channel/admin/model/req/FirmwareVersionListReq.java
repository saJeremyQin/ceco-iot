package com.ceco.channel.admin.model.req;

import com.ceco.common.utils.BasePageReq;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("固件列表")
public class FirmwareVersionListReq extends BasePageReq {
}
