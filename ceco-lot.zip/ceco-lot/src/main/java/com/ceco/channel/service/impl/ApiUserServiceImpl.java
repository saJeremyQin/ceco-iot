package com.ceco.channel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.AppUserListReq;
import com.ceco.channel.admin.model.req.UserLoginReq;
import com.ceco.channel.admin.model.resp.AppUserDetailResp;
import com.ceco.channel.admin.model.resp.AppUserDeviceResp;
import com.ceco.channel.admin.model.resp.AppUserResp;
import com.ceco.channel.admin.model.resp.UserLoginResp;
import com.ceco.channel.app.model.req.AppUserForgetPwdReq;
import com.ceco.channel.app.model.req.AppUserRegisterReq;
import com.ceco.channel.app.model.req.AppUserSaveReq;
import com.ceco.channel.app.model.req.CheckVerifyCodeReq;
import com.ceco.channel.app.model.resp.AliAppUserLoginResp;
import com.ceco.channel.service.IApiUserService;
import com.ceco.common.Enum.ResultCode;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.properties.UserProperties;
import com.ceco.common.utils.*;
import com.ceco.common.utils.encrypt.AES128;
import com.ceco.module.entity.AdminUser;
import com.ceco.module.entity.AppUser;
import com.ceco.module.service.IAdminUserService;
import com.ceco.module.service.IAppUserService;
import com.ceco.module.service.IDeviceService;
import com.ceco.module.service.IRoomDeviceService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;

import static com.ceco.common.utils.Constants.*;

@Slf4j
@Service
public class ApiUserServiceImpl implements IApiUserService {

    @Autowired
    IAdminUserService adminUserService;

    @Autowired
    IAppUserService appUserService;

    @Autowired
    IRoomDeviceService roomDeviceService;

    @Autowired
    IDeviceService deviceService;

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    MessageUtils messageUtils;


    /**
     * 用户从阿里云app登录
     * @param req
     * @return
     */
    @Override
    public Map aliApploginByPwd(UserLoginReq req) {
        AliAppUserLoginResp   aliAppUserLoginResp=ConvertUtil.convert(loginApp(req),AliAppUserLoginResp.class);
        //授权码。先采用用户的ID加密后的作为授权码
        String encryptUserId=null;
        try {
            encryptUserId= AES128.encrypt(aliAppUserLoginResp.getId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        aliAppUserLoginResp.setAuthCode(encryptUserId);
        Map mapRes=new HashMap();
        mapRes.put("AuthCode",encryptUserId+(DateUtils.format(new Date(),"MMss")));
        return mapRes;
    }

    /**
     * 用户登录管理后台
     * @param req
     * @return
     */
    @Override
    public UserLoginResp loginByPwd(UserLoginReq req) {

        AdminUser userEntity = adminUserService.getOne(
                new QueryWrapper<AdminUser>()
                        .lambda()
                        .eq(AdminUser::getPhone, req.getAccount())
        );
        String encrypt =null;
        try {
            encrypt = AES128.encrypt(req.getPassword());
        } catch (Exception e) {
            log.info("AES128加密出错,出错类容{}",e);
        }
        if (null == userEntity) {
            throw new BusinessException(messageUtils.getLocale("user.not.exists"));
        }
        if (!encrypt.equals(userEntity.getPassword())) {
            throw new BusinessException(messageUtils.getLocale("user.info.error"));
        }
        try {
            String userToken = this.generateToken(userEntity,"pc");
            UserLoginResp response = new UserLoginResp();
            response.setId(userEntity.getId());
            response.setUserToken(userToken);
            response.setExpire(UserProperties.getExpire());
            redisTemplate.opsForValue().set(userEntity.getId(),userToken);
            return response;
        } catch (NoSuchAlgorithmException | InvalidKeySpecException | DecoderException e) {
            throw new BusinessException(messageUtils.getLocale("system.error"));
        }
    }

    /**
     * 用户登录app
     * @param req
     * @return
     */
    @Override
    public UserLoginResp loginApp(UserLoginReq req) {
        AppUser appUser = appUserService.getOne(
                new QueryWrapper<AppUser>()
                        .lambda()
                        .eq(AppUser::getAccount, req.getAccount())
        );
        String encrypt =null;
        try {
            encrypt = AES128.encrypt(req.getPassword());
        } catch (Exception e) {
            log.info("AES128加密出错,出错类容{}",e);
        }
        if (null == appUser) {
            throw new BusinessException(messageUtils.getLocale("user.not.exists"));
        }
        if (!encrypt.equals(appUser.getPassword())) {
            throw new BusinessException(messageUtils.getLocale("user.info.error"));
        }
        try {
            String userToken = this.generateToken(appUser,"app");
            UserLoginResp response = new UserLoginResp();
            response.setId(appUser.getId());
            response.setUserToken(userToken);
            response.setExpire(UserProperties.getExpire());
            appUser.setLastLoginDate(new Date());
            appUserService.updateById(appUser);
            redisTemplate.opsForValue().set(appUser.getId(),userToken);
            return response;
        } catch (NoSuchAlgorithmException | InvalidKeySpecException | DecoderException e) {
            throw new BusinessException(messageUtils.getLocale("system.error"));
        }
    }

    private String generateToken(AppUser userEntity, String systemKey) throws NoSuchAlgorithmException, InvalidKeySpecException, DecoderException {
        if (StringUtils.isBlank(systemKey)) {
            systemKey = CurrentContext.getSystemKey();
        }
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(UserProperties.getPriKeyBytes());
        KeyFactory kf = KeyFactory.getInstance("RSA");
        String compactJws = Jwts.builder()
                .setSubject(userEntity.getId())
                .claim("nonce", UUID.randomUUID().toString())
                .claim("systemKey", systemKey)
                .claim("uid", userEntity.getId())
                .claim("uname", userEntity.getNickName())
                .claim("mobile", userEntity.getPhone())
                .setExpiration(DateTime.now().plusSeconds(UserProperties.getExpire()).toDate())
                .signWith(SignatureAlgorithm.RS256, kf.generatePrivate(spec))
                .compact();
        return compactJws;
    }


    private String generateToken(AdminUser userEntity, String systemKey) throws NoSuchAlgorithmException, InvalidKeySpecException, DecoderException {
        if (StringUtils.isBlank(systemKey)) {
            systemKey = CurrentContext.getSystemKey();
        }
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(UserProperties.getPriKeyBytes());
        KeyFactory kf = KeyFactory.getInstance("RSA");
        String compactJws = Jwts.builder()
                .setSubject(userEntity.getId())
                .claim("nonce", UUID.randomUUID().toString())
                .claim("systemKey", systemKey)
                .claim("uid", userEntity.getId())
                .claim("uname", userEntity.getName())
                .claim("mobile", userEntity.getPhone())
                .setExpiration(DateTime.now().plusSeconds(UserProperties.getExpire()).toDate())
                .signWith(SignatureAlgorithm.RS256, kf.generatePrivate(spec))
                .compact();
        return compactJws;
    }


    @Override
    public PageInfo<AppUserResp> appList(AppUserListReq req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<AppUser>  appUserList = appUserService.list(new QueryWrapper<AppUser>().lambda().like(StringUtils.isNotEmpty(req.getNickName()),AppUser::getNickName,req.getNickName()));
        List<AppUserResp> appUserRespList = ConvertUtil.convert(appUserList,AppUserResp.class);

        return new PageInfo<>(appUserRespList);
    }

    @Override
    public AppUserDetailResp appUserDetail(String id) {
        AppUser appUser = appUserService.getById(id);
        if(appUser !=null ){
            AppUserDetailResp appUserDetailResp = ConvertUtil.convert(appUser,AppUserDetailResp.class);
            List<AppUserDeviceResp> appUserDeviceRespList = deviceService.selectUserDetailDevice(appUser.getId());
            if(!CollectionUtils.isEmpty(appUserDeviceRespList)) {
                appUserDetailResp.setAppUserDeviceRespList(appUserDeviceRespList);
            }
            return appUserDetailResp;
        }else{
            throw  new BusinessException("用户信息不存在!");
        }


    }

    @Override
    public boolean saveUserInfo(AppUserSaveReq req) {

        ValidatorUtils.validateEntity(req);
        AppUser appUser = appUserService.getById(req.getId());
        if(appUser == null) {
            throw  new BusinessException("用户不存在!");
        }
        else{
            appUser.setNickName(req.getNickName());
            appUser.setHeadImg(req.getHeadImg());
            return appUserService.updateById(appUser);
        }
    }



    @Override
    public UserLoginResp register(AppUserRegisterReq req)  {
        ValidatorUtils.validateEntity(req.getAccount());
        UserLoginResp response = new UserLoginResp();
        String code = redisTemplate.opsForValue().get(VERIFY_USER_CODE + "_"+req.getAccount()) == null ? "" : redisTemplate.opsForValue().get(VERIFY_USER_CODE + "_"+req.getAccount()).toString();
        if(!code.equals(req.getVerifyCode())){
            throw  new BusinessException("验证码不一致");
        }
        AppUser appUser = appUserService.getOne(new QueryWrapper<AppUser>().lambda().eq(AppUser::getAccount,req.getAccount()));
        if(appUser !=null ){
            throw  new BusinessException("当前账号已存在！");
        }
        appUser = ConvertUtil.convert(req,AppUser.class);
        if(req.getSource().intValue() == Constants.OVERSEAS_APP_USER.intValue()){
            appUser.setEmail(req.getAccount());
        }else{
            appUser.setPhone(req.getAccount());
        }
        try {
           String encrypt = AES128.encrypt(req.getPassword());
           appUser.setPassword(encrypt);
        } catch (Exception e) {
            log.info("AES128加密出错,出错类容{}",e);
        }
        boolean result = appUserService.save(appUser);
        if(result){
            redisTemplate.delete(VERIFY_USER_CODE + "_"+req.getAccount());
            String userToken = null;
            try {
                userToken = this.generateToken(appUser,"app");
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (InvalidKeySpecException e) {
                e.printStackTrace();
            } catch (DecoderException e) {
                e.printStackTrace();
            }
            response.setId(appUser.getId());
            response.setUserToken(userToken);
            response.setExpire(UserProperties.getExpire());

        }
        return response;
    }

    @Override
    public boolean forgetPassword(AppUserForgetPwdReq req) {
        ValidatorUtils.validateEntity(req);

        String code = redisTemplate.opsForValue().get(VERIFY_USER_CODE + "_"+req.getAccount()) == null ? "" : redisTemplate.opsForValue().get(VERIFY_USER_CODE + "_"+req.getAccount()).toString();
        if(!code.equals(req.getVerifyCode())){
            throw  new BusinessException("验证码不一致");
        }
        AppUser appUser = appUserService.getOne(new QueryWrapper<AppUser>().lambda().eq(AppUser::getAccount,req.getAccount()));
        if(appUser == null) {
            throw new BusinessException("用户不存在!");
        }
        try {
            String encrypt = AES128.encrypt(req.getPassword());
            appUser.setPassword(encrypt);
        } catch (Exception e) {
            log.info("AES128加密出错,出错类容{}",e);
        }
        boolean result =   appUserService.updateById(appUser);
        if(result){
            redisTemplate.delete(VERIFY_USER_CODE + "_"+req.getAccount());
        }
        return result;

    }

    @Override
    public boolean checkVerifyCode(CheckVerifyCodeReq req) {
        ValidatorUtils.validateEntity(req);
        String code = redisTemplate.opsForValue().get(VERIFY_USER_CODE + "_"+req.getAccount()) == null ? "" : redisTemplate.opsForValue().get(VERIFY_USER_CODE + "_"+req.getAccount()).toString();
        return code.equals(req.getVerifyCode());
    }
}
