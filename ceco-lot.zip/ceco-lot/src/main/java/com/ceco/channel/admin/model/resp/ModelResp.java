package com.ceco.channel.admin.model.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Date;
import java.util.List;

@ApiModel("模式返回对象")
@Data
public class ModelResp {

    @ApiModelProperty("模式名称")
    private String name;
    @ApiModelProperty("图片地址")
    private String imgUrl;

    @ApiModelProperty("白光亮度值")
    private String brightnessValue;
    @ApiModelProperty("白光")

    private String colorTemperatureValue;
    @ApiModelProperty("彩光值")
    private String hsvValue;

    @ApiModelProperty("彩光亮度值")
    private String hsvBrightnessValue;

    @ApiModelProperty("创建时间")
    private Date createTime;
    @ApiModelProperty("创建人")
    private String createName;

    @ApiModelProperty("最后修改人")
    private String updateName;
    @ApiModelProperty("最后修改时间")
    private Date updateTime;

    @ApiModelProperty("id ")
    private String id;

    @ApiModelProperty("设备类型")
    private String deviceType;

    @ApiModelProperty("支持的的设备类型对象")
    private List<DeviceModelResp> deviceModelRespList;
}
