package com.ceco.channel.admin.model.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;


@ApiModel("动态灯效响应请求对象")
@Data
public class SceneResp{


    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("动态灯效名称")
    private String name;

    @ApiModelProperty("图片地址")
    private String imgUrl;

    @ApiModelProperty("设备类型")
    private String deviceType;

    @ApiModelProperty("支持的的设备类型对象")
    private List<DeviceModelResp> deviceModelRespList;

    @ApiModelProperty("参数Id")
    private String paramId;

    @ApiModelProperty("参数内容")
    private String paramContent;

    @ApiModelProperty("最后修改人")
    private String updateName;
    @ApiModelProperty("最后修改时间")
    private Date updateTime;
}
