package com.ceco.channel.service.impl;


import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.iot.model.v20180120.QueryDevicePropertyStatusRequest;
import com.aliyuncs.iot.model.v20180120.QueryDevicePropertyStatusResponse;
import com.aliyuncs.iot.model.v20180120.SetDevicePropertyRequest;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.app.model.req.deviceUpdateReq.AL1LightStripThingModel;
import com.ceco.channel.service.IApiDeviceControlService;
import com.ceco.channel.service.thing.AL1IThingControlImpl;
import com.ceco.channel.service.thing.AWS1IThingControlImpl;
import com.ceco.channel.service.thing.DeviceParam;
import com.ceco.channel.service.thing.ThingModel;
import com.ceco.channel.thridPart.model.vo.SceneParamCmdVo;
import com.ceco.channel.thridPart.model.vo.ScheduleCmdParam;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.Constants;
import com.ceco.common.utils.DateUtils;
import com.ceco.common.utils.GsonUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.common.utils.aliyun.CNIOTDeviceUtils;
import com.ceco.common.utils.aliyun.USIOTDeivceUtils;
import com.ceco.common.utils.response.ResultResponse;
import com.ceco.module.entity.*;
import com.ceco.module.service.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;


/**
 * @auther Dean
 * @Date 2021/10/18.
 */
@Service
@Slf4j
public class ApiDeviceControlServiceImpl implements IApiDeviceControlService {


    @Autowired
    private USIOTDeivceUtils usiotDeivceUtils;
    @Autowired
    private CNIOTDeviceUtils cniotDeviceUtils;

    @Autowired
    private DefaultAcsClient foreignIotClient;

    @Autowired
    private AL1IThingControlImpl aL1IThingControlImpl;

    @Autowired
    private IDeviceService iDeviceService;

    @Autowired
    private ISceneParamService iSceneParamService;

    @Autowired
    private IModelConfService modelConfService;
    @Autowired
    private IColorPaletteService iColorPaletteService;

    @Autowired
    private IScheduleService scheduleService;

    @Autowired
    private IScheduleTimeService scheduleTimeService;


    @Autowired
    private AWS1IThingControlImpl aws1IThingControlmpl;

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public boolean thingSceneParamSetService(String body) {
        return false;
    }

    @Override
    public boolean thingWebsocketPropertiesSetService(String body) {
        return false;
    }

    /**
     * 获取设备连接状态
     * @param body
     * @return
     */
    @Override
    public Map thingStatusGetService(String body) {
        Gson gson =new Gson();
        Map bodyMap =gson.fromJson(body,Map.class);
        String cloudBiz=(String)bodyMap.get("cloudBiz");



        Map mapResponse=null;
        String sn = (String)bodyMap.get("sn");
        if("-1".equals(sn)){
            mapResponse = new HashMap();
            mapResponse.put("status",1);
            return mapResponse;
        }
        if(cloudBiz.equals("AL1")){
            DeviceParam deviceParam=getDeviceParam(body);
            mapResponse= aL1IThingControlImpl.thingStatusSearch(deviceParam);

        }else if(cloudBiz.equals("AL2")){
            //阿里云物联网平台控制逻辑
            throw new BusinessException("thingStatusGet--------阿里云物联网平台暂未接入");
        }else if(cloudBiz.equals("AWS1")){
            //AWS IOT 平台控制逻辑
            Map mapBody=JSONObject.parseObject(body);
            DeviceParam deviceParam =new DeviceParam();
            deviceParam.setDeviceName((String)mapBody.get("sn"));
            mapResponse=aws1IThingControlmpl.thingStatusSearch(deviceParam);
        }else{
            throw new BusinessException("thingPropertiesSetService---该IOT云厂商不存在");
        }
        return mapResponse;
    }


    /**
     * 获取设备属性状态
     * @param body
     * @return
     */
    @Override
    public ThingModel thingPropertiesGetService(String body) {
        Gson gson =new Gson();
        Map mapBody=gson.fromJson(body,Map.class);
        String cloudBiz=(String)mapBody.get("cloudBiz");

        if(cloudBiz.equals("AL1")){
            DeviceParam deviceParam=getDeviceParam(body);
           return  aL1IThingControlImpl.thingPropertySearch(deviceParam);

        }else if (cloudBiz.equals("AL2")){
            throw new BusinessException("thingPropertiesGetService------该IOT云厂商不存在");
        }else if(cloudBiz.equals("AWS1")){
            Map mapBody1=JSONObject.parseObject(body);
            DeviceParam deviceParam =new DeviceParam();
            deviceParam.setDeviceName((String)mapBody1.get("sn"));

            return aws1IThingControlmpl.thingPropertySearch(deviceParam);
        }else{
            throw new BusinessException("thingPropertiesGetService------该IOT云厂商不存在");
        }

    }

    /**
     * 设置设备状态
     * 设备控制由 controller发起调用，也由
     * @param body
     * @return
     */
    @Override
    public boolean thingPropertiesSetService(String body) {
        //参考文档 ：https://living.aliyun.com/
        Gson gson =new Gson();
        Map bodyMap =gson.fromJson(body,Map.class);
        String cloudBiz=(String)bodyMap.get("cloudBiz");

        if(cloudBiz.equals("AL1")){
            DeviceParam deviceParam=getDeviceParam(body);
            aL1IThingControlImpl.thingPropertySet(deviceParam);

        }else if(cloudBiz.equals("AL2")){
            //阿里云物联网平台控制逻辑
            throw new BusinessException("阿里云物联网平台暂未接入");
        }else if(cloudBiz.equals("AWS1")){
            DeviceParam deviceParam=getDeviceParam(body);
            aws1IThingControlmpl.thingPropertySet(deviceParam);
            //AWS IOT 平台控制逻辑
        }else{
            throw new BusinessException("thingPropertiesSetService---该IOT云厂商不存在");
        }

        return true;

    }
















    /**
     * 获取deviceParam
     * @param body
     * @return
     */
    @Override
    public  DeviceParam getDeviceParam(String body){
        Map bodyMap =JSONObject.parseObject(body);

        String cloudBiz=(String)bodyMap.get("cloudBiz");
        String sn=(String)bodyMap.get("sn");
        String appUserIdX=(String)bodyMap.get("appUserId");
        Integer  switchMode= Integer.parseInt(bodyMap.get("switchMode") == null ? "-1":bodyMap.get("switchMode").toString());
        if(StringUtils.isEmpty(sn)||StringUtils.isEmpty(cloudBiz)){
            throw new BusinessException("缺少参数sn或cloudBiz");
        }
        String cloudeToken="";
        if(cloudBiz.equals("AL1")){
//          Object o=   redisTemplate.opsForValue().get("aliCloudToken");
//          if(o==null){
              //缓存中过期
              cloudeToken= aL1IThingControlImpl.getCloudToken();
//              redisTemplate.opsForValue().set("aliCloudToken",cloudeToken, Constants.ALIYUN_IOT_CLOUDTOKEN_EXPIRETIME, TimeUnit.SECONDS);
//          }else{
//              //redis保存的是字符串，直接转换
//              cloudeToken=(String)o;
//          }

        }

        DeviceParam deviceParam = new DeviceParam();
        deviceParam.setCloudToken(cloudeToken);
        deviceParam.setDeviceName(sn);
        //查询DB 获取productKey------------------------------------
        Device device= iDeviceService.getOne(new QueryWrapper<Device>().lambda().eq(Device::getSerialNo,sn).eq(Device::getAppUserId,appUserIdX));
        if(device==null){
            throw new BusinessException("该设备未绑定用户");
        }
        String productKey=device.getProductKey();
        deviceParam.setProductKey(productKey);  //a1KN3RmnLWb 测试的灯


        Gson gson = new Gson();
       // Long switchMode=Long.parseLong((String)bodyMap.get("switchMode"));
        if(switchMode!=null){

            if(switchMode==0){
                //彩光
            }

            if(switchMode==1){
                //白光
            }

            if(switchMode == 2){
                //静态光效
                String sceneConfId=(String)bodyMap.get("sceneConfId");
                ModelConf modelConf =  modelConfService.getById(sceneConfId);

                bodyMap.put("brightValue",modelConf.getBrightnessValue());
                bodyMap.put("tempValue",modelConf.getColorTemperatureValue());
                bodyMap.put("colourData",modelConf.getHsvValue());

            }

            if(switchMode==3){
                //动态光效
                String sceneConfId=(String)bodyMap.get("sceneConfId");
                //如果是设置场景的模式
                String   sceneParam= iSceneParamService.selectSceneParamBySceneConfIdService(sceneConfId);
                Map<String,Object>  paramMap= JSONObject.parseObject(sceneParam);
                SceneParamCmdVo sceneParamCmdVo = new SceneParamCmdVo();
                if(paramMap.get("colorList") !=null){
                    List<JSONObject> list = (List) paramMap.get("colorList");
                    String colorList = list.stream().map(jsonObject -> jsonObject.get("value")== null ? "" :jsonObject.get("value").toString()).collect(Collectors.joining("|"));
                    sceneParamCmdVo.setColorList(colorList);
                }
                if(paramMap.get("timeRange") !=null){
                    List<JSONObject> list = (List) paramMap.get("timeRange");
                    String timeRange = list.stream().map(jsonObject -> jsonObject.get("value")== null ? "" :jsonObject.get("value").toString()).findFirst().orElseGet(null);
                    sceneParamCmdVo.setTimeRange(timeRange);
                }
                if(paramMap.get("showTimes") !=null){
                    List<JSONObject> list = (List) paramMap.get("showTimes");
                    String showTimes = list.stream().map(jsonObject -> jsonObject.get("value")== null ? "" :jsonObject.get("value").toString()).collect(Collectors.joining("|"));
                    sceneParamCmdVo.setShowTimes(showTimes);
                }
                if(paramMap.get("intervalTimes") !=null){
                    List<JSONObject> list = (List) paramMap.get("intervalTimes");
                    String intervalTimes = list.stream().map(jsonObject -> jsonObject.get("value")== null ? "" :jsonObject.get("value").toString()).collect(Collectors.joining("|"));
                    sceneParamCmdVo.setIntervalTimes(intervalTimes);
                }
                if(paramMap.get("status") !=null){
                    List<JSONObject> list = (List) paramMap.get("status");
                    String status = list.stream().map(jsonObject -> jsonObject.get("value")== null ? "" :jsonObject.get("value").toString()).collect(Collectors.joining("|"));
                    sceneParamCmdVo.setStatus(status);
                }
                if(StringUtil.isEmpty(sceneParamCmdVo.getShowTimes())){
                    sceneParamCmdVo.setShowTimes("0");
                }
                if(StringUtil.isEmpty(sceneParamCmdVo.getTimeRange())){
                    sceneParamCmdVo.setTimeRange("0");
                }else {
                    if(StringUtil.isEmpty(sceneParamCmdVo.getIntervalTimes()) && sceneParamCmdVo.getTimeRange().indexOf("|" ) ==-1){
                        Integer size = ( (List) paramMap.get("colorList")).size();
                        Integer range =  Integer.parseInt(sceneParamCmdVo.getTimeRange());
                        sceneParamCmdVo.setIntervalTimes( (range /(size -1)) +"");
                    }
                }
                if(StringUtil.isEmpty(sceneParamCmdVo.getIntervalTimes())){
                    sceneParamCmdVo.setIntervalTimes("100");
                }
                if(StringUtil.isEmpty(sceneParamCmdVo.getStatus())){
                    sceneParamCmdVo.setStatus("3");
                }

                bodyMap.put("sceneData",JSONObject.toJSON(sceneParamCmdVo));
                bodyMap.remove("sceneConfId");
            }

            if(switchMode==4){
                //音乐
            }

            //调节、控制
            if(switchMode==5){
                String time = bodyMap.get("time") == null ? DateUtils.format(new Date(),DateUtils.NORM_DATETIME_PATTERN) : bodyMap.get("time").toString();
                String appUserId = (String)bodyMap.get("appUserId");
                List<ScheduleCmdParam> scheduleCmdParamList = new ArrayList<>();
                Map controlDataMap = new HashMap();
                List<Schedule> scheduleList = scheduleService.list(new QueryWrapper<Schedule>().lambda().eq(Schedule::getAppUserId,appUserId).eq(Schedule::getDeviceId,device.getId()).eq(Schedule::getStatus,1));
                if(CollectionUtil.isNotEmpty(scheduleList)) {
                    List<ScheduleTime> scheduleTimeList = scheduleTimeService.list(new QueryWrapper<ScheduleTime>().lambda().in(ScheduleTime::getScheduleId, scheduleList.stream().map(Schedule::getId).collect(Collectors.toList())));
                    Map<String, List<ScheduleTime>> scheduleTimeMap = scheduleTimeList.stream().collect(Collectors.groupingBy(ScheduleTime::getScheduleId));
                    Schedule schedule = scheduleList.stream().findFirst().get();
                    if (schedule.getType() == 0) {
                        ScheduleCmdParam scheduleCmdParam = new ScheduleCmdParam();
                        scheduleCmdParam.setWeekDays("0123456");
                        scheduleCmdParam.setColor("#f8d4bc|#ff850d|#e0e5fb");
                        List<ScheduleTime> scheduleTimeList1 = scheduleTimeMap.get(schedule.getId());
                        scheduleCmdParam.setTimes(scheduleTimeList1.stream().map(scheduleTime -> String.valueOf(scheduleTime.getTime())).collect(Collectors.joining("|")));
                        scheduleCmdParam.setActions(scheduleTimeList1.stream().map(scheduleTime -> String.valueOf(scheduleTime.getAction())).collect(Collectors.joining("|")));
                        scheduleCmdParamList.add(scheduleCmdParam);
                    } else {
                        scheduleList.forEach(schedule1 -> {
                            if (scheduleTimeMap.get(schedule1.getId()) != null) {
                                List<ScheduleTime> scheduleTimeList1 = scheduleTimeMap.get(schedule1.getId());
                                ScheduleCmdParam scheduleCmdParam = new ScheduleCmdParam();
                                scheduleCmdParam.setWeekDays(scheduleTimeList1.stream().map(scheduleTime -> String.valueOf(scheduleTime.getDayOfWeek())).collect(Collectors.joining("")));
                                scheduleCmdParam.setTimes(scheduleTimeList1.stream().map(scheduleTime -> String.valueOf(scheduleTime.getTime())).collect(Collectors.joining("|")));
                                scheduleCmdParam.setActions(scheduleTimeList1.stream().map(scheduleTime -> String.valueOf(scheduleTime.getAction())).collect(Collectors.joining("|")));
                                scheduleCmdParam.setColor("#ff850d");
                                scheduleCmdParamList.add(scheduleCmdParam);

                            }
                        });
                    }
                }
                controlDataMap.put("currentTime", time);
                controlDataMap.put("scheduleList",scheduleCmdParamList);
              //保存到固件
              //段工需要开发代码的地方
//                String switchLedTime=(String)bodyMap.get("switchLedTime");
//                String dateRange=(String)bodyMap.get("dateRange");
//                long switchLedStatus=((Long)bodyMap.get("switchLedStatus"));
//                controlDataMap.put("switchLedTime",switchLedTime);
//                controlDataMap.put("dateRange",dateRange);
//                controlDataMap.put("switchLedStatus",switchLedStatus);
//                SimpleDateFormat df = new SimpleDateFormat("HH:mm");
//                controlDataMap.put("currentTime",df.format(new Date()));
//
//                bodyMap.remove("switchLedTime");
//                bodyMap.remove("dateRange");
//                bodyMap.remove("switchLedStatus");


                 bodyMap.put("controlData", JSONObject.toJSON(controlDataMap));

            }

            if(switchMode==6){
                //保存指令并且控制设备
                //查询接口单独调用调色板控制器
//                ColorPalette colorPalette =new ColorPalette();
//                String appUserId=(String)bodyMap.get("appUserId");
//                String serialNo=(String)bodyMap.get("sn");
//                colorPalette.setAppUserId(appUserId);
//                colorPalette.setSerialNo(serialNo);
//                //List listData=(List)bodyMap.get("colorPaletteData");
//
//                ColorPalette colorPalette1=   iColorPaletteService.getOne(new QueryWrapper<ColorPalette>().lambda().eq(ColorPalette::getAppUserId,appUserId).eq(ColorPalette::getSerialNo,serialNo));
//                JSONArray jsonArray = JSONObject.parseArray(colorPalette1.getColorPaletteData());
//                Map<String,Object> paramMap = new HashMap<>();
//                StringBuffer idBuffer = new StringBuffer();
//                StringBuffer rgbBuffer = new StringBuffer();
//                for(int i =0 ;i <jsonArray.size();i ++){
//                        idBuffer.append(jsonArray.getJSONObject(i).get("id")).append("|");
//                        rgbBuffer.append(jsonArray.getJSONObject(i).get("rgb")).append("|");
//
//                }
//
//                paramMap.put("id",idBuffer.substring(0,idBuffer.lastIndexOf("|")));
//                paramMap.put("rgb",rgbBuffer.substring(0,rgbBuffer.lastIndexOf("|")));
//
//                bodyMap.remove("appUserId");
//                bodyMap.put("colorPaletteData",JSONObject.toJSON(paramMap));
            }


        }




        bodyMap.remove("cloudBiz");
        bodyMap.remove("sn");


        String param=gson.toJson(bodyMap);
        log.info("发送指令参数-----》 "+param);
        deviceParam.setParam(param);
        return deviceParam;
    }

    /**
     * 物联网平台-------更新设备状态
     * @param deviceName
     * @param AL1LightStripThingModel
     * @return
     */
    @Override
    public boolean updateDevice(String deviceName,  AL1LightStripThingModel AL1LightStripThingModel) {
        String locale= AL1LightStripThingModel.getLocale();//获取地域

        if(locale.equals("us")){
           return  usiotDeivceUtils.usControlDevice (deviceName, AL1LightStripThingModel);

        }else if(locale.equals("cn")){
            //其余地区、中国等
            return  cniotDeviceUtils.cnControlDevice(deviceName, AL1LightStripThingModel);

        }else{
            throw  new BusinessException("全球未开通此区域IOT服务");
        }

    }
    /**
     * 物联网平台-------更新设备状态
     * @param deviceName
     * @return
     */
    @Override
    public Object queryDevice(String deviceName,String productKey) {
        com.aliyuncs.iot.model.v20180120.SetDevicePropertyResponse response;
        com.aliyuncs.iot.model.v20180120.SetDevicePropertyRequest setDevicePropertyRequest = new SetDevicePropertyRequest();
        String deviceId= cniotDeviceUtils.getDeviceId(deviceName);
        setDevicePropertyRequest.setIotId(deviceId);
        Map map=  queryDevicePropertyStatus(deviceId,productKey,deviceName);

        return map;
    }
    public Map queryDevicePropertyStatus(String iotId, String productKey,
                                                  String deviceName) {
        List resList=new ArrayList();
        QueryDevicePropertyStatusResponse response = null;
        QueryDevicePropertyStatusRequest request = new QueryDevicePropertyStatusRequest();
        request.setDeviceName(deviceName);
        request.setIotId(iotId);
        request.setProductKey(productKey);
        Map mapRes = new HashMap();
        try {
            response = foreignIotClient.getAcsResponse(request);

            if (response.getSuccess() != null && response.getSuccess()) {
                resList=response.getData().getList();
                if(resList!=null&&resList.size()>0){

                    Gson gson =new Gson();
                    for(Object o: resList){
                        String json =gson.toJson(o);

                        Map map0=gson.fromJson(json,Map.class);
                        mapRes.put(map0.get("identifier"),map0.get("value"));
                    }
                }
            } else {

                throw  new BusinessException("设备属性查询失败");
            }
            return mapRes;

        } catch (ClientException e) {
            e.printStackTrace();
            throw  new BusinessException("设备属性查询失败");
        }

    }
}
