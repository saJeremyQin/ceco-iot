package com.ceco.channel.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.DevicePanelListReq;
import com.ceco.channel.admin.model.req.DevicePanelSaveReq;
import com.ceco.channel.admin.model.resp.DeviceModelPanelResp;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.channel.admin.model.resp.DevicePanelResp;
import com.ceco.channel.admin.model.resp.SceneResp;
import com.ceco.channel.service.IApiDevicePanelService;
import com.ceco.common.Enum.EnumDevicePanelType;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.PageUtils;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.*;
import com.ceco.module.service.IDeviceModelService;
import com.ceco.module.service.IDevicePanelService;
import com.ceco.module.service.IPanelSupportDeviceService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ApiDevicePanelServiceImpl implements IApiDevicePanelService {

    @Autowired
    IDevicePanelService devicePanelService;

    @Autowired
    IDeviceModelService deviceModelService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean save(DevicePanelSaveReq req) {
        ValidatorUtils.validateEntity(req);
        List<DevicePanel> devicePanelList = new ArrayList<>();
        devicePanelService.remove(new QueryWrapper<DevicePanel>().lambda().eq(DevicePanel::getDeviceModelId,req.getDeviceModeId()));
        req.getSupportPanelList().forEach(supportPanel->{
            DevicePanel devicePanel = new DevicePanel();
            devicePanel.setSupportPanel(supportPanel);
            devicePanel.setPanelName(EnumDevicePanelType.getTextByValue(supportPanel));
            devicePanel.setDeviceModelId(req.getDeviceModeId());
            devicePanelList.add(devicePanel);
        });
        return devicePanelService.saveBatch(devicePanelList);
    }

    @Override
    public PageInfo<DeviceModelPanelResp> list(DevicePanelListReq req) {
        List<DevicePanel> devicePanelList = devicePanelService.list();
        PageInfo<DeviceModelPanelResp> respPageInfo = new PageInfo<>();

        if(!CollUtil.isEmpty(devicePanelList)) {
            List<String> deviceModelIdList = devicePanelList.stream().map(DevicePanel::getDeviceModelId).collect(Collectors.toList());
            Map<String,List<DevicePanel> > devicePanelMap = devicePanelList.stream().collect(Collectors.toMap(DevicePanel::getDeviceModelId, devicePanel-> Lists.newArrayList(devicePanel),(List<DevicePanel> newValueList, List<DevicePanel> oldValueList) ->
            {
                oldValueList.addAll(newValueList);
                return oldValueList;
            }));
            PageHelper.startPage(req.getPageNum(), req.getPageSize());
            List<DeviceModel> deviceModelList = deviceModelService.list(new QueryWrapper<DeviceModel>().lambda().in(DeviceModel::getId,deviceModelIdList));
            PageInfo<DeviceModel> pageInfo = new PageInfo<>(deviceModelList);
            Page<DeviceModelPanelResp> page = new Page<>(pageInfo.getPageNum(), pageInfo.getPageSize());
            page.setTotal(pageInfo.getTotal());
            if(!CollUtil.isEmpty(deviceModelList)){
                deviceModelList.forEach(deviceModel -> {
                    DeviceModelPanelResp deviceModelPanelResp = new DeviceModelPanelResp();
                    deviceModelPanelResp.setDeviceType(deviceModel.getDeviceType());
                    deviceModelPanelResp.setDeviceModelId(deviceModel.getId());
                    deviceModelPanelResp.setDeviceModelName(deviceModel.getModelName());
                    List<DevicePanel> devicePanels = devicePanelMap.get(deviceModel.getId());
                    if(CollUtil.isNotEmpty(devicePanels)){
                        List<DevicePanelResp> devicePanelRespList = ConvertUtil.convert(devicePanels,DevicePanelResp.class);
                        deviceModelPanelResp.setDevicePanelRespList(devicePanelRespList);
                    }
                    page.add(deviceModelPanelResp);
                });
            }
            respPageInfo = new PageInfo<>(page, pageInfo.getNavigatePages());
        }
        return respPageInfo;
    }

    @Override
    public List<DeviceModelPanelResp> list() {
        List<DevicePanel> devicePanelList = devicePanelService.list();
        List<DeviceModelPanelResp> deviceModelPanelRespList = new ArrayList<>();
        if(!CollUtil.isEmpty(devicePanelList)) {
            List<String> deviceModelIdList = devicePanelList.stream().map(DevicePanel::getDeviceModelId).collect(Collectors.toList());
            Map<String,List<DevicePanel> > devicePanelMap = devicePanelList.stream().collect(Collectors.toMap(DevicePanel::getDeviceModelId, devicePanel-> Lists.newArrayList(devicePanel),(List<DevicePanel> newValueList, List<DevicePanel> oldValueList) ->
            {
                oldValueList.addAll(newValueList);
                return oldValueList;
            }));

            List<DeviceModel> deviceModelList = deviceModelService.list(new QueryWrapper<DeviceModel>().lambda().eq(DeviceModel::getId,deviceModelIdList));
            if(!CollUtil.isEmpty(deviceModelList)){
                deviceModelList.forEach(deviceModel -> {
                    DeviceModelPanelResp deviceModelPanelResp = new DeviceModelPanelResp();
                    deviceModelPanelResp.setDeviceType(deviceModel.getDeviceType());
                    deviceModelPanelResp.setDeviceModelId(deviceModel.getId());
                    deviceModelPanelResp.setDeviceModelName(deviceModel.getModelName());
                    List<DevicePanel> devicePanels = devicePanelMap.get(deviceModel.getId());
                    if(CollUtil.isNotEmpty(devicePanels)){
                        List<DevicePanelResp> devicePanelRespList = ConvertUtil.convert(devicePanels,DevicePanelResp.class);
                        deviceModelPanelResp.setDevicePanelRespList(devicePanelRespList);
                    }
                    deviceModelPanelRespList.add(deviceModelPanelResp);
                });
            }

        }
        return deviceModelPanelRespList;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(String deviceModelId) {
        boolean result =  devicePanelService.remove(new QueryWrapper<DevicePanel>().lambda().eq(DevicePanel::getDeviceModelId,deviceModelId));
        return result;
    }


}
