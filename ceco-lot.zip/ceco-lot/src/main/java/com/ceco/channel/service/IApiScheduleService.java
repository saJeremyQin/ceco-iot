package com.ceco.channel.service;

import com.ceco.channel.app.model.req.ScheduleListReq;
import com.ceco.channel.app.model.req.ScheduleSaveReq;
import com.ceco.channel.app.model.req.ScheduleTimeUpdateReq;
import com.ceco.channel.app.model.resp.ScheduleResp;
import com.ceco.channel.app.model.resp.ScheduleTimeResp;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface IApiScheduleService {

    /**
     * 定时控制保存
     * @param req
     * @return
     */
    boolean save(ScheduleSaveReq req);


    /**
     * 定时配置数据查询
     * @param req
     * @return
     */
    List<ScheduleResp> list(@RequestBody ScheduleListReq req);


    /**
     * 定时配置状态变更
     * @param req
     * @return
     */
    boolean updateStatus ( ScheduleTimeUpdateReq req);

    /**
     * 定时配置状态删除
     * @param id
     * @return
     */
    boolean delete ( String id,String time);

    /**
     * 重置节律
     * @return
     */
    List<ScheduleTimeResp> restMelody();
}
