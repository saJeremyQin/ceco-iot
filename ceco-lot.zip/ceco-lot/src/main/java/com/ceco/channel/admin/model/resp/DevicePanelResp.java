package com.ceco.channel.admin.model.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel("面板返回对象")
public class DevicePanelResp {

    @ApiModelProperty("支持的面板信息：1.彩光、2白光、3、光效、4、音乐5、节律6、膜片")
    private Integer supportPanel;

    @ApiModelProperty("面板名称")
    private String panelName;

}
