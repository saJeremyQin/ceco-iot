package com.ceco.channel.thridPart.model.vo;

import com.ceco.common.utils.BasePageReq;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @auther Dean
 * @Date 2021/11/9.
 */
@ApiModel
@Data
public class BiorhymListReq  extends BasePageReq {

}
