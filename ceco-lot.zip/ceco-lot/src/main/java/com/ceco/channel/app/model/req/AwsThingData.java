package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("亚马逊对接请求")
public class AwsThingData {

    @ApiModelProperty("产品key")
    private String productKey;

    @ApiModelProperty("产品序列")
    private String serialNo;

    private String appUserId;


    private String name;

}
