package com.ceco.channel.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.ModelListReq;
import com.ceco.channel.admin.model.req.ModelSaveReq;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.channel.admin.model.resp.ModelResp;
import com.ceco.channel.service.IApiModelService;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.PageUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.ConfDevice;
import com.ceco.module.entity.Device;
import com.ceco.module.entity.DeviceModel;
import com.ceco.module.entity.ModelConf;
import com.ceco.module.service.IConfDeviceService;
import com.ceco.module.service.IDeviceModelService;
import com.ceco.module.service.IDeviceService;
import com.ceco.module.service.IModelConfService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.ceco.common.utils.Constants.STATIC_LIGHTING;

@Service
public class ApiModelServiceImpl implements IApiModelService {

    @Autowired
    IModelConfService modelConfService;
    @Autowired
    IConfDeviceService confDeviceService;
    @Autowired
    IDeviceService deviceService;
    @Autowired
    IDeviceModelService deviceModelService;


    @Override
    public boolean save(ModelSaveReq req) {
        ValidatorUtils.validateEntity(req);
        ModelConf modelConf = ConvertUtil.convert(req, ModelConf.class);
        boolean result =  modelConfService.saveOrUpdate(modelConf);
        List<ConfDevice> confDeviceList = new ArrayList<>();
        confDeviceService.remove(new QueryWrapper<ConfDevice>().lambda().eq(ConfDevice::getConfId,modelConf.getId()));
        req.getDeviceModel().forEach(deviceModel ->{
            ConfDevice confDevice = new ConfDevice();
            confDevice.setDeviceModelId(deviceModel);
            confDevice.setConfId(modelConf.getId());
            confDevice.setType(STATIC_LIGHTING);
            confDeviceList.add(confDevice);
        });
        confDeviceService.saveBatch(confDeviceList);
        return result;
    }

    @Override
    public PageInfo<ModelResp> list(ModelListReq req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<ModelConf> modelConfList = modelConfService.list();
        PageInfo<ModelConf> pageInfo = new PageInfo<>(modelConfList);
        PageInfo<ModelResp> pageResp =  PageUtils.pageInfo2Resp(pageInfo, ModelResp.class);
        if(!CollUtil.isEmpty(pageResp.getList())){
            List<String> modelIdList = pageResp.getList().stream().map(ModelResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> deviceModelRespList = confDeviceService.selectConfDeviceList(modelIdList,STATIC_LIGHTING,null);
            if(!CollUtil.isEmpty(deviceModelRespList)){
                Map<String,List<DeviceModelResp>> confDeviceMap = deviceModelRespList.stream().collect(Collectors.groupingBy(DeviceModelResp::getConfId));
                pageResp.getList().forEach(modelResp -> {
                    if(confDeviceMap.get(modelResp.getId() ) !=null){
                        modelResp.setDeviceModelRespList(confDeviceMap.get(modelResp.getId()));
                    }
                });
            }
        }
        return pageResp;
    }

    @Override
    public List<ModelResp> list() {
        List<ModelConf> modelConfListList = modelConfService.list();
        List<ModelResp> modelRespList =  ConvertUtil.convert(modelConfListList,ModelResp.class);
        if(!CollUtil.isEmpty(modelRespList)){
            List<String> modelIdList = modelRespList.stream().map(ModelResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> deviceModelRespList = confDeviceService.selectConfDeviceList(modelIdList,STATIC_LIGHTING,null);
            if(!CollUtil.isEmpty(deviceModelRespList)){
                Map<String,List<DeviceModelResp>> confDeviceMap = deviceModelRespList.stream().collect(Collectors.groupingBy(DeviceModelResp::getConfId));
                modelRespList.forEach(modelResp -> {
                    if(confDeviceMap.get(modelResp.getId() ) !=null){
                        modelResp.setDeviceModelRespList(confDeviceMap.get(modelResp.getId()));
                    }
                });
            }
        }
        return modelRespList;
    }


    @Override
    public List<ModelResp> listByDeviceId(String deviceId) {
        List<ModelResp> respList = new ArrayList<>();
        if(StringUtil.isEmpty(deviceId)){
            return respList;
        }
        Device device = deviceService.getById(deviceId);
        if(Objects.isNull(device) || Objects.isNull(device.getProductKey())){
            return respList;
        }

        List<ModelResp> modelRespList = modelConfService.getModeRespListByDeviceId(deviceId);
        if(!CollUtil.isEmpty(modelRespList)){
            List<String> modelIdList = modelRespList.stream().map(ModelResp::getId).collect(Collectors.toList());
            List<DeviceModelResp> deviceModelRespList = confDeviceService.selectConfDeviceList(modelIdList,STATIC_LIGHTING,null);
            if(!CollUtil.isEmpty(deviceModelRespList)){
                Map<String,List<DeviceModelResp>> confDeviceMap = deviceModelRespList.stream().collect(Collectors.groupingBy(DeviceModelResp::getConfId));
                modelRespList.forEach(modelResp -> {
                    if(confDeviceMap.get(modelResp.getId() ) !=null){
                        modelResp.setDeviceModelRespList(confDeviceMap.get(modelResp.getId()));
                    }
                });
            }
        }
        return modelRespList;
    }

    @Override
    public boolean delete(String id) {
        return modelConfService.removeById(id);
    }
}
