package com.ceco.channel.admin.controller;


import com.ceco.channel.admin.model.req.SceneListReq;
import com.ceco.channel.admin.model.req.SceneParamSaveReq;
import com.ceco.channel.admin.model.req.SceneSaveReq;
import com.ceco.channel.admin.model.req.SceneListReq;
import com.ceco.channel.admin.model.resp.SceneParamResp;
import com.ceco.channel.admin.model.resp.SceneResp;
import com.ceco.channel.service.IApiSceneService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@Api(tags = {"pc端动态灯效配置控制器--废弃"})
@RequestMapping("/pc/scene")
public class SceneController {

    @Autowired
    IApiSceneService apiSceneService;

    @ApiOperation("后台保存信息动态灯效配置")
    @PostMapping("/save")
    public boolean save(@RequestBody SceneSaveReq req){
        return apiSceneService.save(req);
    }

    @ApiOperation("后台查询动态灯效配置信息")
    @PostMapping("/page/list")
    public PageInfo<SceneResp> list(@RequestBody SceneListReq req){
        return apiSceneService.list(req);
    }

    @ApiOperation("删除动态灯效配置")
    @GetMapping("/delete/{id}")
    public boolean delete(@PathVariable("id") String id){
        return apiSceneService.delete(id);
    }


    @ApiOperation("后台保存信息动态灯效参数配置")
    @PostMapping("/param/save")
    public boolean paramSave(@RequestBody SceneParamSaveReq req){
        return apiSceneService.paramSave(req);
    }

    @ApiOperation("后台查询动态灯效参数配置信息")
    @PostMapping("/param/list")
    public List<SceneParamResp> paramList(){
        return apiSceneService.paramList();
    }

    @ApiOperation("删除动态灯效参数配置")
    @GetMapping("/param/delete/{id}")
    public boolean paramDelete(@PathVariable("id") String id){
        return apiSceneService.paramDelete(id);
    }





}
