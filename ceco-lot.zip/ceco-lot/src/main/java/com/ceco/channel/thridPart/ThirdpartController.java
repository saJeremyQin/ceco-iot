package com.ceco.channel.thridPart;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.UserLoginReq;
import com.ceco.channel.admin.model.resp.UserLoginResp;
import com.ceco.channel.app.model.resp.AliAppUserLoginResp;
import com.ceco.channel.service.IApiUserService;
import com.ceco.common.Enum.ResultCode;
import com.ceco.common.annotation.NoAuthAnnotation;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.encrypt.AES128;
import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.AppUser;
import com.ceco.module.service.IAppUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/10/27.
 */
@RestController
@Api(tags = {"app端第三方登录控制器"})
@RequestMapping("/app/third")
@Slf4j
public class ThirdpartController {
    @Autowired
    IApiUserService apiUserService;
    @Value("${ceco.oauth.aliApp.clientId}")
    private String client_id;
    @Value("${ceco.oauth.aliApp.clientSecret}")
    private String clientSecret;
    @Autowired
    IAppUserService appUserService;

    @PostMapping("/aliApp/oauth/loginByPwd")
    @ApiOperation(value = "aliApp用户密码登录")
    @NoAuthAnnotation
    public Map loginByPwd(@RequestBody UserLoginReq req) {
        return apiUserService.aliApploginByPwd(req);
    }

    @PostMapping("/aliApp/oauth/token")
    @ApiOperation(value = "aliApp用户密码登录")
    @ResponseBody
    public Map getAccess_token(String grant_type,String client_id,String client_secret,String code ){
        //判断是否是阿里云客户端
        Map mapRes=new HashMap();
        log.info("阿里云登录code===========>>"+code);
        mapRes.put("result_code","0");
        mapRes.put("openid",null);
        mapRes.put("access_token","111111");
        mapRes.put("refresh_token","111111");
        if(client_id.equals("abcdefg123456789")&&client_secret.equals("abcdefg123456789")){
            log.info("生成openId----->");
            String openid=null;
            try {
                openid= AES128.decrypt(code);
                mapRes.put("openid",openid);
            } catch (Exception e) {
                throw  new BusinessException("阿里云app 用户唯一标示openid解密失败");
            }
        }
        log.info("getAccess_token___clien_id_________________"+ client_id);
        log.info("getAccess_token___client_secret_________________"+ client_secret);
        log.info("getAccess_token___result_________________"+ JSON.toJSONString(mapRes));
        return mapRes;

    }

    @PostMapping("/aliApp/oauth/userinfo")
    @ApiOperation(value = "用户信息")
    @ResponseBody
    public Map userInfo(String access_token,String openid ){
        AppUser appUser = appUserService.getOne(
                new QueryWrapper<AppUser>()
                        .lambda()
                        .eq(AppUser::getId, openid)
        );

        Map mapResult =new HashMap();
        mapResult.put("result_code","0");
        mapResult.put("message","成功");
        mapResult.put("openid",openid);
        mapResult.put("nick_name",appUser.getNickName());
        log.info("userInfo___result_________________"+ JSON.toJSONString(mapResult));

        return  mapResult;

    }


}
