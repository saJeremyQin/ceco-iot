package com.ceco.channel.app.model.resp;

import lombok.Data;

/**
 * @auther Dean
 * @Date 2021/10/22.
 */
@Data
public class DeviceQueryModel {
    String unit;
    String identifier;
    String dataType;
    String time;
    String value;
    String name;

}
