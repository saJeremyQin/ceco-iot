package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@ApiModel("修改设备信息根据设备mac地址")
@Data
public class DeviceSaveSerialNoReq {


    @ApiModelProperty("设备mac地址")
    @NotEmpty(message = "设备mac地址不能为空")
    private String serialNo;

    @ApiModelProperty("设备名称")
    @NotEmpty(message = "设备名称不能为空")
    private String name;
}
