package com.ceco.channel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.service.IApiDeviceInfoService;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.device.DeviceInfo;
import com.ceco.module.service.IDeviceInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @auther Dean
 * @Date 2021/11/24.
 */
@Service
public class ApiDeviceInfoServiceImpl implements IApiDeviceInfoService {
    @Autowired
    private IDeviceInfoService deviceInfoService;

    @Override
    public boolean save(DeviceInfo deviceInfo) {
        ValidatorUtils.validateEntity(deviceInfo);
        deviceInfo.setSwitchLed(0);
        deviceInfo.setActivationStatus(0);
       return    deviceInfoService.save(deviceInfo);
    }

    @Override
    public boolean update(DeviceInfo deviceInfo) {
        deviceInfo.setActivationStatus(1);
        deviceInfo.setSerialNo(deviceInfo.getSerialNo());
        return deviceInfoService.update(deviceInfo, new QueryWrapper<DeviceInfo>().lambda().eq(DeviceInfo::getSerialNo,deviceInfo.getSerialNo()));

    }

    @Override
    public DeviceInfo queryOne(DeviceInfo deviceInfo) {
        DeviceInfo deviceInfo1=  deviceInfoService.getOne(new QueryWrapper<DeviceInfo>().lambda().eq(DeviceInfo::getSerialNo,deviceInfo.getSerialNo()));
        return deviceInfo1;
    }
}
