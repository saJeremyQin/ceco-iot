package com.ceco.channel.app.model.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
@ApiModel("定时配置具体时间点响应对象")
public class ScheduleTimeResp {


    @ApiModelProperty("表示星期几，从0开始，表示星期天,节律可不填")
    private Integer dayOfWeek;

    @ApiModelProperty("具体时间")
    private Integer time;

    @ApiModelProperty("具体操作：1开灯2关灯")
    private Integer action;

    @ApiModelProperty("数据id")
    private String id;

    @ApiModelProperty("配置id")
    private String scheduleId;

    @ApiModelProperty("状态:0有效1无效")
    private Integer status;


}
