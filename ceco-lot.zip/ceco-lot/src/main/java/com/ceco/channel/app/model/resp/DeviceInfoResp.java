package com.ceco.channel.app.model.resp;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

/**
 * @auther Dean
 * @Date 2021/11/30.
 */
@Data
public class DeviceInfoResp {
    private Integer switchLed;

    /**
     * 设备激活状态：1激活 0未激活
     */
    private Integer activationStatus;

    /**
     * 设备mac地址
     */
    private String serialNo;

    /**
     * 设备密钥
     */
    private String productKey;

    /**
     * 固件版本号
     */
    private String firmwareVersion;

    private Integer tempValue;

    private String colourData;

    private Integer brightValue;
}
