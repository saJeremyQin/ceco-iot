package com.ceco.channel.admin.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@ApiModel("动态灯效保存请求对象")
@Data
public class SceneSaveReq {

    @ApiModelProperty("动态灯效名称")
    @NotEmpty(message ="名称不能为空")
    private String name;
    @ApiModelProperty("图片地址")
    private String imgUrl;

    @ApiModelProperty("设备类型")
    @NotEmpty(message = "支持设备类型不能为空！")
    private String deviceType;

    @ApiModelProperty("支持设备型号")
    @NotEmpty(message = "支持设备型号不能为空！")
    private List<String> deviceModel;

    @ApiModelProperty("参数id")
    @NotEmpty(message = "参数ID不能为空！")
    private String paramId;

    @ApiModelProperty("id")
    private String id;


}
