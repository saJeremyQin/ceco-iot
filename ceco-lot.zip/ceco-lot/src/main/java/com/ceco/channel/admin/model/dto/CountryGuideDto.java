package com.ceco.channel.admin.model.dto;

import lombok.Data;

@Data
public class CountryGuideDto {

    private String countryName;
    private String countryId;
    private String guideId;





}
