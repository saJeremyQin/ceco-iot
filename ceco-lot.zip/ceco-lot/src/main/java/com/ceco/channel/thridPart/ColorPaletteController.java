package com.ceco.channel.thridPart;

import com.ceco.channel.service.IApiColorPaletteService;
import com.ceco.channel.service.IApiDeviceControlService;
import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.ColorPalette;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @auther Dean
 * @Date 2021/11/12.
 */
@RestController
@Api(tags = {"app端调色板控制器"})
@RequestMapping("/app/colorPalette")
public class ColorPaletteController {
    @Autowired
    private IApiColorPaletteService iApiColorPaletteService;

    /**
     * 保存或更新调色板
     * @param body
     * @return
     */
    @PostMapping("/saveOrUpdate")
    @ResponseBody
    @ApiOperation(value = "保存或更新调色板")
    @ApiImplicitParams({
            @ApiImplicitParam(name="body",value="demo:有id表示更新。数据体colorPaletteData 的id表示 灯带段序号。更新要上传全部数据，覆盖  {\"id\":\"1459070649533501442\",\"appUserId\":\"1450741156045770754\",\"switchMode\":6,\"cloudBiz\":\"AL1\",\"sn\":\"b4e8420fcce4\",\"colorPaletteData\":[{\"id\":\"0\",\"rgb\":\"qqqqqq\"},{\"id\":\"1\",\"rgb\":\"-\"},{\"id\":\"2\",\"rgb\":\"-\"},{\"id\":\"3\",\"rgb\":\"-\"},{\"id\":\"4\",\"rgb\":\"-\"},{\"id\":\"5\",\"rgb\":\"-\"},{\"id\":\"6\",\"rgb\":\"-\"},{\"id\":\"7\",\"rgb\":\"-\"},{\"id\":\"8\",\"rgb\":\"-\"},{\"id\":\"9\",\"rgb\":\"-\"}]}" )
    })
    ResponseModel saveOrUpdate(@RequestBody String body){

        return iApiColorPaletteService.saveSerivce(body);
    }

    @PostMapping("/query")
    @ResponseBody
    @ApiOperation(value = "查询调色板")
    @ApiImplicitParams({
            @ApiImplicitParam(name="body",value="{\"appUserId\":\"1450741156045770754\",\"sn\":\"b4e8420fcce4\"}" )
    })
    ResponseModel query(@RequestBody String body){
        return iApiColorPaletteService.querySerivce(body);
    }
}
