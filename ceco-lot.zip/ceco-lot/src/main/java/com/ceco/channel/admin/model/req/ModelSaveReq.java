package com.ceco.channel.admin.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@ApiModel("模式保存请求对象")
@Data
public class ModelSaveReq {

    @ApiModelProperty("模式名称")
    @NotEmpty(message ="名称不能为空")
    private String name;
    @ApiModelProperty("图片地址")
    private String imgUrl;

    @ApiModelProperty("白光亮度值")
    @NotEmpty(message ="白光亮度值不能为空")
    private String brightnessValue;
    @ApiModelProperty("白光")
    @NotEmpty(message ="白光值不能为空")

    private String colorTemperatureValue;
    @ApiModelProperty("彩光值")
    @NotEmpty(message ="彩光值不能为空")
    private String hsvValue;


    @ApiModelProperty("id")
    private String id;


    @ApiModelProperty("设备类型")
    @NotEmpty(message = "支持设备类型不能为空！")
    private String deviceType;

    @ApiModelProperty("支持设备型号")
    @NotEmpty(message = "支持设备型号不能为空！")
    private List<String> deviceModel;

}
