package com.ceco.channel.app.model.req.deviceUpdateReq;

/**
 * @auther Dean
 * @Date 2021/10/29.
 * 灯带物模型
 */
public class LightStripThingModel {
}
