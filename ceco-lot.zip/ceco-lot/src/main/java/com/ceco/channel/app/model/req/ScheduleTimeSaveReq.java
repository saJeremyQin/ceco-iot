package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.models.auth.In;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
@ApiModel("定时配置具体时间点保存请求对象")
public class ScheduleTimeSaveReq {


    @ApiModelProperty("表示星期几，从0开始，表示星期天,节律可不填")
    private Integer dayOfWeek;

    @ApiModelProperty("具体时间")
    @NotEmpty(message = "时间不能为空")
    private Integer time;

    @ApiModelProperty("具体操作：1开灯2关灯")
    private Integer action;


}
