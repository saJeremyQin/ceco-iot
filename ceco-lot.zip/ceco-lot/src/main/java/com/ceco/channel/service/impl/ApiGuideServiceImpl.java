package com.ceco.channel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.admin.model.req.GuideListReq;
import com.ceco.channel.admin.model.req.GuideSaveReq;
import com.ceco.channel.admin.model.resp.GuideListResp;
import com.ceco.channel.admin.model.resp.GuideResp;
import com.ceco.channel.service.IApiGuideService;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.PageUtils;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.GuideConf;
import com.ceco.module.service.ICountryGuideService;
import com.ceco.module.service.IGuideConfService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ApiGuideServiceImpl implements IApiGuideService {

    @Autowired
    IGuideConfService guideConfService;

    @Autowired
    ICountryGuideService countryGuideService;

    @Override
    public boolean save(GuideSaveReq req) {
        ValidatorUtils.validateEntity(req);
        GuideConf guideConf = ConvertUtil.convert(req, GuideConf.class);
        boolean result =  guideConfService.saveOrUpdate(guideConf);
        return result;

    }

    @Override
    public PageInfo<GuideListResp> list(GuideListReq req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<GuideConf> guideConfListList = guideConfService.list();
        PageInfo<GuideConf> pageInfo = new PageInfo<>(guideConfListList);
        return  PageUtils.pageInfo2Resp(pageInfo, GuideListResp.class);
    }

    @Override
    public List<GuideResp> listBySys(GuideListReq req) {
        List<GuideConf> guideConfListList = guideConfService.list(new QueryWrapper<GuideConf>().lambda().eq(req.getSysType() != null,GuideConf::getSysType,req.getSysType()));
        List<GuideResp> guideRespList = new ArrayList<>();
        guideConfListList.forEach(guideConf -> {
            GuideResp guideResp = new GuideResp();
            guideResp.setId(guideConf.getId());
            guideResp.setSysType(guideConf.getSysType());
            guideResp.setStartDate(guideConf.getStartDate().getTime());
            guideResp.setEndDate(guideConf.getEndDate().getTime());
            guideResp.setImgUrl(guideConf.getImgUrl());
            guideResp.setCreateName(guideConf.getCreateName());
            guideResp.setCreateTime(guideConf.getCreateTime());
            guideRespList.add(guideResp);
        });

        return guideRespList;
    }

    @Override
    public boolean delete(String id) {
        return guideConfService.removeById(id);
    }
}
