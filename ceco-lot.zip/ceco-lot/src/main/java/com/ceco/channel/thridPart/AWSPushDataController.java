package com.ceco.channel.thridPart;

import com.ceco.channel.service.thing.model.aws1.ShadowProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

/**
 * @auther Dean
 * @Date 2021/11/25.
 */
@RestController
@RequestMapping("/aws")
@Slf4j
public class AWSPushDataController {
    @Autowired
    private ShadowProcessor shadowProcessor;

    /**
     * 规则引擎  aws ->myrule
     *
     * @param confirmationToken
     * @param body
     */
    @PostMapping("/ruleEngine")
    public void pushData( String confirmationToken,  @RequestBody String body){
        log.info("=================confirmationToken===================="+confirmationToken);
        shadowProcessor.uploadDataByHttp(body);  //通过http推送过来
        shadowProcessor.uploadDataBySQS(body); //推送到sqs
        log.info("=================body===================="+body);
    }

    /**
     * ELB 负载 健康检查,GET请求，空参数
     */
    @GetMapping("/elbTest")
    public void ELBHealthTest(){

    }

}
