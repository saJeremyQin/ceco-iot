package com.ceco.channel.app.model.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("设备信息返回对象")
@Data
public class DeviceResp {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("设备序列号")
    private String serialNo;

    @ApiModelProperty("设备名称")
    private String name;

    @ApiModelProperty("设备类型")
    private String productKey;

    @ApiModelProperty("设备所属组")
    private String groupId;

    @ApiModelProperty("设备所属组名")
    private String groupName;

    @ApiModelProperty("设备所属房间")
    private String roomId;

    @ApiModelProperty("设备所属房间名")
    private String roomName;

    @ApiModelProperty("设备图片")
    private String imgUrl;

    @ApiModelProperty("设备类型名称")
    private String deviceModelName;




}
