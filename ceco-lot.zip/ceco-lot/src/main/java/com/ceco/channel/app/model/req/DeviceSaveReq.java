package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
@ApiModel("设备修改请求对象")
public class DeviceSaveReq {

    @ApiModelProperty("设备id")
    @NotEmpty(message = "设备信息不能为空")
    private String id;

    @ApiModelProperty("设备名称")
    @NotEmpty(message = "设备名称不能为空")
    private String name;
}
