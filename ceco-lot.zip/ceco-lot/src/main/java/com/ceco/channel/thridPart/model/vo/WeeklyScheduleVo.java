package com.ceco.channel.thridPart.model.vo;

import com.ceco.module.entity.WeeklySchedule;
import com.google.gson.Gson;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.HashMap;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/9.
 */
@Data
@ApiModel
public class WeeklyScheduleVo {
    private String appUserId;

    private Map monday=new HashMap();

    private Map tuesday=new HashMap();

    private Map wednesday=new HashMap();

    private Map thursday=new HashMap();

    private Map friday=new HashMap();

    private Map saturday=new HashMap();

    private Map sunday=new HashMap();

    private int status;
    private String serialNo;

    public static WeeklyScheduleVo getWeeklyScheduleVo(WeeklySchedule weeklySchedule){
        Gson gson =new Gson();
        WeeklyScheduleVo weeklyScheduleVo=new WeeklyScheduleVo();
        weeklyScheduleVo.setAppUserId(weeklySchedule.getAppUserId());
        weeklyScheduleVo.setMonday(gson.fromJson(weeklySchedule.getMonday(),Map.class));
        weeklyScheduleVo.setTuesday(gson.fromJson(weeklySchedule.getTuesday(),Map.class));
        weeklyScheduleVo.setWednesday(gson.fromJson(weeklySchedule.getWednesday(),Map.class));
        weeklyScheduleVo.setThursday(gson.fromJson(weeklySchedule.getThursday(),Map.class));
        weeklyScheduleVo.setFriday(gson.fromJson(weeklySchedule.getFriday(),Map.class));
        weeklyScheduleVo.setSaturday(gson.fromJson(weeklySchedule.getSaturday(),Map.class));
        weeklyScheduleVo.setSunday(gson.fromJson(weeklySchedule.getSunday(),Map.class));
        weeklyScheduleVo.setStatus(weeklySchedule.getStatus());
        weeklyScheduleVo.setSerialNo(weeklySchedule.getSerialNo());
        return weeklyScheduleVo;
    }
}
