package com.ceco.channel.thridPart.model.vo;

import lombok.Data;

import java.util.ArrayList;

/**
 * @auther Dean
 * @Date 2021/11/12.
 */
@Data
public class ColorPaletteVo {
    String id;
    String appUserId;
    String serialNo;
    String colorPaletteData;
}
