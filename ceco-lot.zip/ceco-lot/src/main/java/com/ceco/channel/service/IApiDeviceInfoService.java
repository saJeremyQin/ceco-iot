package com.ceco.channel.service;


import com.ceco.module.entity.device.DeviceInfo;

/**
 * @auther Dean
 * @Date 2021/11/24.
 */
public interface IApiDeviceInfoService {
    //保存设备信息
        boolean save(DeviceInfo deviceInfo);

        //更新设备信息
        boolean update(DeviceInfo deviceInfo);

        DeviceInfo queryOne(DeviceInfo deviceInfo);
}
