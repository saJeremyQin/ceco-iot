package com.ceco.channel.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.service.IApiColorPaletteService;
import com.ceco.channel.service.IApiDeviceControlService;
import com.ceco.channel.service.thing.AL1IThingControlImpl;
import com.ceco.channel.service.thing.DeviceParam;
import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.ColorPalette;
import com.ceco.module.service.IColorPaletteService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.Objects;

/**
 * @auther Dean
 * @Date 2021/11/12.
 */
@Service
public class ApiColorPaletteServiceImpl implements IApiColorPaletteService{
    @Autowired
    private IColorPaletteService iColorPaletteService;
    @Autowired
    private IApiDeviceControlService iApiDeviceControlService;
    @Autowired
    private AL1IThingControlImpl al1IThingControl;
    @Override
    public ResponseModel saveSerivce(String body) {

        Map bodyMap=JSONObject.parseObject(body,Map.class);
        ColorPalette colorPalette =new ColorPalette();
        String appUserId=(String)bodyMap.get("appUserId");
        String cloudBiz=(String)bodyMap.get("cloudBiz");
        String serialNo=(String)bodyMap.get("sn");
        colorPalette.setAppUserId(appUserId);
        colorPalette.setSerialNo(serialNo);
        String listData =bodyMap.get("colorPaletteData").toString();
        iColorPaletteService.remove(new QueryWrapper<ColorPalette>().lambda().eq(ColorPalette::getAppUserId,appUserId).eq(ColorPalette::getSerialNo,serialNo));
        colorPalette.setColorPaletteData(listData);
        /**
         * 更新操作带着全量的灯段数据，整个list
         */
         iColorPaletteService.saveOrUpdate(colorPalette);
        DeviceParam deviceParam= iApiDeviceControlService.getDeviceParam(body);
        if(cloudBiz.equals("AL1")){
            al1IThingControl.thingPropertySet(deviceParam);
        }

        return ResponseModel.success(200,"写入数据",null);
    }

    @Override
    public ResponseModel querySerivce(String body) {
        Gson gson =new Gson();
        Map map=gson.fromJson(body,Map.class);
        String appUserId=(String)map.get("appUserId");
        String serialNo=(String)map.get("sn");
        ColorPalette colorPalette1=   iColorPaletteService.getOne(new QueryWrapper<ColorPalette>().lambda().eq(ColorPalette::getAppUserId,appUserId).eq(ColorPalette::getSerialNo,serialNo));
        if(!Objects.isNull(colorPalette1)) {
            return ResponseModel.success(200, "获取数据", JSONObject.parseArray(colorPalette1.getColorPaletteData()));
        }else{
            return ResponseModel.SUCCESS;
        }
    }
}
