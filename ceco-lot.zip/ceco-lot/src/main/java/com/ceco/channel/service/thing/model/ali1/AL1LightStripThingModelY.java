package com.ceco.channel.service.thing.model.ali1;

import com.ceco.common.Enum.SwitchLed;
import com.ceco.channel.service.thing.ThingModel;
import com.ceco.interceptor.annotation.CecoEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

/**
 * @auther Dean
 * @Date 2021/10/29.
 * 公版物模型
 */
@Data
public class AL1LightStripThingModelY extends ThingModel {
    //开关状态
    @CecoEnum(clazz = SwitchLed.class, method = "getValue", message = "powerstate参数只能为1或0")
    private Integer powerstate;


    //亮度值
    @ApiModelProperty("亮度值")
    @Max(value = 100,message = "bright_value最大不能超过100")
    @Min(value  =1,message = "bright_value最小不能小于0")
    private Integer brightness;

    private Integer LightType;

}
