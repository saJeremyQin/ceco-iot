package com.ceco.channel.thridPart.model.vo;

import lombok.Data;

@Data
public class ScheduleCmdParam {

    private String weekDays;

    private String actions;

    private String times;

    private String color;


}
