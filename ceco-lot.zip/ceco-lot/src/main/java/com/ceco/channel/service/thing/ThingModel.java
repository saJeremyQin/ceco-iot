package com.ceco.channel.service.thing;

/**
 * @auther Dean
 * @Date 2021/10/29.
 */
public class ThingModel {
}
