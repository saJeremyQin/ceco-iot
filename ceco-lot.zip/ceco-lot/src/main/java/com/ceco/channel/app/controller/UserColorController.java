package com.ceco.channel.app.controller;

import com.ceco.channel.app.model.req.UserColorSaveReq;
import com.ceco.channel.app.model.resp.UserColorResp;
import com.ceco.channel.service.IApiUserColorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Api(tags = {"用户颜色管理控制器"})
@RequestMapping("/app/userColor")
public class UserColorController {

    @Autowired
    IApiUserColorService apiUserColorService;

    @ApiOperation("用户颜色信息保存")
    @PostMapping("/save")
    public boolean save(@RequestBody UserColorSaveReq req){
        return apiUserColorService.save(req);
    }

    @ApiOperation("用户颜色信息查询")
    @GetMapping("/list/{appUserId}")
    public List<UserColorResp> list(@PathVariable("appUserId") String appUserId){
        return apiUserColorService.list(appUserId);
    }

    @ApiOperation("删除用户颜色信息")
    @GetMapping("/delete/{id}")
    public boolean delete(@PathVariable("id") String id){
        return apiUserColorService.delete(id);
    }
    


}
