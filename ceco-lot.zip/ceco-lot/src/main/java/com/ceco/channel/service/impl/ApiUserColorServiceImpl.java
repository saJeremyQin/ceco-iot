package com.ceco.channel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.app.model.req.GroupDeviceAddReq;
import com.ceco.channel.app.model.req.GroupListReq;
import com.ceco.channel.app.model.req.GroupSaveReq;
import com.ceco.channel.app.model.req.UserColorSaveReq;
import com.ceco.channel.app.model.resp.DeviceResp;
import com.ceco.channel.app.model.resp.GroupResp;
import com.ceco.channel.app.model.resp.UserColorResp;
import com.ceco.channel.service.IApiGroupService;
import com.ceco.channel.service.IApiUserColorService;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.ConvertUtil;
import com.ceco.common.utils.ValidatorUtils;
import com.ceco.module.entity.Device;
import com.ceco.module.entity.Group;
import com.ceco.module.entity.GroupDevice;
import com.ceco.module.entity.UserColor;
import com.ceco.module.service.IDeviceService;
import com.ceco.module.service.IGroupDeviceService;
import com.ceco.module.service.IGroupService;
import com.ceco.module.service.IUserColorService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ApiUserColorServiceImpl implements IApiUserColorService {


    @Autowired
    IUserColorService userColorService;




    @Override
    public boolean save(UserColorSaveReq req) {
        ValidatorUtils.validateEntity(req);
        UserColor userColor = ConvertUtil.convert(req, UserColor.class);
        return userColorService.save(userColor);

    }

    @Override
    public List<UserColorResp> list(String appUserId) {
        List<UserColor> userColorList = userColorService.list(new QueryWrapper<UserColor>().lambda().eq(UserColor::getAppUserId,appUserId));
        return ConvertUtil.convert(userColorList,UserColorResp.class);
    }

    @Override
    public boolean delete(String id) {
        return userColorService.removeById(id);
    }


}
