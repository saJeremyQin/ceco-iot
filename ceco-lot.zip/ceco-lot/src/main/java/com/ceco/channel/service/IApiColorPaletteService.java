package com.ceco.channel.service;

import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.ColorPalette;

import java.util.List;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/12.
 */
public interface IApiColorPaletteService {

    ResponseModel saveSerivce(String body);
    ResponseModel querySerivce(String body);
}
