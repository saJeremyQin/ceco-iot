package com.ceco.channel.thridPart;

import com.ceco.channel.service.IApiWeeklyScheduleService;
import com.ceco.channel.thridPart.model.vo.BiorhythmVo;
import com.ceco.channel.service.IApiBiorhythmService;
import com.ceco.common.utils.response.ResponseModel;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/9.
 */
@RestController
@Api(tags = {"app端用生物节律控制"})
@RequestMapping("/app/biorhythm")
public class BiorhythmController {

    @Autowired
    private IApiBiorhythmService iApiBiorhythmService;
    @Autowired
    private IApiWeeklyScheduleService iApiWeeklyScheduleService;






    @ApiOperation("保存生物节律信息")
    @PostMapping("/save")
    @ApiImplicitParams({
            @ApiImplicitParam(name="biorhythmVo",value="{\"appUserId\":\"1450741156045770754\",\"serialNo\":\"b4e8420fcce4\",\"sunrise\":1211110,\"noon\":1120,\"sunset\":110,\"sleep\":101}")
    })
    public ResponseModel save(@RequestBody BiorhythmVo biorhythmVo){
        return iApiBiorhythmService.save(biorhythmVo);
    }

    @ApiOperation("删除生物节律信息")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(name="biorhythmVo",value="{\"id\":\"1457977748443381761\"}")
    })
    public ResponseModel delete(@RequestBody BiorhythmVo biorhythmVo){
        return iApiBiorhythmService.delete(biorhythmVo);
    }

    @ApiOperation("修改生物节律信息(编辑日出日落等时间。如果上传status并且为1，则立刻生效(周定时失效))")
    @PostMapping("/update")
    @ApiImplicitParams({
            @ApiImplicitParam(name="biorhythmVo",value="{\"id\":\"1458367573222805506\",\"sunrise\":121110,\"noon\":100,\"sunset\":100,\"sleep\":100,\"status\":1}")
    })
    public ResponseModel update(@RequestBody BiorhythmVo biorhythmVo){
        return iApiBiorhythmService.update(biorhythmVo);
    }

    @ApiOperation("查询生物节律信息")
    @PostMapping("/queryOne")
    @ApiImplicitParams({
            @ApiImplicitParam(name="biorhythmVo",value="{\"id\":\"1457977748443381761\"}")
    })
    public ResponseModel queryOne(@RequestBody BiorhythmVo biorhythmVo){
        return iApiBiorhythmService.queryOne(biorhythmVo);
    }

    @ApiOperation("重置生物节律信息")
    @PostMapping("/resetOne")
    @ApiImplicitParams({
            @ApiImplicitParam(name="biorhythmVo",value="{\"id\":\"1457977748443381761\"}")
    })
    public ResponseModel resetOne(@RequestBody BiorhythmVo biorhythmVo){
        return iApiBiorhythmService.resetOne(biorhythmVo);
    }


    @ApiOperation("保存周定时规则(冲突则覆盖更新)")
    @PostMapping("/weekSchedule/saveOrUpdate")
    @ApiImplicitParams({
            @ApiImplicitParam(name="map", value="time 截止到凌晨的分钟时间戳，operation 操作1开机 0关机，立刻生效subStatus为1，status为1，生物节律信息status=0" +
                    "星期字段：monday,tuesday,wednesday,thursday,friday,saturday,sunday" +
                    "demo:{\"wednesday\":{\"time\":\"312\",\"operation\":\"1\"},\"serialNo\":\"b4e8420fcce4\",\"appUserId\":\"1450741156045770754\"}")
    })
    public ResponseModel saveWeekSchedule(@RequestBody Map map){
        return iApiWeeklyScheduleService.saveWeeklyScheduleService(map);
    }

    //周定时删除接口
    @ApiOperation("删除周定时规则")
    @PostMapping("/weekSchedule/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(name="map",value="{\"whichDay\":\"monday\",\"time\":\"302\",\"appUserId\":\"1450741156045770754\",\"serialNo\":\"b4e8420fcce4\"}")
    })
    public ResponseModel deleteWeekSchedule(@RequestBody Map map){
        return iApiWeeklyScheduleService.deleteWeekScheduleService(map);
    }

    //周定时修改
//    @ApiOperation("修改周定时生效状态(与生物节律互斥)")
//    @PostMapping("/weekSchedule/update")
//    @ApiImplicitParams({
//            @ApiImplicitParam(name="map",value="{\"whichDay\":\"monday\",\"time\":\"302\",\"appUserId\":\"1450741156045770754\",\"serialNo\":\"b4e8420fcce4\"}")
//    })
//    public ResponseModel updateWeekSchedule(@RequestBody Map map){
//        return iApiWeeklyScheduleService.updateWeekScheduleService(map);
//    }


    //周定时查询
    @ApiOperation("查询生物节律和周定时列表")
    @PostMapping("/list")
    @ApiImplicitParams({
            @ApiImplicitParam(name="map",value="{   \n" +
                    "    \"appUserId\":\"1450741156045770754\"\n" +
                    "}")
    })
    @ApiResponses({
            @ApiResponse(code=200,message = "{\"code\":200,\"msg\":\"生物节律和周定时列表查询\",\"data\":{\"biorhythmVo\":{\"id\":\"1458367573222805506\",\"status\":0},\"weeklyScheduleVo\":{\"sunday\":{},\"saturday\":{},\"tuesday\":{},\"wednesday\":{\"312\":{\"operation\":\"1\",\"subStatus\":\"0\"}},\"thursday\":{},\"friday\":{},\"monday\":{\"301\":{\"operation\":\"1\",\"subStatus\":\"1\"},\"302\":{\"operation\":\"1\",\"subStatus\":\"0\"}},\"status\":1}}}")
    })
    public ResponseModel queryOneWeekSchedule(@RequestBody Map map){

        return iApiWeeklyScheduleService.queryOneWeekScheduleService(map);
    }
}
