package com.ceco.channel.admin.model.resp;

import com.ceco.module.entity.DevicePanel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel("面板已绑定的设备类型信息")
public class DeviceModelPanelResp {

    @ApiModelProperty("设备型号id")
    private String deviceModelId;

    @ApiModelProperty("设备型号名称")
    private String deviceModelName;

    @ApiModelProperty("设备类型")
    private String deviceType;

    @ApiModelProperty("设备支持的面板信息")
    private List<DevicePanelResp> devicePanelRespList;


}
