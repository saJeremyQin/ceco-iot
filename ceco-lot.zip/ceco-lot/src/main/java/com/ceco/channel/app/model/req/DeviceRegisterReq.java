package com.ceco.channel.app.model.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@ApiModel("设备注册请求对西那个")
@Data
public class DeviceRegisterReq {

    @ApiModelProperty("用户id")
    @NotEmpty(message = "用户id不能为空")
    private String appUserId;

    @ApiModelProperty("设备名称")
    @NotEmpty(message = "设备名称不能为空")
    private String name;

    @ApiModelProperty("设备序列号")
    @NotEmpty(message = "设备序列号不能为空")
    private String serialNo;

    @ApiModelProperty("设备类型")
    @NotEmpty(message = "设备类型不能为空")
    private String productKey;


}
