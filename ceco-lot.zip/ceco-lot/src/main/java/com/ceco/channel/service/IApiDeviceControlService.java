package com.ceco.channel.service;


import com.ceco.channel.app.model.req.deviceUpdateReq.AL1LightStripThingModel;
import com.ceco.channel.service.thing.DeviceParam;
import com.ceco.channel.service.thing.ThingModel;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/10/18.
 */
public interface IApiDeviceControlService {

   boolean thingWebsocketPropertiesSetService(String body);

   boolean thingSceneParamSetService(String body);
   boolean thingPropertiesSetService(String body);
   ThingModel thingPropertiesGetService(String body);
   Map thingStatusGetService(String body);
   boolean updateDevice(String deviceName,AL1LightStripThingModel AL1LightStripThingModel);
   Object queryDevice(String deviceName,String productKey);
   public DeviceParam getDeviceParam(String body);

   }
