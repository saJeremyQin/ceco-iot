package com.ceco.channel.common;

import com.ceco.channel.common.model.req.BiorhythmResp;
import com.ceco.common.utils.FileUploadResult;
import com.ceco.common.utils.FileUploadUtils;
import com.ceco.common.utils.MailUtils;
import com.ceco.common.utils.WeatherUtils;
import com.ceco.common.utils.aliyun.AliyunPhoneCodeUtils;
import com.ceco.common.utils.aws.SESUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@Api(tags = {"通用控制器"})
public class CommonController {

    @Autowired
    FileUploadUtils fileUploadUtils;

    @Autowired
    AliyunPhoneCodeUtils aliyunPhoneCodeUtils;

    @Autowired
    MailUtils mailUtils;

    @Autowired
    WeatherUtils weatherUtils;

    @Autowired
    private SESUtils sesUtils;
    /**
     * 通用上传请求
     */
    @PostMapping("/common/upload")
    @ApiOperation("上传文件")
    public FileUploadResult uploadFile(MultipartFile file)
    {
        return fileUploadUtils.upload(file);
    }

    @PostMapping("/common/aws/upload")
    @ApiOperation("上传文件")
    public FileUploadResult awsUploadFile(MultipartFile file)
    {
        return fileUploadUtils.awsUpload(file);
    }

    @GetMapping("/common/sendPhoneCode/{phone}")
    @ApiOperation("发送手机验证码(五分钟内有效)")
    public boolean sendSms(@PathVariable("phone") String phone){
        return aliyunPhoneCodeUtils.getPhoneMsg(phone);
    }

    @GetMapping("/common/sendMailCode/{address}")
    @ApiOperation("发送邮箱验证码(两小时内有效)")
    public boolean sendMail(@PathVariable("address") String address){
        return mailUtils.sendMailCode(address);
    }

    @GetMapping("/common/aws/sendMailCode/{address}")
    @ApiOperation("发送邮箱验证码(两小时内有效)")
    public boolean sendAwsMail(@PathVariable("address") String address){
        return sesUtils.sendMailCode(address);
    }

    @GetMapping("/common/getBiorhythm")
    @ApiOperation("生物节律查询")
    @ResponseBody
    public BiorhythmResp getBiorhythm(@RequestParam Map map){
        return weatherUtils.getBiorhythm(map);
    }


}
