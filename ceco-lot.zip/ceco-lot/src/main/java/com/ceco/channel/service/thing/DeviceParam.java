package com.ceco.channel.service.thing;

import lombok.Data;

/**
 * @auther Dean
 * @Date 2021/10/29.
 */
@Data
public class DeviceParam {
    String deviceName;
    String cloudToken;//阿里云生活IOT平台cloudToken
    String productKey;
    String param;//设备控制参数
}
