package com.ceco.channel.service;

import com.ceco.channel.app.model.req.GroupSaveReq;
import com.ceco.channel.app.model.req.UserColorSaveReq;
import com.ceco.channel.app.model.resp.GroupResp;
import com.ceco.channel.app.model.resp.UserColorResp;

import java.util.List;


public interface IApiUserColorService {

    /**
     * 保存用户颜色
     * @param req
     * @return 操作结果
     */
    boolean save(UserColorSaveReq req);

    /**
     * 查询用户颜色
     * @param
     * @return
     */
    List<UserColorResp> list(String  appUserId);

    /**
     * 删除用户颜色
     * @param id 删除用户颜色
     * @return
     */
    boolean delete(String id);


}
