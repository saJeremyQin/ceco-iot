package com.ceco.websocket;

import com.alipay.api.java_websocket.enums.ReadyState;

import java.net.URI;

public class Client {

    private static String url = "wss://usapi.cecoceco.com/cecoapi/websocket/cmd/device";

    public static void main(String[] args) {
        try {
            SocketClient myClient = new SocketClient(new URI(url));
            myClient.connect();
            // 判断是否连接成功，未成功后面发送消息时会报错
            while (!myClient.getReadyState().equals(ReadyState.OPEN)) {
                System.out.println("连接中···请稍后");
                Thread.sleep(1000);
            }
            myClient.send("{\"sn\":\"b4e8420f78c8\",\"switchMode\":1,\"tempValue\":4600,\"brightValue\":43,\"appUserId\":\"1463382940933718017\",\"cloudBiz\":\"AL1\"}");
            System.out.println("发送成功");
            //myClient.send("test1");
            //myClient.send("test2");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
