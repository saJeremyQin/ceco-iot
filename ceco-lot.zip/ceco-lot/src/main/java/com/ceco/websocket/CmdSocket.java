package com.ceco.websocket;



import com.alibaba.fastjson.JSONObject;
import com.ceco.channel.service.IApiDeviceControlService;
import com.ceco.common.utils.response.ResponseModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
/**
 * @Author: zy
 * @Date: 2020/9/10 17:52
 * @desc：
 */

/**
 *
 * 前后端交互的类实现消息的接收推送(自己发送给所有人(不包括自己))
 *
 */
@Slf4j
@ServerEndpoint(value = "/websocket/cmd/device")
@Component
public class CmdSocket {

    /** 记录当前在线连接数 */
    private static AtomicInteger onlineCount = new AtomicInteger(0);

    static IApiDeviceControlService apiDeviceControlService;


    @Autowired
    public void setApiDeviceControlService(IApiDeviceControlService apiDeviceControlService){
        CmdSocket.apiDeviceControlService = apiDeviceControlService;
    }

    @OnOpen
    public void onOpen() {
        onlineCount.incrementAndGet(); // 在线数加1
        log.info("有新连接加入，当前在线人数为：{}", onlineCount);
    }
    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        onlineCount.decrementAndGet(); // 在线数减1
        log.info("有连接关闭，当前在线人数为：{}", onlineCount);
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message
     *            客户端发送过来的消息
     */
    @OnMessage
    public void onMessage( String message,Session session) throws IOException {
        log.info("服务端收到客户端的消息:{}", message);
        try {
            boolean result = apiDeviceControlService.thingPropertiesSetService(message);
            session.getBasicRemote().sendText(JSONObject.toJSONString(ResponseModel.success(result)));
        } catch (IOException e) {
            session.getBasicRemote().sendText(JSONObject.toJSONString(ResponseModel.FAIL));
            log.error("消息处理失败，失败原因====>"+e.getMessage());
        }
    }

    @OnError
    public void onError( Throwable error) {
        log.error("发生错误");
        error.printStackTrace();
    }

    /**
     * 群发消息
     *
     * @param message
     *            消息内容
     *           fromSession==null即为广播
     */
    public static void sendMessage(String message) {

    }
}
