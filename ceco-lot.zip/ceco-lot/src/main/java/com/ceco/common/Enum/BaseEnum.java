package com.ceco.common.Enum;

public interface BaseEnum<V> {
    public V getValue();
    public String getText();
}
