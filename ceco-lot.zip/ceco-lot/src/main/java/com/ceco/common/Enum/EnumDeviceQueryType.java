package com.ceco.common.Enum;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;

public enum EnumDeviceQueryType implements BaseEnum<Integer>{
    ALL(1,"查询全部"),
    IN_ROOM_DEVICE(2,"在房间的设备"),
    OUT_ROOM_DEVICE(3,"不在房间的设备");
    private final Integer value;
    private final String text;

    private EnumDeviceQueryType(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    @Override
    public String getText() {
        return text;
    }


}
