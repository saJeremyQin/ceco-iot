package com.ceco.common.utils.aliyun;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.iot.model.v20180120.SetDevicePropertyRequest;
import com.ceco.channel.app.model.req.deviceUpdateReq.AL1LightStripThingModel;
import com.ceco.configure.AliIOT.USIOTConfig;
import com.ceco.module.service.IDeviceService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @auther Dean
 * @Date 2021/10/21.
 */
@Component
public class USIOTDeivceUtils {
    @Autowired
    private DefaultAcsClient foreignIotClient;
    @Autowired
    private USIOTConfig usiotConfig;
    @Autowired
    private CNIOTDeviceUtils cniotDeviceUtils;

    @Autowired
    private IDeviceService iDeviceService;

    public  boolean usControlDevice(String deviceName,  AL1LightStripThingModel AL1LightStripThingModel){
        Gson gson =new Gson();
        com.aliyuncs.iot.model.v20180120.SetDevicePropertyResponse response;
        com.aliyuncs.iot.model.v20180120.SetDevicePropertyRequest setDevicePropertyRequest = new SetDevicePropertyRequest();
        //美国地区
        setDevicePropertyRequest.setDeviceName(deviceName);
        //需要设备ID
        String deviceId= cniotDeviceUtils.getDeviceId(deviceName);
        setDevicePropertyRequest.setIotId(deviceId);
        //        Device deviceEntity= iDeviceService.getOne(new QueryWrapper<Device>().lambda().eq(Device::getName,deviceName));
//        setDevicePropertyRequest.setProductKey(deviceEntity.getProductKey());
        setDevicePropertyRequest.setProductKey(AL1LightStripThingModel.getProductKey());
        //Alink语法，无关参数要为null，变为json 的key就不存在了
        AL1LightStripThingModel.setLocale(null);
        AL1LightStripThingModel.setProductKey(null);
        setDevicePropertyRequest.setItems(gson.toJson(AL1LightStripThingModel));


        try {
            response = foreignIotClient.getAcsResponse(setDevicePropertyRequest);
            if (response.getSuccess() != null && response.getSuccess()) {
                return true;   //设备属性下发成功
            } else {
                return false;  //设备属性下发失败
            }

        } catch (ClientException e) {
            e.printStackTrace();

        }
        return true;
    }




}
