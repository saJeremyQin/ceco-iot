package com.ceco.common.utils;

/**
 * @auther Dean
 * @Date 2021/11/17.
 */
public class LogInfoUtils {

    public static String successInfo(String className,String methodName,String message){
        return "SUCCESS["+className+"."+methodName+":("+message+")]";
    }

    public static String errorInfo(String className,String methodName,String message){
        return "ERROR["+className+"."+methodName+":("+message+")]";
    }

}
