package com.ceco.common.Enum;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum EnumDevicePanelType implements BaseEnum<Integer>{
    DEVICE_PANEL_TYPE_1(1,"彩光"),
    DEVICE_PANEL_TYPE_2(2,"白光"),
    DEVICE_PANEL_TYPE_3(3,"光效"),
    DEVICE_PANEL_TYPE_4(4,"音乐"),
    DEVICE_PANEL_TYPE_5(5,"节律"),
    DEVICE_PANEL_TYPE_6(6,"膜片");

    private final Integer value;
    private final String text;

    private EnumDevicePanelType(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    @Override
    public String getText() {
        return text;
    }


    public static String getTextByValue(Integer value) {
        EnumDevicePanelType[] enumDevicePanelTypes = values();
        for (EnumDevicePanelType enumDevicePanelType : enumDevicePanelTypes) {
            if (enumDevicePanelType.getValue() == value.intValue()) {
                return enumDevicePanelType.getText();
            }
        }
        return null;
    }

}
