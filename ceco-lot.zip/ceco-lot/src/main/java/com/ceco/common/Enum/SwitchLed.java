package com.ceco.common.Enum;

/**
 * @auther Dean
 * @Date 2021/10/18.
 */
public enum SwitchLed {
    TRUN_ON(1,"开灯"),
    TRUN_OFF(0,"关灯");
    private int value;
    private String desc;

    SwitchLed(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
