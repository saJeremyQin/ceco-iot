package com.ceco.common.Enum;

/**
 * @auther Dean
 * @Date 2021/10/18.
 */
public enum SwitchMode {
    White(1,"white"),
    colour(2,"colour"),
    Scene(3,"Scene"),
    Music(4,"Music");

    private int value;
    private String desc;
    SwitchMode(int value,String desc){
        this.value = value;
        this.desc = desc;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
