package com.ceco.common.utils;

import com.ceco.channel.common.model.req.BiorhythmResp;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.http.HttpApiService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/10/27.
 */
@Component
public class WeatherUtils {
    @Autowired
    private HttpApiService httpApiService;

    public static void main(String[] args) {
//        System.out.println(tranformPos("22°32′43.86"));
//        System.out.println(tranformPos("114°03′10.40"));
    }


    public BiorhythmResp getBiorhythm(Map map){
        String lng=(String)map.get("lng");//经度
        String lat=(String)map.get("lat");//纬度
        double lngD=tranformPos(lng);
        double latD=tranformPos(lat);
        String date=(String)map.get("date");
        String url="https://api.sunrise-sunset.org/json?lat="+latD+"&lng="+lngD+"&date="+date;
        //https://api.sunrise-sunset.org/json?lat=22.545517&lng=114.052889&date=2021-10-27
        Gson gson = new Gson();
        Map map1=new HashMap();
        BiorhythmResp biorhythmResp = new BiorhythmResp();
        try {
         String result=   httpApiService.doGet(url);
            map1=gson.fromJson(result,Map.class);
            if(map1.get("status").equals("OK")){
               biorhythmResp=   ConvertUtil.convert(map1.get("results"),BiorhythmResp.class);
            }

        } catch (Exception e) {
            throw new BusinessException("获取生物节律接口失败");
        }
        return biorhythmResp;
    }



    public  Double tranformPos(String lng){
        String[] lntArr = lng
                .trim()
                .replace("°", ";")
                .replace("′", ";")
                .replace("'", ";")
                .replace("\"", "")
                .split(";");
        Double result = 0D;
        for (int i = lntArr.length; i >0 ; i--) {
            double v = Double.parseDouble(lntArr[i-1]);
            if(i==1){
                result=v+result;
            }else{
                result=(result+v)/60;
            }
        }
        BigDecimal b=new BigDecimal(result);
        result=b.setScale(6,BigDecimal.ROUND_HALF_UP).doubleValue();
        return result;
    }
}
