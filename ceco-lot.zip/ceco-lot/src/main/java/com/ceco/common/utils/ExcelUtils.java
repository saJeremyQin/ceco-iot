//package com.ceco.common.utils;
//
//
//import joinery.DataFrame;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * @auther Dean
// * @Date 2021/11/22.
// */
//public class ExcelUtils {
//    public static void main(String[] args) {
//        String filePath= "E:\\test\\"+"aaa"+".csv";
//        List titleList=new ArrayList();titleList.add("name"); titleList.add("age");titleList.add("gender");
//
//        List contentList1=new ArrayList();
//        contentList1.add("caolihua");
//        contentList1.add("30");
//        contentList1.add("male");
//        List contentList2=new ArrayList();
//        contentList2.add("lifei");
//        contentList2.add("30");
//        contentList2.add("male");
//
//        List lineList=new ArrayList();
//        lineList.add(contentList1); lineList.add(contentList2);
//
//
//        ExcelUtils.writeCSV(titleList,lineList,filePath);
//
//    }
//
//
//    /**
//     * CSV文件生成工具
//     * @param titleList  CSV 标题数组
//     * @param colList   CSV 行记录,二维数组
//     * @param filePath  文件保存路径
//     */
//    public static void writeCSV(List<String> titleList, List<List>colList, String filePath){
//        //创建
//        DataFrame<Object> df = new DataFrame<>(titleList);
//        for(List list:colList){
//            df.append(list);
//        }
//
//        //保存为csv文件
//        try {
//            df.writeCsv(filePath);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
