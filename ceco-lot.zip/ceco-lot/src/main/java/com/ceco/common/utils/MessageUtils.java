package com.ceco.common.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

@Component
public class MessageUtils {

    @Autowired
    MessageSource messageSource;

    public  String getLocale(String msg) {
        MessageSource messageSource = SpringUtil.getBean(MessageSource.class);
        try {
            System.out.println( LocaleContextHolder.getLocale());
            return messageSource.getMessage(msg, null, LocaleContextHolder.getLocale());
        } catch (Exception e) {
            return msg;
        }
    }

}
