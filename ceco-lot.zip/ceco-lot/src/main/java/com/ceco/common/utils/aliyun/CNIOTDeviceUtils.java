package com.ceco.common.utils.aliyun;

import com.aliyun.iot20180120.Client;
import com.aliyun.iot20180120.models.QueryDeviceInfoRequest;
import com.aliyun.iot20180120.models.QueryDeviceInfoResponse;
import com.aliyun.iot20180120.models.SetDevicePropertyResponse;
import com.aliyun.teaopenapi.models.Config;
import com.ceco.channel.app.model.req.deviceUpdateReq.AL1LightStripThingModel;
import com.ceco.configure.AliIOT.CNIOTConfig;
import com.ceco.configure.AliIOT.USIOTConfig;
import com.ceco.module.service.IDeviceService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.aliyun.iot20180120.models.SetDevicePropertyRequest;
/**
 * @auther Dean
 * @Date 2021/10/21.
 */
@Component
public class CNIOTDeviceUtils {
    @Autowired
    private Client cnIotClient;

    @Autowired
    private CNIOTConfig cniotConfig;

    @Autowired
    private USIOTConfig usiotConfig;

    @Autowired
    private IDeviceService iDeviceService;

    /**
     * 查询设备ID。由 CN 的Clinent提供接口
     * @param deviceName
     * @return
     */
    public String getDeviceId(String deviceName){
        QueryDeviceInfoRequest queryDeviceInfoRequest = new QueryDeviceInfoRequest()
                .setProductKey(usiotConfig.getLotProductKey())
                .setDeviceName(deviceName);
        QueryDeviceInfoResponse resp=null;
        try {
            Config config = new Config()
                    .setAccessKeyId(cniotConfig.getAccessKeyId())
                    .setAccessKeySecret(cniotConfig.getAccessKeySecret());
            // 访问的域名
            //设置为美国的端点
            config.endpoint = usiotConfig.getUsWestDomain();
            com.aliyun.iot20180120.Client client = new com.aliyun.iot20180120.Client(config);
            //要用中国的client 才能查询设备ID
             resp = client.queryDeviceInfo(queryDeviceInfoRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resp.body.data.iotId;
    }

    public  boolean cnControlDevice(String deviceName,  AL1LightStripThingModel AL1LightStripThingModel) {
        Gson gson= new Gson();
        SetDevicePropertyRequest setDevicePropertyRequest = new SetDevicePropertyRequest();
        setDevicePropertyRequest.setIotInstanceId(cniotConfig.getInstanceId());

        //需要产品类型
//        Device deviceEntity= iDeviceService.getOne(new QueryWrapper<Device>().lambda().eq(Device::getName,deviceName));
//        setDevicePropertyRequest.setProductKey(deviceEntity.getProductKey());
        setDevicePropertyRequest.setProductKey(AL1LightStripThingModel.getProductKey());
        setDevicePropertyRequest.setDeviceName(deviceName);
        AL1LightStripThingModel.setLocale(null);
        setDevicePropertyRequest.setItems(gson.toJson(AL1LightStripThingModel));
        try {
            SetDevicePropertyResponse response= cnIotClient.setDeviceProperty(setDevicePropertyRequest);
            //
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;

    }
}
