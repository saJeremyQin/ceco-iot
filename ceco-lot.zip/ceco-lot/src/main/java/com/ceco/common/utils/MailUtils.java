package com.ceco.common.utils;

import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.aliyun.AliyunPhoneCodeUtils;
import com.ceco.configure.EmailConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Component;

import static com.ceco.common.utils.Constants.*;


@Component
@Slf4j
public class MailUtils {


    @Autowired
    EmailConfig emailConfig;

    @Autowired
    RedisTemplate redisTemplate;


    public boolean sendMailCode(String address){
        log.info(address);
        if (address == null || address == "") {
            log.info("邮箱地址为空");
            throw new BusinessException("邮箱地址为空");
        }

        if (!StringUtil.isEmail(address)) {
            log.info("邮箱地址错误");
            throw  new BusinessException("邮箱地址错误");
        }
        String code = AliyunPhoneCodeUtils.vcode();
        Object o = redisTemplate.opsForValue().get(VERIFY_EXPIRE+"_"+address);
        if(o != null){
            throw new BusinessException("邮件发送消息过频繁,请稍后再试");
        }
        String [] arr = new String[]{address};
        String subject = "  your  verification code";//邮件主题
        String name = "ceco";//发件人昵称展示
        String host = "smtp.ym.163.com";//163企业邮箱smtp
        Double random = Math.random();//随机数
        String nuberm = random.toString();
        nuberm =  nuberm.substring(nuberm.length()-4,nuberm.length());
        StringBuffer content = new StringBuffer();//内容
        content.append("<html><head></head>");
        content.append("<body><div><h2>Confirm your email </h2>Please enter this verification code to get started on ceco:\n" +
                " \n" +
                code +
                " \n" +
                "Verification codes expire after two hours'");
        content.append("</body></html>");
        try {
            sendHtmlMail(name,arr,subject,content.toString());
            redisTemplate.opsForValue().set(VERIFY_USER_CODE+"_"+address,code,VERIFY_EXPIRE, TimeUnit.MINUTES);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private  void sendHtmlMail(String from, String[] to, String subject, String text) throws Exception {
        //设置服务器验证信息
        Properties prop = new Properties();
        prop.setProperty("mail.smtp.auth", "true");
        prop.setProperty("mail.smtp.timeout", "465");

        //设置邮件内容
        JavaMailSenderImpl javaMailSend = new JavaMailSenderImpl();
        MimeMessage message = javaMailSend.createMimeMessage();
        MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "utf-8");
        String nick = MimeUtility.encodeText(from);//设置昵称
        messageHelper.setFrom(new InternetAddress(nick + " <" + emailConfig.getUsername() + ">"));// 邮件发送者
        messageHelper.setTo(to);
        messageHelper.setSubject(subject);
        messageHelper.setText(text, true);

        //设置邮件服务器登录信息
        javaMailSend.setHost(emailConfig.getHost());
        javaMailSend.setUsername(emailConfig.getUsername());
        javaMailSend.setPassword(emailConfig.getPassword());
        javaMailSend.setJavaMailProperties(prop);
        javaMailSend.send(message);
    }



}
