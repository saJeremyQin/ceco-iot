package com.ceco.common.utils.algorithm;

/**
 * @auther Dean
 * @Date 2021/10/19.
 */
public class RGBWUtils {
    public static void main(String[] args) {

//        System.out.println(rgbHex2RgbcwAlgorithm2("ffffff",1.1));
        System.out.println(rgbHex2RgbcwAlgorithm1("45dbdb"));
    }




    /**
     * 算法1 ：  将RGB Hex  转为  RGBCW Hex
     * @param rgbHex
     * @return
     */
    public  static String rgbHex2RgbcwAlgorithm1(String rgbHex){
        int rgbIntArrays[]=  rgbHex2RgbIntArrays(rgbHex);
        int redInt=rgbIntArrays[0];
        int greenInt=rgbIntArrays[1];
        int blueInt=rgbIntArrays[2];

         int tmp=  rgbInt2White1(redInt,greenInt,blueInt);
         String warm="00";
         String cold="00";
         // 0-99为 warm ,100-255为cold
        if(tmp>=100){
            cold=int2Hex(tmp);
        }else{
            warm=int2Hex(tmp);
        }
        return  int2Hex(redInt)+int2Hex(greenInt)+int2Hex(blueInt)+warm+cold;
    }


    /**
     * 获取白光值.
     * 输入为RGB ,输出为RGBCW,输出的RGB不变，CW是计算结果
     * @param redInt
     * @param greenInt
     * @param blueInt
     * @return
     */
    public  static int rgbInt2White1(int redInt,int greenInt,int blueInt){
        float low=Math.min(redInt,Math.min(greenInt,blueInt));
        float high=Math.max(redInt,Math.max(greenInt,blueInt));
        int saturation=Math.round(100*(high-low)/high);
        double xxx= (255-saturation)/255.0*(redInt+greenInt+blueInt)/3;
        long whiteL=Math.round(xxx);
        return (int)whiteL;
    }


    /**
     * 获取白光值
     * 输入为RGB ,输出为RwGwBwCW,输出的由R->Rw,G->Gw,B->Bw和C,W
     * 白色分量提取法

     * @return
     */
    public  static String  rgbHex2RgbcwAlgorithm2(String rgbHex,double a){
        int rgbIntArrays[]=  rgbHex2RgbIntArrays(rgbHex);
        int redInt=rgbIntArrays[0];
        int greenInt=rgbIntArrays[1];
        int blueInt=rgbIntArrays[2];

        float low=Math.min(redInt,Math.min(greenInt,blueInt));
        float high=Math.max(redInt,Math.max(greenInt,blueInt));

        float W_=low;
        double M=low/high;
        double W=W_*a;

        double Rw=(1+M)*redInt-W;
        double Gw=(1+M)*greenInt-W;
        double Bw=(1+M)*blueInt-W;

         int RwInt=  (int)Math.round(Rw);
        int GwInt=  (int)Math.round(Gw);
        int BwInt=  (int)Math.round(Bw);
        int WInt =(int)Math.round(W);

        String warm="00";
        String cold="00";
        // 0-99为 warm ,100-255为cold
        if(WInt>=100){
            cold=Integer.toHexString(WInt);
        }else{
            warm=Integer.toHexString(WInt);
        }
        return  int2Hex(RwInt)+int2Hex(GwInt)+int2Hex(BwInt)+warm+cold;

    }


    /**
     * 将RGB  HEX 转为 RGB Int Arrays
     * @param rgbHex
     * @return
     */
    public  static int[] rgbHex2RgbIntArrays(String rgbHex) {
        String redHex=rgbHex.substring(0,2);
        String greenHex=rgbHex.substring(2,4);
        String blueHex=rgbHex.substring(4,6);
        int redInt=Integer.parseInt(redHex,16);
        int greenInt=Integer.parseInt(greenHex,16);
        int blueInt=Integer.parseInt(blueHex,16);
        int rgbIntArrays[]=new int[]{redInt,greenInt,blueInt};
        return rgbIntArrays;
    }


    /**
     * 将int 类型转为16进制字符串。int 为2字节
     * @param val
     * @return
     */
    public static String int2Hex(int val){
        String result=Integer.toHexString(val);
        if(result.length()<2){
            return "0"+result;
        }
        return result;
    }
}
