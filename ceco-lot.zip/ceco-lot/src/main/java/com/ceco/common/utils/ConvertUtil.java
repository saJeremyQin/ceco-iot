package com.ceco.common.utils;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

/**
 * 类型转换工具类
 * @author gjy
 * @since 2020-03-21
 */
@Slf4j
public class ConvertUtil {

    /**
     * 实体转换:1.将Map转为Object
     * 2.Object之间属性copy
     * @param source
     * @param target
     * @param <T>
     * @return
     */
    public static <T> T convert(Object source, @NonNull Class<T> target) {
        if (Objects.isNull(source)) {
            return null;
        }
        T targetObject = null;
        try {
            targetObject = target.newInstance();
            BeanUtil.copyProperties(source, targetObject);
        } catch (InstantiationException | IllegalAccessException e) {
            log.error("convertObject error", e);
        }
        return targetObject;
    }

    /**
     * 列表转换
     * @param sourceList
     * @param target
     * @param <T>
     * @return
     */
    public static <T> List<T> convert(Collection<?> sourceList, @NonNull Class<T> target) {
        List<T> targetList = CollectionUtil.newArrayList();
        if (CollectionUtil.isEmpty(sourceList)) {
            return targetList;
        }
        sourceList.forEach(item -> {
            try {
                T targetObject = target.newInstance();
                BeanUtil.copyProperties(item, targetObject);
                targetList.add(targetObject);
            } catch (InstantiationException | IllegalAccessException e) {
                log.error("convertList error", e);
            }
        });
        return targetList;
    }

    /**
     * 将Object 转为Map:Object 为null的字段不忽略
     * @param obj
     * @return
     */
    public static HashMap<String, Object> convertToMap(Object obj) {
        HashMap<String, Object> map = new HashMap< >();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (int i = 0, len = fields.length; i < len; i++) {
            String varName = fields[i].getName();
            boolean accessFlag = fields[i].isAccessible();//反射默认无权限操作
            fields[i].setAccessible(true);//设置为true，有权限操作
            Object o = null;
            try {
                o = fields[i].get(obj);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            if (o != null) map.put(varName, o);
            fields[i].setAccessible(accessFlag);
        }
        return map;
    }

    /**
     * 将Object转为map：object的字段为null的则忽略
     * @param obj
     * @return
     */
    public static HashMap<String, Object> convertToMapNotEmpty(Object obj) {
        HashMap<String, Object> map = new HashMap< >();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (int i = 0, len = fields.length; i < len; i++) {
            String varName = fields[i].getName();
            boolean accessFlag = fields[i].isAccessible();//反射默认无权限操作
            fields[i].setAccessible(true);//设置为true，有权限操作
            Object o = null;
            try {
                o = fields[i].get(obj);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            if (o == null||o.equals("")) {
                continue;
            }
            map.put(varName, o);
            fields[i].setAccessible(accessFlag);
        }
        return map;
    }

}
