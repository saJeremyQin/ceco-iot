package com.ceco.common.utils.aws;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSONObject;
import com.amazonaws.services.iot.client.AWSIotDevice;
import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ceco.channel.app.model.req.AwsThingData;
import com.ceco.channel.service.IApiDeviceInfoService;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.CurrentContext;
import com.ceco.common.utils.LogInfoUtils;
import com.ceco.common.utils.StringUtil;
import com.ceco.configure.aws.AWSConfig;
import com.ceco.module.entity.Device;
import com.ceco.module.entity.DeviceModel;
import com.ceco.module.entity.device.DeviceInfo;
import com.ceco.module.service.IDeviceModelService;
import com.ceco.module.service.IDeviceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import software.amazon.awssdk.services.iot.IotClient;
import software.amazon.awssdk.services.iot.model.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/11/17.
 */
@Component
@Slf4j
public class IOTCoreUtils {
    @Autowired
    private IotClient iotClient;

    @Autowired
    private AWSConfig awsConfig;

    @Autowired
    private IApiDeviceInfoService iApiDeviceInfoService;

    @Autowired
    private IDeviceService deviceService;

    @Autowired
    private IDeviceModelService deviceModelService;


    //目前测试阶段，一型一密，用一个证书
    private String  principal="arn:aws:iot:us-east-2:936716451258:cert/88c82404d0c223196676443f2e47f05dc15049064f7329679a6a256ff0f9f856";
    private static int INTERNAL_FAILURE_EXCEPTION_CODE=500;
    private static int RESPONSE_SUCCESS_CODE=200;

    //首次创建或重新配网都会调用这些接口

    /**
     * 嵌入式调用---> 1创建物品
     * 首次创建设备
     * @param serialNo 物品名称,采用mac地址
     */
    @Transactional
    public void createThing(String serialNo,String productKey){
        log.info("设备注册=====》 注册序列号:" +serialNo);
        //密钥鉴权
        //aws 创建物品
        if(StringUtil.isEmpty(serialNo)||StringUtil.isEmpty(productKey)){
            throw new BusinessException("缺少必传的参数thingName or productKey");
        }

        CreateThingRequest createThingRequest=CreateThingRequest.builder().thingName(serialNo).thingTypeName(productKey).build();
        CreateThingResponse res=null;
        try {
            res=iotClient.createThing(createThingRequest);
        } catch (ResourceNotFoundException e) {
           log.info(LogInfoUtils.errorInfo("IOTCoreUtils","createThing","设备类型不存在:"+productKey));
            throw new BusinessException("设备类型不存在:"+serialNo);
        }
        int statusCode=  res.sdkHttpResponse().statusCode();
         if(statusCode==RESPONSE_SUCCESS_CODE){
             Map resMap=new HashMap();
             resMap.put("statusCode",statusCode);
             resMap.put("serialNo",serialNo);
             String message= JSONObject.toJSONString(resMap);
             log.info(LogInfoUtils.successInfo("IOTCoreUtils","createThing",message));
             //创建成功，写入DB，创建设备
             DeviceInfo deviceInfoReq =new DeviceInfo();
             deviceInfoReq.setSerialNo(serialNo);
             deviceInfoReq.setProductKey(productKey);

             //aws db 可以重复注册设备
            DeviceInfo deviceInfo=iApiDeviceInfoService.queryOne(deviceInfoReq);
            if(deviceInfo!=null){
                return ;
            }
             iApiDeviceInfoService.save(deviceInfoReq);


         }else{
             Map resMap=new HashMap();
             resMap.put("statusCode",statusCode);
             resMap.put("serialNo",serialNo);
             String message= JSONObject.toJSONString(resMap);
             log.info(LogInfoUtils.errorInfo("IOTCoreUtils","createThing",message));
         }
    }

    /**
     * 嵌入式调用--->2创建物品经典影子
     * 此时该物品还没有影子
     * @param serialNo
     */
    public void createThingShadow(String serialNo,String productKey){
        log.info("创建物品经典影子=====》 注册序列号:" +serialNo);

        if(StringUtil.isEmpty(serialNo)||StringUtil.isEmpty(productKey)){
            throw new BusinessException("缺少必传的参数thingName or thingType");
        }
        AWSIotMqttClient awsIotMqttClient=awsConfig.getAWSIotMqttClient();
        try {
            awsIotMqttClient.connect();

            Class class1=null;
            Object ooo=null;

            class1=Class.forName("com.ceco.channel.service.thing.model.aws1."+productKey);
            ooo=  class1.newInstance();

            AWSIotDevice device = new AWSIotDevice(serialNo);
            String shadowDocJson=JSONObject.toJSONString(ooo);

            awsIotMqttClient.attach(device);
            device.update(shadowDocJson);

        } catch (AWSIotException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } finally {
            try {
                awsIotMqttClient.disconnect();
            } catch (AWSIotException e) {
                e.printStackTrace();
            }
        }


    }

    /**
     * 暂时不调用--->3policy->principal
     * 可以aws 控制台设置。后续定制化功能变多，通过接口更改
     * @param policy
     * @param principal
     */
    public void attachPolicy2Certificate(String principal,String policy){
        AttachPolicyRequest.Builder builder =AttachPolicyRequest.builder();
        principal=this.principal;
        builder.policyName("policy");//单一策略。全部设备统一
        builder.target(principal); //证书arn
        iotClient.attachPolicy(builder.build());

    }

    /**
     * 嵌入式调用--->4证书附加物品  thingName->principal
     * @param principal  can be a certificate ARN
     * @param serialNo
     */
    @Transactional
    public void attachThing2Certificate(String principal,String serialNo){
        AttachThingPrincipalRequest.Builder builder=AttachThingPrincipalRequest.builder();
        principal=this.principal;//证书arn
        builder.thingName(serialNo);
        builder.principal(principal);
        iotClient.attachThingPrincipal(builder.build());

        //更新DB 的设备激活状态....
        DeviceInfo deviceInfoReq =new DeviceInfo();
        deviceInfoReq.setSerialNo(serialNo);
        iApiDeviceInfoService.update(deviceInfoReq);

    }

}
