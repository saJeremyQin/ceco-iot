package com.ceco.common.utils.aws;

import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.model.*;
import com.ceco.common.exception.BusinessException;
import com.ceco.common.utils.aliyun.AliyunPhoneCodeUtils;
import com.ceco.configure.aws.AWSConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import static com.ceco.common.utils.Constants.VERIFY_EXPIRE;
import static com.ceco.common.utils.Constants.VERIFY_USER_CODE;

/**
 * @auther Dean
 * @Date 2021/11/4.
 */
@Component
@Slf4j
public class SESUtils {
    @Resource(name="awsSesBean")
    private AmazonSimpleEmailService amazonSimpleEmailService;
    @Autowired
    RedisTemplate redisTemplate;

    private String FROM="no-reply@cecoceco.com";



    public  boolean sendMailCode(String address){
        //邮件主题，找回密码
        String code = AliyunPhoneCodeUtils.vcode();
        Object o = redisTemplate.opsForValue().get(VERIFY_EXPIRE+"_"+address);
        if(o != null){
            throw new BusinessException("邮件发送消息过频繁,请稍后再试");
        }

        String subject = "  your  verification code";//邮件主题
        StringBuffer content = new StringBuffer();//内容
        content.append("<html><head></head>");
        content.append("<body><div><h2>Confirm your email </h2>Please enter this verification code to get started on ceco:\n" +
                " \n" +
                code +
                " \n" +
                "Verification codes expire after two hours'");
        content.append("</body></html>");

        AmazonSimpleEmailService client=  amazonSimpleEmailService;
        SendEmailRequest request = new SendEmailRequest()
                .withDestination(
                        new Destination().withToAddresses(address))
                .withMessage(new Message()
                        .withBody(new Body()
                                .withHtml(new Content()
                                        .withCharset("UTF-8").
                                                withData(content.toString())).clone()  //设置内容
                                .withText(new Content()
                                        .withCharset("UTF-8").withData("")))
                        .withSubject(new Content()
                                .withCharset("UTF-8").withData(subject))) //设置主题
                .withSource(FROM);

        try {
            client.sendEmail(request);
            redisTemplate.opsForValue().set(VERIFY_USER_CODE+"_"+address,code,VERIFY_EXPIRE, TimeUnit.MINUTES);
        } catch (Exception e) {
            e.printStackTrace();
            return  false;
        }
        return true;
    }
}
