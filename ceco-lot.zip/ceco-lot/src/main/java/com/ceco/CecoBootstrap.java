package com.ceco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CecoBootstrap {

    public static void main(String[] args) {
         SpringApplication.run(CecoBootstrap.class, args);
    }



}
