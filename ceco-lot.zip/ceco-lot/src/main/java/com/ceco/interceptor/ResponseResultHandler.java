package com.ceco.interceptor;

import com.ceco.common.utils.response.ResponseModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.util.Objects;

//@RestControllerAdvice(basePackages = "com.ceco.channel")
//这些包的返回码限定死了，只能以200返回，boolean 或500。无法指定其他业务编码
@RestControllerAdvice(basePackages ={"com.ceco.channel.admin","com.ceco.channel.app","com.ceco.channel.common"})
@Slf4j
@Component
public class ResponseResultHandler implements ResponseBodyAdvice {
    @Override
    public boolean supports(MethodParameter methodParameter, Class aClass) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object o, MethodParameter methodParameter, MediaType mediaType, Class aClass, ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse) {
        if(Objects.isNull(o)){
            return ResponseModel.SUCCESS_CODE;
        }
         return ResponseModel.success(o);
    }
}
