package com.ceco.interceptor.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.Method;

/**
 * @author lazycece
 * @date 2019/2/15
 */
public class EnumValidator implements ConstraintValidator<CecoEnum, Object> {

    private CecoEnum annotation;

    @Override
    public void initialize(CecoEnum constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        //自定义注解 传入参数可以为空
        if (value == null) {
            return true;
        }

        Object[] objects = annotation.clazz().getEnumConstants();
        try {
            Method method = annotation.clazz().getMethod(annotation.method());
            for (Object o : objects) {
                if (value.equals(method.invoke(o))) {
                    return true;
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return false;
    }
}
