package com.ceco.configure.aws;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;

/**
 * @auther Dean
 * @Date 2021/11/17.
 * aws sdk2认证
 *
 */
@Component
@Configuration
public class AWSCredentialsProviderImpl implements AwsCredentialsProvider {
    @Value("${aws.account.appkey}")
    private String appKey;

    @Value("${aws.account.appsecret}")
    private String appSecret;
    @Override
    public AwsCredentials resolveCredentials() {
        return new AwsCredentials(){
            @Override
            public String accessKeyId() {
                return appKey;
            }

            @Override
            public String secretAccessKey() {
                return appSecret;
            }
        };

    }
}
