package com.ceco.configure.AliIOT.life;

import com.alibaba.cloudapi.sdk.model.HttpClientBuilderParams;

/**
 * @auther Dean
 * @Date 2021/10/29.
 */
public class IoTApiClientBuilderParams extends HttpClientBuilderParams {
}
