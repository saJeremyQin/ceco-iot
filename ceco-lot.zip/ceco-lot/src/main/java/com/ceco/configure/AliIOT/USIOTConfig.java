package com.ceco.configure.AliIOT;

import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.ceco.common.exception.BusinessException;
import lombok.Data;
import org.omg.CORBA.SystemException;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import com.aliyuncs.DefaultAcsClient;

/**
 * @auther Dean
 * @Date 2021/10/15.
 */
@Configuration
@Component
@ConfigurationProperties(prefix = "aliyun.iot.us")
@Data
public class USIOTConfig {
    private String accessKeyId;
    private String accessKeySecret;
    private String lotProductKey;
    private String usRegionId;
    private String usProductCode;
    private String usWestDomain;
    private String version;


    @Bean
    public DefaultAcsClient getUSIOTClient(){
        DefaultAcsClient client;
        IClientProfile profile = DefaultProfile.getProfile(usRegionId, accessKeyId, accessKeySecret);
        try {
            DefaultProfile.addEndpoint(usRegionId, usRegionId, usProductCode,usWestDomain);
            client = new DefaultAcsClient(profile);
        } catch (ClientException e) {
            throw  new BusinessException("us iot client 初始化失败");
        }
        return client;
    }





}
