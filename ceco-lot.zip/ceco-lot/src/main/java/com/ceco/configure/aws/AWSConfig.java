package com.ceco.configure.aws;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.iot.IotClient;

import java.util.UUID;

/**
 * @auther Dean
 * @Date 2021/11/4.
 */
@Configuration
@Component
@ConfigurationProperties(prefix = "aws.account")
@Data
public class AWSConfig {
    private String appkey;
    private String appsecret;
    private String iotCoreClientEndpoint;
    private Regions awsSDK1Region=Regions.US_EAST_2;
    private Region awsSDK2Region=Region.US_EAST_2;

    @Autowired
    private AwsCredentialsProvider awsCredentialsProvider;
    /**
     * aws sdk1 创建凭证
     * @return
     */
    @Bean
    public AWSCredentials getAWSCredentials(){
        return new BasicAWSCredentials(appkey,appsecret);
    }

    /**
     * aws 邮件服务
     * @param aWSCredentials
     * @return
     */
    @Bean(name="awsSesBean")
    public  AmazonSimpleEmailService getAmazonSimpleEmailService(AWSCredentials aWSCredentials){
        AmazonSimpleEmailService client =
                AmazonSimpleEmailServiceClientBuilder.standard()
                        .withRegion(awsSDK1Region).withCredentials(new AWSStaticCredentialsProvider(aWSCredentials)).build();
        return client;
    }

    /**
     * aws存储桶服务
     * @param aWSCredentials
     * @return
     */
    @Bean
    public  AmazonS3 getAmazonS3(AWSCredentials aWSCredentials){
        AmazonS3 s3= AmazonS3ClientBuilder.standard()
                .withRegion(awsSDK1Region).withCredentials(new AWSStaticCredentialsProvider(aWSCredentials)).build();
        return s3;
    }

    /**
     * iot core服务
     * @return
     */
    @Bean
    public IotClient getIotClient(){
        IotClient iotClient=IotClient.builder().region(awsSDK2Region).credentialsProvider(awsCredentialsProvider).build();
        return iotClient;
    }


    /**
     * aws iot client 直接下发topic
     * @return
     */
    public  AWSIotMqttClient getAWSIotMqttClient( ){
        AWSIotMqttClient awsIotMqttClient=new  AWSIotMqttClient(iotCoreClientEndpoint, UUID.randomUUID()+"", appkey, appsecret);
        return awsIotMqttClient;
    }

}
