package com.ceco.configure.AliIOT.life;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * @auther Dean
 * @Date 2021/10/29.
 * 阿里云IOT 生活物联网平台配置文件
 */
@Configuration
@Component
@ConfigurationProperties(prefix = "aliyun.iot.life")
@Data
public class AL1IOTConfig {
    private String projectId; //项目ID  一个项目里可以放多个产品 如灯带、灯泡
    private String appKey;      //每个项目有一个唯一的appKey
    private String appSecret; //每个项目有个一个唯一的appSecret
    private String chinaHost; //中国区
    private String usHost;//美国区
    private String euHost;//欧洲区
    public static Map<String,String> productKey2TingMoelMap=new HashMap();

    @Bean
    public SyncApiClient syncApiClient(){
        IoTApiClientBuilderParams ioTApiClientBuilderParams =
                new IoTApiClientBuilderParams();
        ioTApiClientBuilderParams.setAppKey(appKey);
        ioTApiClientBuilderParams.setAppSecret(appSecret);
        SyncApiClient syncClient = new SyncApiClient(ioTApiClientBuilderParams);
        return syncClient;
    }

    /**
     * 初始化 productKey ->ThingModel
     */
    @PostConstruct
    private void init(){
        productKey2TingMoelMap.put("a1KN3RmnLWb","com.ceco.channel.service.thing.model.ali1.AL1LightStripThingModelX"); //定制
        productKey2TingMoelMap.put("a1rP2pEvHmo","com.ceco.channel.service.thing.model.ali1.AL1LightStripThingModelY");//公版
    }
}
