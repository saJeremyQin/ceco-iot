package com.ceco.configure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableSwagger2
public class SwaggerConfig {


    @Bean
    public Docket buildSysDocket() {
//        List<Parameter> aParameters = getParameters();

        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("管理端API接口文档")
                .apiInfo(buildApiInf())
//                .globalOperationParameters(aParameters)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.ceco.channel.admin"))//controller路径
                .paths(PathSelectors.any()).build().securitySchemes(securitySchemes())
                .securityContexts(securityContexts());
    }
    @Bean
    public Docket buildH5Docket() {
//        List<Parameter> aParameters = getParameters();
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("App接口文档")
                .apiInfo(buildApiInf())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.ceco.channel.app"))//controller路径
                .paths(PathSelectors.any()).build().securitySchemes(securitySchemes())
                .securityContexts(securityContexts());
    }

    @Bean
    public Docket buildCommonDocket() {
//        List<Parameter> aParameters = getParameters();

        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("公共接口文档")
                .apiInfo(buildApiInf())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.ceco.channel.common"))//controller路径
                .paths(PathSelectors.any()).build().securitySchemes(securitySchemes())
                .securityContexts(securityContexts());
    }
    @Bean
    public Docket buildThirdPartDocket() {
//        List<Parameter> aParameters = getParameters();

        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("第三方服务接口文档")
                .apiInfo(buildApiInf())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.ceco.channel.thridPart"))//controller路径
                .paths(PathSelectors.any()).build().securitySchemes(securitySchemes())
                .securityContexts(securityContexts());
    }


//    private List<Parameter> getParameters() {
//        ParameterBuilder aParameterBuilder = new ParameterBuilder();
//        aParameterBuilder
//                .parameterType("header") //参数类型支持header, cookie, body, query etc
//                .name("Authorization") //参数名
//                .defaultValue("eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxIiwibm9uY2UiOiI3MTViNDgzNC1hOTk0LTQ4MjktOTE5ZS1iYjNlODA2Y2NkNGEiLCJzeXN0ZW1LZXkiOiJwYyIsInVpZCI6IjEiLCJ1bmFtZSI6IuW8oOS4iSIsIm1vYmlsZSI6IjE4NjY2OTc4Njg2IiwiZXhwIjoxOTQ5Nzk0MzQ1fQ.ADocTbZIsfQRlbVCST18Mtuxmb5s18p8jj1fp0FRzUY2JdmOr-Z6HRX0FVYZ_vr5YnRRHwtH3ZIp5JqClVqnCCfzkSnKjWSoJ_QZ4i8eONmNeqg9xave1Qi-KPpEKUdnQfY4nwRBFUdjDniWsS4X0c9zR7cYvDGEwRzF0GsKPsU")
//                .description("token令牌")
//                .modelRef(new ModelRef("string"))//指定参数值的类型
//                .required(false).build(); //非必需，这里是全局配置，然而在登陆的时候是不用验证的
//        List<Parameter> aParameters = new ArrayList<Parameter>();
//        aParameters.add(aParameterBuilder.build());
//        return aParameters;
//    }

    private List<ApiKey> securitySchemes() {
        List<ApiKey> apiKeyList= new ArrayList();
        apiKeyList.add(new ApiKey("Authorization", "Authorization", "header"));
        return apiKeyList;
    }

    private List<SecurityContext> securityContexts() {
        List<SecurityContext> securityContexts=new ArrayList<>();
        securityContexts.add(
                SecurityContext.builder()
                        .securityReferences(defaultAuth())
                        .forPaths(PathSelectors.regex("^(?!auth).*$"))
                        .build());
        return securityContexts;
    }

    List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        List<SecurityReference> securityReferences=new ArrayList<>();
        securityReferences.add(new SecurityReference("Authorization", authorizationScopes));
        return securityReferences;
    }
    private ApiInfo buildApiInf() {
        return new ApiInfoBuilder()
                .title("物联网平台")
                .description("物联网平台")
                .version("1.0")
                .build();

    }
}
