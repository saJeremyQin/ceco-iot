package com.ceco.module.service;

import com.ceco.channel.app.model.resp.GroupResp;
import com.ceco.module.entity.Group;
import com.baomidou.mybatisplus.extension.service.IService;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 群组设置 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
public interface IGroupService extends IService<Group> {

    /**
     * 查询家庭关联的群组信息
     * @param appUserId
     * @return
     */
    List<GroupResp> selectHomeGroup ( String appUserId);
}
