package com.ceco.module.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ceco.module.dao.SceneConfMapper;
import com.ceco.module.dao.SceneParamMapper;
import com.ceco.module.entity.SceneConf;
import com.ceco.module.entity.SceneParam;
import com.ceco.module.service.ISceneConfService;
import com.ceco.module.service.ISceneParamService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 动态灯效配置 服务实现类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Service
public class SceneParamServiceImpl extends ServiceImpl<SceneParamMapper, SceneParam> implements ISceneParamService {
    @Override
    public String selectSceneParamBySceneConfIdService(String sceneConfId) {
        return baseMapper.selectSceneParamBySceneConfIdDAO(sceneConfId);
    }
}
