package com.ceco.module.service.impl;

import com.ceco.module.entity.WeeklySchedule;
import com.ceco.module.dao.WeeklyScheduleMapper;
import com.ceco.module.service.IWeeklyScheduleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dean
 * @since 2021-11-09
 */
@Service
public class WeeklyScheduleServiceImpl extends ServiceImpl<WeeklyScheduleMapper, WeeklySchedule> implements IWeeklyScheduleService {

}
