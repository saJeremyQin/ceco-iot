package com.ceco.module.dao;

import com.ceco.channel.admin.model.resp.SceneResp;
import com.ceco.module.entity.SceneConf;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 动态灯效配置 Mapper 接口
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Mapper
public interface SceneConfMapper extends BaseMapper<SceneConf> {


    List<SceneResp> selectSceneConfByDevice(@Param("deviceId") String deviceId);

}
