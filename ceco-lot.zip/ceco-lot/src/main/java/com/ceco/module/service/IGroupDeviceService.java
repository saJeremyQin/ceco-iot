package com.ceco.module.service;

import com.ceco.module.entity.GroupDevice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 群组设备 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
public interface IGroupDeviceService extends IService<GroupDevice> {

}
