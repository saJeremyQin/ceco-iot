package com.ceco.module.entity.device;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ceco.common.utils.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author dean
 * @since 2021-11-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("ce_device_info")
public class DeviceInfo extends BaseEntity implements BaseDeviceInfo {

    private static final long serialVersionUID=1L;

    /**
     * 设备在线状态：1 开灯 关灯
     */
    @TableField
    private Integer switchLed;

    /**
     * 设备激活状态：1激活 0未激活
     */
    private Integer activationStatus;

    /**
     * 设备mac地址
     */
    private String serialNo;

    /**
     * 设备密钥
     */
    private String productKey;

    /**
     * 固件版本号
     */
    private String firmwareVersion;

    private Integer tempValue;

    private String colourData;

    private Integer brightValue;


    private Integer connected;


}
