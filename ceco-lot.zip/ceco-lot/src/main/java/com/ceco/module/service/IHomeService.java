package com.ceco.module.service;

import com.ceco.module.entity.Home;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 家庭设置 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
public interface IHomeService extends IService<Home> {

}
