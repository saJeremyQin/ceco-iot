package com.ceco.module.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ceco.common.utils.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author dean
 * @since 2021-11-09
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("ce_biorhythm")
public class Biorhythm extends BaseEntity {

    private static final long serialVersionUID=1L;

    /**
     * 用户id
     */
    private String appUserId;

    /**
     * 设备编码
     */
    private String serialNo;

    /**
     * 日出
     */
    private Integer sunrise;

    /**
     * 中午
     */
    private Integer noon;

    /**
     * 日落
     */
    private Integer sunset;

    /**
     * 入睡
     */
    private Integer sleep;



}
