package com.ceco.module.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ceco.module.entity.SceneConf;
import com.ceco.module.entity.SceneParam;

/**
 * <p>
 * 动态灯效配置 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
public interface ISceneParamService extends IService<SceneParam> {
    String selectSceneParamBySceneConfIdService(String sceneConfId);
}
