package com.ceco.module.service.impl;

import com.ceco.channel.admin.model.resp.ModelResp;
import com.ceco.channel.admin.model.resp.SceneResp;
import com.ceco.module.entity.SceneConf;
import com.ceco.module.dao.SceneConfMapper;
import com.ceco.module.service.ISceneConfService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 动态灯效配置 服务实现类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Service
public class SceneConfServiceImpl extends ServiceImpl<SceneConfMapper, SceneConf> implements ISceneConfService {

    @Override
    public List<SceneResp> getSceneRespListByDeviceId(String deviceId) {
        return baseMapper.selectSceneConfByDevice(deviceId);
    }
}
