package com.ceco.module.dao;

import com.ceco.module.entity.device.DeviceInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dean
 * @since 2021-11-24
 */
@Mapper
public interface DeviceInfoMapper extends BaseMapper<DeviceInfo> {

}
