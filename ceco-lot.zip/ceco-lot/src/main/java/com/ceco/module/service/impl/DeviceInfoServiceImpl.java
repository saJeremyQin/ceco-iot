package com.ceco.module.service.impl;

import com.ceco.module.entity.device.BaseDeviceInfo;
import com.ceco.module.entity.device.DeviceInfo;
import com.ceco.module.dao.DeviceInfoMapper;
import com.ceco.module.service.IDeviceInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dean
 * @since 2021-11-24
 */
@Service
public class DeviceInfoServiceImpl extends ServiceImpl<DeviceInfoMapper, DeviceInfo> implements IDeviceInfoService {
    @Override
    public void saveDynamicDeviceInfo(BaseDeviceInfo baseDeviceInfo) {

    }

    @Override
    public BaseDeviceInfo queryDynamicDeviceInfo(Map map) {
        return null;
    }
}
