package com.ceco.module.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.ceco.common.utils.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author zmj
 * @since 2021-11-12
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("ce_schedule_time")
public class ScheduleTime extends BaseEntity {



    private String scheduleId;

    /**
     * 1周期2定时
     */
    private Integer type;

    private Integer dayOfWeek;

    private Integer time;
    /**
     * 动作:1开灯2关灯
     */
    private Integer action;




}
