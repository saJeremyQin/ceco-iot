package com.ceco.module.service;

import com.ceco.module.entity.Schedule;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zmj
 * @since 2021-11-12
 */
public interface IScheduleService extends IService<Schedule> {

}
