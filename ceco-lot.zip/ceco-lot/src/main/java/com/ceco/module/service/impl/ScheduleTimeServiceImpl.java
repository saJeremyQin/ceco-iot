package com.ceco.module.service.impl;

import com.ceco.module.entity.ScheduleTime;
import com.ceco.module.dao.ScheduleTimeMapper;
import com.ceco.module.service.IScheduleTimeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zmj
 * @since 2021-11-12
 */
@Service
public class ScheduleTimeServiceImpl extends ServiceImpl<ScheduleTimeMapper, ScheduleTime> implements IScheduleTimeService {

}
