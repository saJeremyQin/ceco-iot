package com.ceco.module.entity.device;

/**
 * @auther Dean
 * @Date 2021/11/26.
 */
public interface BaseDeviceInfo {
}
