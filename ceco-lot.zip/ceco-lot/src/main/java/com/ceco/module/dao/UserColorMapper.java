package com.ceco.module.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ceco.channel.app.model.resp.GroupResp;
import com.ceco.module.entity.Group;
import com.ceco.module.entity.UserColor;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 群组设置 Mapper 接口
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Mapper
public interface UserColorMapper extends BaseMapper<UserColor> {

}
