package com.ceco.module.service;

import com.ceco.common.utils.response.ResponseModel;
import com.ceco.module.entity.WeeklySchedule;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dean
 * @since 2021-11-09
 */
public interface IWeeklyScheduleService extends IService<WeeklySchedule> {

}
