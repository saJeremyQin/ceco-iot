package com.ceco.module.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

import com.ceco.common.utils.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 模式配置
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("ce_model_conf")
public class ModelConf extends BaseEntity {
    /**
     * 模式名称
     */
    private String name;

    /**
     * 图片地址
     */
    private String imgUrl;


    /**
     * 亮度
     */
    private String brightnessValue;

    /**
     * 色温值
     */
    private String colorTemperatureValue;

    /**
     * hsv值
     */
    private String hsvValue;


    private String deviceType;


   private String hsvBrightnessValue;




}
