package com.ceco.module.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ceco.channel.app.model.resp.GroupResp;
import com.ceco.module.dao.GroupMapper;
import com.ceco.module.dao.UserColorMapper;
import com.ceco.module.entity.Group;
import com.ceco.module.entity.UserColor;
import com.ceco.module.service.IGroupService;
import com.ceco.module.service.IUserColorService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 群组设置 服务实现类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Service
public class UserColorServiceImpl extends ServiceImpl<UserColorMapper, UserColor> implements IUserColorService {

}
