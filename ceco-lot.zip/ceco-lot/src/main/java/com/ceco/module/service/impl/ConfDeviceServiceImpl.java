package com.ceco.module.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.module.dao.ConfDeviceMapper;
import com.ceco.module.dao.VersionSupportDeviceMapper;
import com.ceco.module.entity.ConfDevice;
import com.ceco.module.entity.VersionSupportDevice;
import com.ceco.module.service.IConfDeviceService;
import com.ceco.module.service.IVersionSupportDeviceService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 固件支持设备型号 服务实现类
 * </p>
 *
 * @author zmj
 * @since 2021-10-13
 */
@Service
public class ConfDeviceServiceImpl extends ServiceImpl<ConfDeviceMapper, ConfDevice> implements IConfDeviceService {


    @Override
    public List<DeviceModelResp> selectConfDeviceList(List<String> confIdList,Integer type,List<String>deviceModelIdList) {
        return this.baseMapper.selectConfDeviceList(confIdList,type,deviceModelIdList);
    }
}
