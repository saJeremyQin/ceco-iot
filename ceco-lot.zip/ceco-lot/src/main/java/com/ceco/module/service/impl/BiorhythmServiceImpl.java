package com.ceco.module.service.impl;

import com.ceco.module.dao.BiorhythmMapper;
import com.ceco.module.entity.Biorhythm;
import com.ceco.module.service.IBiorhythmService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dean
 * @since 2021-11-09
 */
@Service
public class BiorhythmServiceImpl extends ServiceImpl<BiorhythmMapper, Biorhythm> implements IBiorhythmService {

}
