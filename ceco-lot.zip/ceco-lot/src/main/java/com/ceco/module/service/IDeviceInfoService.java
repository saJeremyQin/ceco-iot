package com.ceco.module.service;

import com.ceco.module.entity.device.BaseDeviceInfo;
import com.ceco.module.entity.device.DeviceInfo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dean
 * @since 2021-11-24
 */
public interface IDeviceInfoService extends IService<DeviceInfo> {

    /**
     * 动态保存
     * @param baseDeviceInfo
     */
    void saveDynamicDeviceInfo(BaseDeviceInfo baseDeviceInfo);

    /**
     * 动态查询
     * @param map
     * @return
     */
    BaseDeviceInfo queryDynamicDeviceInfo(Map map);


}
