package com.ceco.module.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ceco.common.utils.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 动态灯效配置
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("ce_scene_param")
public class SceneParam extends BaseEntity {


    /**
     * 模式名称
     */
    private String name;

    private String content;


}
