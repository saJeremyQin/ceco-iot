package com.ceco.module.service.impl;

import com.ceco.channel.admin.model.resp.ModelResp;
import com.ceco.module.entity.ModelConf;
import com.ceco.module.dao.ModelConfMapper;
import com.ceco.module.service.IModelConfService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 模式配置 服务实现类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Service
public class ModelConfServiceImpl extends ServiceImpl<ModelConfMapper, ModelConf> implements IModelConfService {

    @Override
    public List<ModelResp> getModeRespListByDeviceId(String deviceId) {
        return baseMapper.selectModelConfByDevice(deviceId);
    }
}
