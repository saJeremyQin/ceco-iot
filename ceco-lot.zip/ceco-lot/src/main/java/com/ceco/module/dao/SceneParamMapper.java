package com.ceco.module.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ceco.module.entity.SceneConf;
import com.ceco.module.entity.SceneParam;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 动态灯效配置 Mapper 接口
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
@Mapper
public interface SceneParamMapper extends BaseMapper<SceneParam> {
            String selectSceneParamBySceneConfIdDAO(String sceneConfId);
}
