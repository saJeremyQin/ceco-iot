package com.ceco.module.service;

import com.ceco.channel.admin.model.resp.ModelResp;
import com.ceco.channel.admin.model.resp.SceneResp;
import com.ceco.module.entity.SceneConf;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 动态灯效配置 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
public interface ISceneConfService extends IService<SceneConf> {



    /**
     * 根据设备查询动态场景
     * @param deviceId
     * @return
     */
    List<SceneResp> getSceneRespListByDeviceId(String deviceId);
}
