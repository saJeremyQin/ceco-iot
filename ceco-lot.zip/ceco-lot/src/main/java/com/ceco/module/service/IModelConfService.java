package com.ceco.module.service;

import com.ceco.channel.admin.model.resp.ModelResp;
import com.ceco.module.entity.ModelConf;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 模式配置 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
public interface IModelConfService extends IService<ModelConf> {

    /**
     * 根据设备查询静态场景
     * @param deviceId
     * @return
     */
    List<ModelResp> getModeRespListByDeviceId(String deviceId);
}
