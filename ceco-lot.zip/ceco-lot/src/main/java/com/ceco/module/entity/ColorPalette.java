package com.ceco.module.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ceco.common.utils.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author dean
 * @since 2021-11-12
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("ce_color_palette")
public class ColorPalette extends BaseEntity {

    private static final long serialVersionUID=1L;

    private String appUserId;

    private String serialNo;

    /**
     * 数据体大小
     */
    private String colorPaletteData;

    /**
     * 调色板节点数
     */
    private Integer size;


}
