package com.ceco.module.service;

import com.ceco.module.entity.ColorPalette;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dean
 * @since 2021-11-12
 */
public interface IColorPaletteService extends IService<ColorPalette> {

}
