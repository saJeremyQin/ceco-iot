package com.ceco.module.service;

import com.ceco.module.entity.FirmwareVersion;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 固件版本 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-13
 */
public interface IFirmwareVersionService extends IService<FirmwareVersion> {

}
