package com.ceco.module.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.module.entity.ConfDevice;
import com.ceco.module.entity.VersionSupportDevice;

import java.util.List;

/**
 * <p>
 * 固件支持设备型号 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-13
 */
public interface IConfDeviceService extends IService<ConfDevice> {

    /**
     * 查询灯效配置支持的设备型号
     * @param confIdList 版本号
     * @param type 灯效类型
     * @return
     */
    List<DeviceModelResp> selectConfDeviceList(List<String> confIdList,Integer type,List<String>deviceModelIdList);

}
