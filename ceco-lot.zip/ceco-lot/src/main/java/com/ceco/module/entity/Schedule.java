package com.ceco.module.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

import com.ceco.common.utils.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author zmj
 * @since 2021-11-12
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("ce_schedule")
public class Schedule extends BaseEntity {

    /**
     * 类型:0节律1定时
     */
    private Integer type;

    /**
     * 用户id
     */
    private String appUserId;




    private String deviceId;


    private String name;



}
