package com.ceco.module.dao;

import com.ceco.module.entity.ColorPalette;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dean
 * @since 2021-11-12
 */
@Mapper
public interface ColorPaletteMapper extends BaseMapper<ColorPalette> {

}
