package com.ceco.module.dao;

import com.ceco.module.entity.ScheduleTime;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zmj
 * @since 2021-11-12
 */
@Mapper
public interface ScheduleTimeMapper extends BaseMapper<ScheduleTime> {

}
