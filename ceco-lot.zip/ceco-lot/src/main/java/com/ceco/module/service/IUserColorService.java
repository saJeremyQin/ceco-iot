package com.ceco.module.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ceco.channel.app.model.resp.GroupResp;
import com.ceco.module.entity.Group;
import com.ceco.module.entity.UserColor;

import java.util.List;

/**
 * <p>
 * 群组设置 服务类
 * </p>
 *
 * @author zmj
 * @since 2021-10-02
 */
public interface IUserColorService extends IService<UserColor> {


}
