package com.ceco.module.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ceco.channel.admin.model.resp.DeviceModelResp;
import com.ceco.module.entity.ConfDevice;
import com.ceco.module.entity.VersionSupportDevice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 固件支持设备型号 Mapper 接口
 * </p>
 *
 * @author zmj
 * @since 2021-10-13
 */
@Mapper
public interface ConfDeviceMapper extends BaseMapper<ConfDevice> {

    /**
     * 根据类型和配置Id查询支持的设备类型信息
     * @param confIdList
     * @return
     */
    List<DeviceModelResp> selectConfDeviceList(@Param("confIdList") List<String> confIdList,@Param("type") Integer type,@Param("deviceModelIdList") List<String> deviceModelIdList);
}
