package com.ceco.module.service;

import com.ceco.module.entity.ScheduleTime;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zmj
 * @since 2021-11-12
 */
public interface IScheduleTimeService extends IService<ScheduleTime> {

}
