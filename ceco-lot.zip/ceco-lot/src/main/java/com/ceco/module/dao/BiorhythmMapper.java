package com.ceco.module.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ceco.module.entity.Biorhythm;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dean
 * @since 2021-11-09
 */
@Mapper
public interface BiorhythmMapper extends BaseMapper<Biorhythm> {

}
