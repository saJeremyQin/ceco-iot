package com.ceco.module.service.impl;

import com.ceco.module.entity.ColorPalette;
import com.ceco.module.dao.ColorPaletteMapper;
import com.ceco.module.service.IColorPaletteService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author dean
 * @since 2021-11-12
 */
@Service
public class ColorPaletteServiceImpl extends ServiceImpl<ColorPaletteMapper, ColorPalette> implements IColorPaletteService {

}
